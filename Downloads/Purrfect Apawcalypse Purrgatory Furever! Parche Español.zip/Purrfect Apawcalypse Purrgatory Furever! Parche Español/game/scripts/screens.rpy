﻿init offset = -1
## Styles
style main_menu_button is navigation_button:
    xalign 0.5
style default:
    properties gui.text_properties()
    language gui.language
style input:
    properties gui.text_properties("input", accent=True)
    adjust_spacing False
style hyperlink_text:
    properties gui.text_properties("hyperlink", accent=True)
    hover_underline True
    mouse "aktion"
style gui_text:
    properties gui.text_properties("interface")
style button:
    properties gui.button_properties("button")
style button_text is gui_text:
    properties gui.text_properties("button")
    yalign 0.5
style label_text is gui_text:
    properties gui.text_properties("label", accent=True)
style prompt_text is gui_text:
    properties gui.text_properties("prompt")
style slider:
    ysize gui.slider_size
    base_bar Frame("gui/slider/horizontal_[prefix_]bar.webp", gui.slider_borders, tile=gui.slider_tile)
    thumb "gui/slider/horizontal_[prefix_]thumb.webp"
style frame:
    padding gui.frame_borders.padding
    background Frame("gui/other/frame.webp", gui.frame_borders, tile=gui.frame_tile)
## In-game screens
## Say screen ##################################################################
screen say(who, what):
    style_prefix "say"
    window:
        id "window"
        if who is not None:
            window:
                id "namebox"
                style "namebox"
                text who id "who"
        text what id "what"
    if not renpy.variant("small"):
        add SideImage() xalign 0.0 yalign 1.0
init python:
    config.character_id_prefixes.append('namebox')
style window is default
style say_label is default
style say_dialogue is default
style say_thought is say_dialogue
style namebox is default
style namebox_label is say_label
style window:
    xalign 0.5
    xfill True
    yalign gui.textbox_yalign
    ysize gui.textbox_height
style namebox:
    xpos gui.name_xpos
    xanchor gui.name_xalign
    xsize gui.namebox_width
    ypos gui.name_ypos
    ysize gui.namebox_height
    background Frame("gui/other/namebox.webp", gui.namebox_borders, tile=gui.namebox_tile, xalign=gui.name_xalign)
    padding gui.namebox_borders.padding
style say_label:
    properties gui.text_properties("name", accent=True)
    xalign gui.name_xalign
    yalign 0.5
style say_dialogue:
    properties gui.text_properties("dialogue")
    xpos gui.dialogue_xpos
    xsize gui.dialogue_width
    ypos gui.dialogue_ypos
## Input screen ################################################################
screen input(prompt):
    style_prefix "input"
    window:
        vbox:
            xpos gui.dialogue_xpos
            xsize gui.dialogue_width
            ypos gui.dialogue_ypos
            text prompt style "input_prompt"
            input id "input"
style input_prompt is default
style input_prompt:
    xalign gui.dialogue_text_xalign
    properties gui.text_properties("input_prompt")
style input:
    xalign gui.dialogue_text_xalign
    xmaximum gui.dialogue_width
## Choice screen ###############################################################
screen choice(items):
    style_prefix "choice"
    if len(items) == 6:
        grid 2 3:
            xalign .5 yalign gui.choice_button_yalign spacing 8
            for i in items:
                textbutton i.caption action i.action mouse "aktion"
    if len(items) == 5: 
        grid 2 3:
            xalign .5 yalign gui.choice_button_yalign spacing 8
            for i in items:
                textbutton i.caption action i.action mouse "aktion"
            null
    if len(items) == 4: 
        grid 2 2:
            xalign .5 yalign gui.choice_button_yalign spacing 8
            for i in items:
                textbutton i.caption action i.action mouse "aktion"
    if len(items) == 3: 
        grid 1 3:
            xalign .5 yalign gui.choice_button_yalign spacing 8
            for i in items:
                textbutton i.caption action i.action mouse "aktion"
    if len(items) == 2: 
        grid 1 2:
            xalign .5 yalign gui.choice_button_yalign spacing 8
            for i in items:
                textbutton i.caption action i.action mouse "aktion"
    if len(items) == 1: 
        grid 1 1:
            xalign .5 yalign gui.choice_button_yalign spacing 8
            for i in items:
                textbutton i.caption action i.action mouse "aktion"
define config.narrator_menu = True
style choice_vbox is vbox
style choice_button is button
style choice_button_text is button_text
style choice_vbox:
    xalign 0.5
    spacing gui.choice_spacing
style choice_button is default:
    properties gui.button_properties("choice_button")
    activate_sound "sound/sfx/button.ogg"
style choice_button_text is default:
    properties gui.button_text_properties("choice_button")
## Quick Menu screen ###########################################################
screen quick_menu():
    zorder 100
    if quick_menu:
        hbox:
            style_prefix "quick"
            xalign 0.5
            yalign 1.0
            textbutton _("Back") action Rollback() mouse "aktion"
            textbutton _("Play") action Preference("auto-forward", "toggle") mouse "aktion"
            textbutton _("Skip") action Skip() alternate Skip(fast=True, confirm=True) mouse "aktion"
            textbutton _("Save") action ShowMenu('save') mouse "aktion"
            textbutton _("Load") action ShowMenu('load') mouse "aktion"
            textbutton _("Options") action ShowMenu('options') mouse "aktion"
init python:
    config.overlay_screens.append("quick_menu")
default quick_menu = True
style quick_button is default
style quick_button_text is button_text
style quick_button:
    properties gui.button_properties("quick_button")
style quick_button_text:
    properties gui.button_text_properties("quick_button")
## Main and Game Menu Screens
## Navigation screen ###########################################################
screen navigation():
    hbox:
        xpos gui.navigation_xpos
        xanchor gui.navigation_xanchor
        yalign gui.navigation_yalign
        spacing gui.navigation_spacing
        if main_menu:
            style_prefix "main_menu"
            textbutton _("Start") action Start() mouse "aktion"
            textbutton _("Load") action ShowMenu("load") mouse "aktion"
            textbutton _("About") action ShowMenu("about") mouse "aktion"
        else:
            style_prefix "navigation"
            textbutton _("Save") action ShowMenu("save") mouse "aktion"
            textbutton _("Load") action ShowMenu("load") mouse "aktion"
        textbutton _("Options") action ShowMenu("options") mouse "aktion"
        if _in_replay:
            textbutton _("End Replay") action EndReplay(confirm=True) mouse "aktion"
        elif not main_menu:
            textbutton _("Main") action MainMenu() mouse "aktion"
        if renpy.variant("pc") and not renpy.variant("steam_deck"):
            textbutton _("Quit") action Quit(confirm=not main_menu) mouse "aktion"
style navigation_button is choice_button
style navigation_button_text is choice_button_text
style navigation_button:
    size_group "navigation"
    properties gui.button_properties("navigation_button")
style navigation_button_text:
    properties gui.button_text_properties("navigation_button")
## Main Menu screen ############################################################
screen main_menu():
    tag menu
    style_prefix "main_menu"
    add gui.main_menu_background
    frame:
        pass
    use navigation
    if gui.show_name:
        vbox:
            text "[config.name!t]":
                style "main_menu_title"
            text "[config.version]":
                style "main_menu_version"
style main_menu_frame is empty
style main_menu_hbox is hbox
style main_menu_text is gui_text
style main_menu_title is main_menu_text
style main_menu_version is main_menu_text
style main_menu_hbox:
    xalign 0.5
    yalign 0.5
    xanchor 0.5
style main_menu_text:
    properties gui.text_properties("main_menu", accent=True)
style main_menu_title:
    properties gui.text_properties("title")
style main_menu_version:
    properties gui.text_properties("version")
## Game Menu screen ############################################################
screen game_menu(title, scroll=None, yinitial=0):
    style_prefix "game_menu"
    if main_menu:
        add gui.main_menu_background
    else:
        add gui.game_menu_background
    frame:
        style "game_menu_outer_frame"
        hbox:
            frame:
                style "game_menu_content_frame"
                if scroll == "viewport": #You can scroll through the viewport!
                    viewport:
                        yinitial yinitial
                        mousewheel True
                        draggable True
                        pagekeys True
                        side_yfill True
                        vbox:
                            transclude
                elif scroll == "vpgrid": # Vpgrid makes it static, non-scrollable
                    vpgrid:
                        cols 1
                        yinitial yinitial
                        mousewheel True
                        draggable False
                        pagekeys True
                        side_yfill True
                        transclude
                else:
                    transclude
    use navigation
    textbutton _("Back"):
        if not renpy.variant("pc") or renpy.variant("steam_deck"):
            ypos gui.gamemenubackbutton_ypos
        style "return_button"
        action Return()
        mouse "aktion"
    label title
    if main_menu:
        key "game_menu" action ShowMenu("main_menu")
style game_menu_outer_frame is empty
style game_menu_content_frame is empty
style game_menu_viewport is gui_viewport
style game_menu_side is gui_side
style game_menu_label is gui_label
style game_menu_label_text is gui_label_text
style game_menu_outer_frame:
    bottom_padding 30
    top_padding 150
    xalign 0.0
    xanchor 0.0
    left_padding gui.preferencespadding
    right_padding gui.preferencespadding
    background "gui/other/game_menu.webp"
style game_menu_content_frame:
    left_margin 60
    right_margin 0
    top_margin 15
    xalign 0.5
    xanchor 0.5
style game_menu_viewport:
    xsize 1380
    ysize 720
style game_menu_side:
    spacing 0
style game_menu_label:
    xpos 0.5
    xanchor 0.5
    ysize 200
style game_menu_label_text:
    size gui.title_text_size
    color gui.accent_color
    yalign 0.5
style return_button:
    xpos 0.5
    xanchor 0.5
    ypos gui.gamemenubackbutton_ypos
    size 12
## About screen ################################################################
screen about():
    tag menu
    use game_menu(_("About"), scroll="viewport"):
        vbox:
            if gui.about:
                xsize 840
                text "[gui.about!t]":
                    if not renpy.variant("pc") or renpy.variant("steam_deck"):
                        size 40
define gui.about = ""
style about_label is gui_label
style about_label_text is gui_label_text
style about_text is gui_text
style about_label_text:
    size gui.label_text_size
## Load and Save screens #######################################################
screen save():
    tag menu
    use file_slots(_("Save"))
screen load():
    tag menu
    use file_slots(_("Load"))
screen file_slots(title):
    default page_name_value = FilePageNameInputValue(pattern=_("Page {}"))
    use game_menu(title):
        fixed:
            xpos -45
            order_reverse True
            button:
                style "page_label"
                key_events True
                xalign 0.5
                if renpy.variant("pc") and not renpy.variant("steam_deck"):
                    action page_name_value.Toggle()
                    mouse "aktion"
                    input:
                        style "page_label_text"
                        value page_name_value
            grid gui.file_slot_cols gui.file_slot_rows:
                style_prefix "slot"
                xalign 0.5
                yalign 0.31
                spacing gui.slot_spacing
                for i in range(gui.file_slot_cols * gui.file_slot_rows):
                    $ slot = i + 1
                    button:
                        action FileAction(slot)
                        mouse "aktion"
                        has vbox
                        add FileScreenshot(slot) xalign 0.5
                        text FileTime(slot, format=_("{#file_time}%B %d, %H:%M"), empty=_("Empty")):
                            style "slot_time_text"
                        ypos 30
                        text FileSaveName(slot):
                            style "slot_name_text"
                        key "save_delete" action FileDelete(slot)
            hbox:
                style_prefix "page"
                xpos 0.5
                xanchor 0.5
                yalign gui.numberedpage_yalign
                spacing gui.page_spacing
                for page in range(1, 10):
                    textbutton "[page]" action FilePage(page) mouse "aktion"
style page_label is gui_label
style page_label_text is gui_label_text
style page_button is gui_button
style page_button_text is gui_button_text
style slot_button is gui_button
style slot_button_text is gui_button_text
style slot_time_text is slot_button_text
style slot_name_text is slot_button_text
style page_label:
    xalign 0.5
    ypadding 5
style page_label_text:
    text_align 0.5
    layout "subtitle"
    hover_color gui.hover_color
style page_button:
    properties gui.button_properties("page_button")
style page_button_text:
    properties gui.button_text_properties("page_button")
style slot_button:
    properties gui.button_properties("slot_button")
style slot_button_text:
    properties gui.button_text_properties("slot_button")
## Preferences screen ##########################################################
screen options():
    tag menu
    use game_menu(_("Options"), scroll="vpgrid"):
        vbox:
            xalign 0.5
            hbox:
                box_wrap False
                xalign 0.5
                if renpy.variant("pc") and not renpy.variant("steam_deck"):
                    vbox:
                        xalign 0.5
                        style_prefix "radio"
                        label _("Display")
                        textbutton _("Window") action Preference("display", "window") mouse "aktion"
                        textbutton _("Fullscreen") action Preference("display", "fullscreen") mouse "aktion"
                vbox:
                    xalign 0.5
                    if not renpy.variant("pc") or renpy.variant("steam_deck"):
                        xpos 360
                    style_prefix "radio"
                    label _("Click to Go Back")
                    textbutton _("Disable") action Preference("rollback side", "disable") mouse "aktion"
                    textbutton _("On Left Side") action Preference("rollback side", "left") mouse "aktion"
                    textbutton _("On Right Side") action Preference("rollback side", "right") mouse "aktion"
                vbox:
                    xalign 0.5
                    if not renpy.variant("pc") or renpy.variant("steam_deck"):
                        xpos 180
                    style_prefix "check"
                    label _("Skip")
                    textbutton _("Unseen Text") action Preference("skip", "toggle") mouse "aktion"
                    textbutton _("After Choices") action Preference("after choices", "toggle") mouse "aktion"
                    textbutton _("Transitions") action InvertSelected(Preference("transitions", "toggle")) mouse "aktion"
            null height (4 * gui.pref_spacing)
            hbox:
                xalign 0.5
                box_wrap False
                if not renpy.variant("pc") or renpy.variant("steam_deck"):
                    ypos -40  # yoffset for the Language section
                vbox:
                    style_prefix "pref"
                    label _("Language")
                    textbutton ("{font=Bani-Regular.ttf}English{/font}"):
                        action Language(None) mouse "aktion"
                        text_size gui.languageoption_text_size
                    textbutton ("{font=Bani-Regular.ttf}Español{/font}"):
                        action Language("spanish") mouse "aktion"
                        text_size gui.languageoption_text_size
                    textbutton ("{font=Bani-Regular.ttf}Portugues do Brasil{/font}"):
                        action Language("portuguesebrazil") mouse "aktion"
                        text_size gui.languageoption_text_size
                    textbutton ("{font=Bani-Regular.ttf}Polski{/font}"):
                        action Language("polish") mouse "aktion"
                        text_size gui.languageoption_text_size
                    #textbutton "{font=Bani-Regular.ttf}Українська{/font}":
                    #    action Language("ukrainian") mouse "aktion"
                    #    text_size gui.languageoption_text_size
                    textbutton ("{font=Bani-Regular.ttf}Русский язык{/font}"):
                        action Language("russian") mouse "aktion"
                        text_size gui.languageoption_text_size
                    textbutton ("{font=FZMM.ttf}中文{/font}"):
                        action Language("chinese") mouse "aktion"
                        text_size gui.languageoption_text_size
                    textbutton ("{font=azuki.ttf}日本語{/font}"):
                        action Language("japanese") mouse "aktion"
                        text_size gui.languageoption_text_size
                    #textbutton ("{font=Bazzi.ttf}한국어{/font}"):
                    #    action Language("korean") mouse "aktion"
                    #    text_size gui.languageoption_text_size
                    text _("Version [config.version]"):
                        size gui.label_text_size
                        ypos gui.version_ypos
                vbox:
                    if not renpy.variant("pc") or renpy.variant("steam_deck"):
                        xpos -150 # Offset for the slider section
                    style_prefix "slider"
                    label _("Text Speed")
                    bar value Preference("text speed") mouse "aktion"
                    label _("Auto-Play Speed")
                    bar value Preference("auto-forward time") mouse "aktion"
                    if config.has_music:
                        label _("Music Volume")
                        hbox:
                            bar value Preference("music volume") mouse "aktion"
                    if config.has_sound:
                        label _("Sound Volume")
                        hbox:
                            bar value Preference("sound volume") mouse "aktion"
                    if config.has_voice:
                        label _("Voice Volume")
                        hbox:
                            bar value Preference("voice volume") mouse "aktion"
                    if config.has_music or config.has_sound or config.has_voice:
                        null height gui.pref_spacing
                        textbutton _("Mute All"):
                            action Preference("all mute", "toggle")
                            style "mute_all_button" mouse "aktion"
style pref_label is gui_label
style pref_label_text is gui_label_text
style pref_vbox is vbox
style radio_label is pref_label
style radio_label_text is pref_label_text
style radio_button is gui_button
style radio_button_text is gui_button_text
style radio_vbox is pref_vbox
style check_label is pref_label
style check_label_text is pref_label_text
style check_button is gui_button
style check_button_text is gui_button_text
style check_vbox is pref_vbox
style slider_label is pref_label
style slider_label_text is pref_label_text
style slider_slider is gui_slider
style slider_button is gui_button
style slider_button_text is gui_button_text
style slider_pref_vbox is pref_vbox
style mute_all_button is check_button
style mute_all_button_text is check_button_text
style pref_label:
    top_margin gui.pref_spacing
    bottom_margin 3
style pref_label_text:
    yalign 1.0
style pref_vbox:
    xsize 320
style radio_vbox:
    spacing gui.pref_button_spacing
style radio_button:
    properties gui.button_properties("radio_button")
    foreground "gui/button/check_[prefix_]foreground.webp"
style radio_button_text:
    properties gui.button_text_properties("radio_button")
style check_vbox:
    spacing gui.pref_button_spacing
style check_button:
    properties gui.button_properties("check_button")
    foreground "gui/button/check_[prefix_]foreground.webp"
style check_button_text:
    properties gui.button_text_properties("check_button")
style slider_slider:
    xsize 525
style slider_button:
    properties gui.button_properties("slider_button")
    yalign 0.5
    left_margin 15
style slider_button_text:
    properties gui.button_text_properties("slider_button")
style slider_vbox:
    xsize 675
## Confirm screen ##############################################################
screen confirm(message, yes_action, no_action):
    modal True
    zorder 200
    style_prefix "confirm"
    add "gui/overlay/confirm.webp"
    frame:
        vbox:
            xalign .5
            yalign .5
            spacing 45
            label _(message):
                style "confirm_prompt"
                xalign 0.5
            hbox:
                xalign 0.5
                spacing 100
                textbutton _("Yes.") action yes_action mouse "aktion"
                textbutton _("No.") action no_action mouse "aktion"
    key "game_menu" action no_action
style confirm_frame is gui_frame
style confirm_prompt is gui_prompt
style confirm_prompt_text is gui_prompt_text
style confirm_button is gui_medium_button
style confirm_button_text is gui_medium_button_text
style confirm_frame:
    background Frame([ "gui/other/confirm_frame.webp", "gui/other/frame.webp"], gui.confirm_frame_borders, tile=gui.frame_tile)
    padding gui.confirm_frame_borders.padding
    xalign .5
    yalign .5
style confirm_prompt_text:
    text_align 0.5
    layout "subtitle"
style confirm_button:
    properties gui.button_properties("confirm_button")
style confirm_button_text:
    properties gui.button_text_properties("confirm_button")
## Skip indicator screen #######################################################
screen skip_indicator():
    zorder 100
    style_prefix "skip"
    frame:
        hbox:
            spacing 9
            text _("Skipping")
            text "▸" at delayed_blink(0.0, 1.0) style "skip_triangle"
            text "▸" at delayed_blink(0.2, 1.0) style "skip_triangle"
            text "▸" at delayed_blink(0.4, 1.0) style "skip_triangle"
transform delayed_blink(delay, cycle):
    alpha .5
    pause delay
    block:
        linear .2 alpha 1.0
        pause .2
        linear .2 alpha 0.5
        pause (cycle - .4)
        repeat
style skip_frame is empty
style skip_text is gui_text
style skip_triangle is skip_text
style skip_frame:
    ypos gui.skip_ypos
    background Frame("gui/other/skip.webp", gui.skip_frame_borders, tile=gui.frame_tile)
    padding gui.skip_frame_borders.padding
style skip_text:
    size gui.notify_text_size
style skip_triangle:
    font "DejaVuSans.ttf"
## Notify screen ###############################################################
screen notify(message):
    zorder 100
    style_prefix "notify"
    frame at notify_appear:
        text "[message!tq]"
    timer 3.25 action Hide('notify')
transform notify_appear:
    on show:
        alpha 0
        linear .25 alpha 1.0
    on hide:
        linear .5 alpha 0.0
style notify_frame is empty
style notify_text is gui_text
style notify_frame:
    ypos gui.notify_ypos
    background Frame("gui/other/notify.webp", gui.notify_frame_borders, tile=gui.frame_tile)
    padding gui.notify_frame_borders.padding
style notify_text:
    properties gui.text_properties("notify")
## Mobile Variants ##################################################################
screen quick_menu():
    variant ("touch", "steam_deck")
    zorder 100
    if quick_menu:
        hbox:
            style_prefix "quick"
            xalign 0.5
            yalign 1.0
            textbutton _("Back") action Rollback()
            textbutton _("Play") action Preference("auto-forward", "toggle")
            textbutton _("Skip") action Skip() alternate Skip(fast=True, confirm=True)
            textbutton _("Menu") action ShowMenu()
style window:
    variant ("small", "medium", "steam_deck")
    background "gui/phone/textbox.webp"
style radio_button:
    variant ("small", "medium", "steam_deck")
    foreground "gui/phone/button/check_[prefix_]foreground.webp"
style check_button:
    variant ("small", "medium", "steam_deck")
    foreground "gui/phone/button/check_[prefix_]foreground.webp"
style nvl_window:
    variant ("small", "medium", "steam_deck")
    background "gui/phone/nvl.webp"
style main_menu_frame:
    variant ("small", "medium", "steam_deck")
    background "gui/phone/overlay/main_menu.webp"
style game_menu_outer_frame:
    variant ("small", "medium", "steam_deck")
    background "game_menu_phone"
style game_menu_navigation_frame:
    variant ("small", "medium", "steam_deck")
    xsize 510
style game_menu_content_frame:
    variant ("small", "medium", "steam_deck")
    left_margin 60
    right_margin 0
    top_margin 0
    xalign 0.5
    xanchor 0.5
    xsize 1000
style pref_vbox:
    variant ("small", "medium", "steam_deck")
    xsize 600
style slider:
    variant ("small", "medium", "steam_deck")
    ysize 38
    base_bar Frame("gui/phone/slider/horizontal_[prefix_]bar.webp", gui.slider_borders, tile=gui.slider_tile)
    thumb "gui/phone/slider/horizontal_[prefix_]thumb.webp"
style slider_slider:
    variant ("small", "medium", "steam_deck")
    xsize 400
style slider_pref_vbox:
    variant ("small", "medium", "steam_deck")
    xsize None
style slider_pref_slider:
    variant ("small", "medium", "steam_deck")
    xsize 900