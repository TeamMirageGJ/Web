# TODO: Translation updated at 2024-11-25 12:57

# game/scripts/scriptbed.rpy:26
translate spanish bedintro_4ef50c56:

    # a "OLIVE!! RUN!!"
    a "¡¡OLIVE!! ¡¡CORRE!!"

# game/scripts/scriptbed.rpy:28
translate spanish bedintro_23c2cc90:

    # n "All of Olive's pals are bound up in magic wire!"
    n "¡Todos los amigos de Olive están atados con un alambre mágico!"

# game/scripts/scriptbed.rpy:32
translate spanish bedintro_98b8be16:

    # "{w=0.5}{nw}" with vpunch
    "{w=0.5}{nw}" with vpunch

# game/scripts/scriptbed.rpy:37
translate spanish bedintro_ddbd5f31:

    # p "SHUT UP TRAITOR."
    p "CALLATE TRAIDOR."

# game/scripts/scriptbed.rpy:41
translate spanish bedintro_57c7c14d:

    # n "Angel's mouth is bound!" with vpunch
    n "¡El ata la boca de Angel!" with vpunch

# game/scripts/scriptbed.rpy:43
translate spanish bedintro_98b8be16_1:

    # "{w=0.5}{nw}" with vpunch
    "{w=0.5}{nw}" with vpunch

# game/scripts/scriptbed.rpy:45
translate spanish bedintro_99c08fdf:

    # p "Ginger, you made it just in time!"
    p "¡Ginger, llegaste justo a tiempo!"

# game/scripts/scriptbed.rpy:47
translate spanish bedintro_5b0f6a71:

    # p "And you brought guests!"
    p "¡Y trajiste invitados!"

# game/scripts/scriptbed.rpy:50
translate spanish bedintro_c720f102:

    # g "P-Patches! You're talking to me again?"
    g "¡P-Patches! ¿Estás hablando conmigo otra vez?"

# game/scripts/scriptbed.rpy:53
translate spanish bedintro_43a6cdbc:

    # p "Well of course, I couldn't do any of this without my lovely assistant!"
    p "Bueno, por supuesto, ¡no podría hacer nada de esto sin mi adorable asistente!"

# game/scripts/scriptbed.rpy:56
translate spanish bedintro_fb5b8f67:

    # g "Heheh..."
    g "Jejeje..."

# game/scripts/scriptbed.rpy:63
translate spanish bedintro_1a1afdb0:

    # s "Ginger, don't listen to him! He's just manipulating you!!"
    s "Ginger, ¡no le hagas caso! ¡¡Él solo te está manipulando!!"

# game/scripts/scriptbed.rpy:68
translate spanish bedintro_be53c5c0:

    # n "Wires grab Sparky!" with vpunch
    n "¡Los cables agarran a Sparky!" with vpunch

# game/scripts/scriptbed.rpy:70
translate spanish bedintro_98b8be16_2:

    # "{w=0.5}{nw}" with vpunch
    "{w=0.5}{nw}" with vpunch

# game/scripts/scriptbed.rpy:73
translate spanish bedintro_cf5b53d0:

    # n "They slam him into the wall with the others!"
    n "¡Y lo estrellan contra la pared junto a los demás!"

# game/scripts/scriptbed.rpy:75
translate spanish bedintro_bc0ba068:

    # p "Enough chit chat! Let's get our new pets in a comfier space!"
    p "¡Basta de charla! ¡Llevemos a nuestras nuevas mascotas a un espacio más cómodo!"

# game/scripts/scriptbed.rpy:76
translate spanish bedintro_a7ad0c05:

    # p "Then we can really give Angel a show!"
    p "¡Entonces realmente podremos darle un espectáculo a Angel!"

# game/scripts/scriptbed.rpy:78
translate spanish bedintro_a0077628:

    # p "As thanks for all the pain he's caused me."
    p "Como agradecimiento por todo el dolor que me ha causado."

# game/scripts/scriptbed.rpy:81
translate spanish bedintro_79f677ed:

    # n "Patches aims his wand at Olive."
    n "Patches apunta con su varita a Olive."

# game/scripts/scriptbed.rpy:83
translate spanish bedintro_02180621:

    # g "NO!"
    g "¡NO!"

# game/scripts/scriptbed.rpy:86
translate spanish bedintro_6b9f69e0:

    # n "Ginger sends a blast of energy from her paw into Patches' chest!!" with vpunch
    n "¡Ginger envía una ráfaga de energía desde su pata al pecho de Patches!" with vpunch

# game/scripts/scriptbed.rpy:90
translate spanish bedintro_7888d20d:

    # n "Patches seems to stand steady."
    n "Patches parece mantenerse estable."

# game/scripts/scriptbed.rpy:92
translate spanish bedintro_573ac716:

    # n "Until he falls over dead." with vpunch
    n "Hasta que cae muerto." with vpunch

# game/scripts/scriptbed.rpy:95
translate spanish bedintro_db7910a2:

    # n "The magic wires that bound Olive's friends dissipate."
    n "Los cables mágicos que unían a los amigos de Olive se disipan."

# game/scripts/scriptbed.rpy:101
translate spanish bedintro_795798ae:

    # n "Angel pulls himself up, coughing."
    n "Ángel se levanta tosiendo."

# game/scripts/scriptbed.rpy:103
translate spanish bedintro_3cadcfed:

    # a "I-is he dead?"
    a "¿Está muerto?"

# game/scripts/scriptbed.rpy:111
translate spanish bedintro_fecb05c4:

    # p "AUGHHH YOU BITCH!!" with vpunch
    p "AUGHHH, ¡¡TU MALDITA PERRA!!" with vpunch

# game/scripts/scriptbed.rpy:114
translate spanish bedintro_0155b8ca:

    # o "P-PATCHES?!"
    o "¡¿P-PATCHES?!"

# game/scripts/scriptbed.rpy:118
translate spanish bedintro_fac9f946:

    # n "Patches lunges at Angel!" with vpunch
    n "¡Patches se lanza hacia Angel!" with vpunch

# game/scripts/scriptbed.rpy:122
translate spanish bedintro_b408ebc8:

    # n "But... He doesn't seem to make it. He's stopped midair by Ginger's magic." with vpunch
    n "Pero... no parece lograrlo. La magia de Ginger lo detiene en el aire." with vpunch

# game/scripts/scriptbed.rpy:124
translate spanish bedintro_82adec34:

    # g "You... You assumed I'd be here to just pick up where I left off."
    g "¿Tú... asumiste que estaría aquí para continuar donde lo dejé?"

# game/scripts/scriptbed.rpy:126
translate spanish bedintro_71a0c5ba:

    # g "I was so hurt when you turned your back on me. You told me I was a failure."
    g "Me dolió mucho cuando me diste la espalda. Me dijiste que era un fracaso."

# game/scripts/scriptbed.rpy:128
translate spanish bedintro_d3d7b697:

    # g "Am I supposed to forget all that?"
    g "¿Se supone que debo olvidar todo eso?"

# game/scripts/scriptbed.rpy:131
translate spanish bedintro_8fa6caee:

    # n "Ginger opens a portal in the middle of the room." with vpunch
    n "Ginger abre un portal en el medio de la habitación." with vpunch

# game/scripts/scriptbed.rpy:133
translate spanish bedintro_02779c22:

    # p "You wouldn't. You love me!"
    p "No lo harías. ¡Tu me amas!"

# game/scripts/scriptbed.rpy:136
translate spanish bedintro_4b340443:

    # g "..."
    g "..."

# game/scripts/scriptbed.rpy:137
translate spanish bedintro_62f38698:

    # n "Ginger begins lowering Patches into the portal."
    n "Ginger comienza a bajar a Patches al portal."

# game/scripts/scriptbed.rpy:139
translate spanish bedintro_f5300c9d:

    # p "I'M NOT GOING DOWN ALONE!!!"
    p "¡¡¡NO VOY A BAJAR SOLO!!!"

# game/scripts/scriptbed.rpy:141
translate spanish bedintro_0c3b64a8:

    # n "Patches bites onto Olive's leg!" with vpunch
    n "¡Patches muerde la pierna de Olive!" with vpunch

# game/scripts/scriptbed.rpy:142
translate spanish bedintro_b63b6088:

    # n "They fall to the ground and start slipping into the portal with him!"
    n "¡Olive cae al suelo y comienza a deslizarse hacia el portal con él!"

# game/scripts/scriptbed.rpy:144
translate spanish bedintro_cca9ebd6:

    # o "AHHH!!!"
    o "¡¡¡AHHH!!!"

# game/scripts/scriptbed.rpy:147
translate spanish bedintro_4c1f2460:

    # g "OLIVE!"
    g "¡OLIVE!"

# game/scripts/scriptbed.rpy:152
translate spanish bedintro_98b8be16_3:

    # "{w=0.5}{nw}" with vpunch
    "{w=0.5}{nw}" with vpunch

# game/scripts/scriptbed.rpy:155
translate spanish bedintro_01668857:

    # n "Ginger quickly closes the portal but it's too late!" with vpunch
    n "¡Ginger cierra rápidamente el portal pero es demasiado tarde!" with vpunch

# game/scripts/scriptbed.rpy:182
translate spanish bedintro_db0b2108:

    # g "Got them!" with vpunch
    g "¡La tengo!" with vpunch

# game/scripts/scriptbed.rpy:185
translate spanish bedintro_61a139f6:

    # c "Let's close the portal before Patches comes through!"
    c "¡Cerremos el portal antes de que llegue Patches!"

# game/scripts/scriptbed.rpy:190
translate spanish bedintro_ca26efd1:

    # o "WHAA!! WAIT WAIT WAIT!"
    o "¡¡QUÉ!! ¡ESPERA, ESPERA, ESPERA!"

# game/scripts/scriptbed.rpy:191
translate spanish bedintro_bb604e4c:

    # o "We can't just leave him in there!!"
    o "¡¡No podemos simplemente dejarlo ahí!!"

# game/scripts/scriptbed.rpy:194
translate spanish bedintro_9cf18289:

    # c "WHAT?! This is our chance to finally be rid of him!!"
    c "¡¿QUÉ?! ¡Esta es nuestra oportunidad de finalmente deshacernos de él!"

# game/scripts/scriptbed.rpy:197
translate spanish bedintro_3b3f2560:

    # o "P-please! I know he's a bad dog... But we c-can't give up on him!!"
    o "¡P-por favor! Sé que es un perro malo... ¡¡Pero no podemos abandonarlo!!"

# game/scripts/scriptbed.rpy:199
translate spanish bedintro_a13e7fea:

    # o "No one gave up on Sparky! Or G-Ginger!!"
    o "¡Nadie se dio por vencido con Sparky! ¡¡o G-ginger!!"

# game/scripts/scriptbed.rpy:202
translate spanish bedintro_a3d49084:

    # o "You've done b-bad stuff too Coco!"
    o "¡Tú también has hecho cosas malas, Coco!"

# game/scripts/scriptbed.rpy:206
translate spanish bedintro_d1462c69:

    # s "They have a point..."
    s "Tienes un punto..."

# game/scripts/scriptbed.rpy:208
translate spanish bedintro_fbbac9f3:

    # s "My life would be over if you guys gave up on me after everything I've done."
    s "Mi vida se acabaría si ustedes me abandonaran después de todo lo que he hecho."

# game/scripts/scriptbed.rpy:216
translate spanish bedintro_fdb7ae2f:

    # b "You can't teach an old dog new tricks."
    b "No se pueden enseñar trucos nuevos a un perro viejo."

# game/scripts/scriptbed.rpy:224
translate spanish bedintro_5d73f7df:

    # a "... He's not even that old though..."
    a "... Aunque ni siquiera es tan viejo..."

# game/scripts/scriptbed.rpy:226
translate spanish bedintro_ef4d680c:

    # a "I mean not that I'm defending him..."
    a "No quiero decir que lo esté defendiendo..."

# game/scripts/scriptbed.rpy:228
translate spanish bedintro_8df28b19:

    # a "Patches won't learn because he just doesn't want to..."
    a "Patches no aprenderá porque simplemente no quiere..."

# game/scripts/scriptbed.rpy:231
translate spanish bedintro_d542d517:

    # o "NoOoOoOo!!"
    o "¡¡NoOoOoOo!!"

# game/scripts/scriptbed.rpy:232
translate spanish bedintro_c677b3ac:

    # o "B-b-but it's my birthday!"
    o "¡P-p-pero es mi cumpleaños!"

# game/scripts/scriptbed.rpy:240
translate spanish bedintro_4a2c1f3d:

    # c "You already got your birthday wish Olive, with the whole meat thing."
    c "Ya tienes tu deseo de cumpleaños Olive, con todo el asunto de la carne."

# game/scripts/scriptbed.rpy:243
translate spanish bedintro_b5d2c302:

    # b "Meat thing?!"
    b "¡¿Asunto de la carne?!"

# game/scripts/scriptbed.rpy:251
translate spanish bedintro_43ee3ec3:

    # g "... Okay."
    g "... Bueno."

# game/scripts/scriptbed.rpy:253
translate spanish bedintro_3dfdaeda:

    # g "I'll grant your wish."
    g "Te concederé tu deseo."

# game/scripts/scriptbed.rpy:255
translate spanish bedintro_403ee6b2:

    # c "Oh you've GOT to be kidding me."
    c "Oh, tu DEBES estar bromeando."

# game/scripts/scriptbed.rpy:258
translate spanish bedintro_ad11c748:

    # g "Olive's right... And I'm not just saying that because I'm hung up on Patches."
    g "Olive tiene razón... Y no lo digo sólo porque esté obsesionada con Patches."

# game/scripts/scriptbed.rpy:259
translate spanish bedintro_537f25ef:

    # g "Everyone is worth saving."
    g "Vale la pena salvar a todos."

# game/scripts/scriptbed.rpy:261
translate spanish bedintro_59faca8d:

    # g "We should have some conditions for him though."
    g "Aunque deberíamos ponerle algunas condiciones."

# game/scripts/scriptbed.rpy:264
translate spanish bedintro_1531d7e4:

    # o "Yeah yeah!! J-j-just tell me what it is and I'll d-do it!!"
    o "¡¡Sí, sí!! ¡¡S-sólo dime cuales y lo haré!!"

# game/scripts/scriptbed.rpy:271
translate spanish bedintro_40d3d3cd:

    # x "{w=0.5}{nw}"
    x "{w=0.5}{nw}"

# game/scripts/scriptbed.rpy:276
translate spanish bedintro_a5bd81d5:

    # n "Coco and Ginger close the portal!"
    n "¡Coco y Ginger cierran el portal!"

# game/scripts/scriptbed.rpy:278
translate spanish bedintro_08399162:

    # s "OLIVE!! I'm so glad you're okay!"
    s "¡¡OLIVE!! ¡Me alegro mucho que estés bien!"

# game/scripts/scriptbed.rpy:288
translate spanish bedintro_e52b3e11:

    # n "Sparky pulls Olive into a bear hug which Angel and Brownie join!"
    n "¡Sparky abraza a Olive y le da un abrazo de oso al que se unen Angel y Brownie!"

# game/scripts/scriptbed.rpy:290
translate spanish bedintro_6842e74d:

    # o "WOW!! OH MY GOSH!!"
    o "¡¡GUAU!! ¡¡OH DIOS MÍO!!"

# game/scripts/scriptbed.rpy:291
translate spanish bedintro_7a3a3d82:

    # o "This is so nice!"
    o "¡Esto es tan lindo!"

# game/scripts/scriptbed.rpy:294
translate spanish bedintro_e7e8ca46:

    # b "Yup I'd say the lack of a serial killer in the house is a big improvement."
    b "Sí, diría que la falta de un asesino en serie en la casa es una gran mejora."

# game/scripts/scriptbed.rpy:297
translate spanish bedintro_a9aeee38:

    # o "Oh yeah... Patches..."
    o "Ah, sí... Patches..."

# game/scripts/scriptbed.rpy:300
translate spanish bedintro_7c22f508:

    # b "Please don't say we need to go back for him."
    b "Por favor, no digas que tenemos que volver por él."

# game/scripts/scriptbed.rpy:303
translate spanish bedintro_c4f25be1:

    # o "No... I don't know if we should..."
    o "No... no sé si deberíamos..."

# game/scripts/scriptbed.rpy:306
translate spanish bedintro_dd8082a1:

    # a "... Really?"
    a "... ¿De verdad?"

# game/scripts/scriptbed.rpy:308
translate spanish bedintro_79ca2d87:

    # a "Well I'm glad we're all in agreement then..."
    a "Bueno, entonces me alegro que estemos todos de acuerdo..."

# game/scripts/scriptbed.rpy:318
translate spanish bedintro_43be6b04:

    # g "Yes. It would only be trouble for all of us if he were to return."
    g "Sí. Sólo sería un problema para todos si regresara."

# game/scripts/scriptbed.rpy:320
translate spanish bedintro_3d50420f:

    # c "Ughhh let's not have a pity party. Let's have a BIRTHDAY PARTY!"
    c "Ughhh no tengamos una fiesta de lástima. ¡Hagamos una FIESTA DE CUMPLEAÑOS!"

# game/scripts/scriptbed.rpy:324
translate spanish bedintro_34916714:

    # o "YEAH!!"
    o "¡¡SÍ!!"

# game/scripts/scriptbed.rpy:356
translate spanish bedmenu_076cce61:

    # n "As soon as Olive's paw reaches the doorknob the lights flicker off!"
    n "¡Tan pronto como la pata de Olive llega al pomo de la puerta, las luces se apagan!"

# game/scripts/scriptbed.rpy:357
translate spanish bedmenu_46f236f6:

    # c "AGHH!!"
    c "¡¡AGHH!!"

# game/scripts/scriptbed.rpy:358
translate spanish bedmenu_bd4a2e9e:

    # c "Olive! WHY did you turn the lights off?!"
    c "¡Olive! ¿POR QUÉ apagaste las luces?"

# game/scripts/scriptbed.rpy:359
translate spanish bedmenu_067100d3:

    # o "I-it wasn't me!!"
    o "¡¡N-no fui yo!!"

# game/scripts/scriptbed.rpy:360
translate spanish bedmenu_0db0ba65:

    # n "Olive fumbles in the dark, feeling around for the light switch."
    n "Olive busca a tientas en la oscuridad el interruptor de la luz."

# game/scripts/scriptbed.rpy:361
translate spanish bedmenu_729d936c:

    # n "Their paws find themselves on something... Something furry and cold and moving."
    n "Su pata se encuentra con algo... Algo peludo, frío y en movimiento."

# game/scripts/scriptbed.rpy:362
translate spanish bedmenu_f5e1d86f:

    # o "AHH! S-s-something's-"
    o "¡AH! A-a-algo-"

# game/scripts/scriptbed.rpy:364
translate spanish bedmenu_de695c1a:

    # n "They're interrupted by a sharp pinch in their neck." with vpunch
    n "Ella es interrumpida por un fuerte pinchazo en el cuello." with vpunch

# game/scripts/scriptbed.rpy:371
translate spanish bedmenu_1f03a97f:

    # n "The lights flicker back on. Olive is on the ground."
    n "Las luces vuelven a encenderse. Olive está en el suelo."

# game/scripts/scriptbed.rpy:373
translate spanish bedmenu_9e76bfc1:

    # c "Olive?"
    c "¿Olive?"

# game/scripts/scriptbed.rpy:377
translate spanish bedmenu_09b94b27:

    # pu "Hello!"
    pu "¡Hola!"

# game/scripts/scriptbed.rpy:380
translate spanish bedmenu_2d83fc65:

    # c "A-ANGEL?! WHAT THE HELL DID YOU-"
    c "¡¿A-ANGEL?! ¿QUÉ DEMONIOS HICISTE?"

# game/scripts/scriptbed.rpy:383
translate spanish bedmenu_3a74dafc:

    # c "Nonono you're not Angel! What the hell are you?!"
    c "¡Nonono no eres Angel! ¡¿Qué diablos eres?!"

# game/scripts/scriptbed.rpy:385
translate spanish bedmenu_ff76e0d7:

    # n "Coco reaches for her wand but finds nothing."
    n "Coco busca su varita pero no encuentra nada."

# game/scripts/scriptbed.rpy:387
translate spanish bedmenu_42f66b60:

    # c "MY WAND! WHERE IS IT?!"
    c "¡MI VARITA! ¡¿DÓNDE ESTÁ?!"

# game/scripts/scriptbed.rpy:390
translate spanish bedmenu_9b3eb38e:

    # pu "Hehehe!"
    pu "¡Jejeje!"

# game/scripts/scriptbed.rpy:392
translate spanish bedmenu_0cf003e5:

    # pu "Is this not a fair trade? One thousand lives for one magical wand?"
    pu "¿No es este un comercio justo? ¿Mil vidas por una varita mágica?"

# game/scripts/scriptbed.rpy:395
translate spanish bedmenu_e09bd866:

    # c "AUGHHH WHY IS THIS HAPPENING?!?!"
    c "AUGHHH ¡¿POR QUÉ ESTÁ PASANDO ESTO?!?!"

# game/scripts/scriptbed.rpy:407
translate spanish gameover03_cbac9f6c:

    # n "Coco in a fit of anger whips pencils and books at the undead Angel." with vpunch
    n "Coco en un ataque de ira le lanza lápices y libros a el Angel zombie." with vpunch

# game/scripts/scriptbed.rpy:409
translate spanish gameover03_47b58e2a:

    # c "I JUST." with vpunch
    c "¡¡YO SOLO" with vpunch

# game/scripts/scriptbed.rpy:411
translate spanish gameover03_b2769fe4:

    # c "WANTED." with vpunch
    c "QUIERO" with vpunch

# game/scripts/scriptbed.rpy:414
translate spanish gameover03_0b1c73f0:

    # c "TO PARTY!!" with vpunch
    c "FIESTA!!" with vpunch

# game/scripts/scriptbed.rpy:418
translate spanish gameover03_95f983dd:

    # n "He uses her own wand against her, binding her in magic barbed wire. She struggles to escape!" with vpunch
    n "Él usa su propia varita contra ella, atándola con un alambre de púas mágico. ¡Ella lucha por escapar!" with vpunch

# game/scripts/scriptbed.rpy:420
translate spanish gameover03_13fb6049:

    # pu "No you're right; I think a thousand lives is worth a little more than a wand."
    pu "No, tienes razón; Creo que mil vidas valen un poco más que una varita."

# game/scripts/scriptbed.rpy:422
translate spanish gameover03_38f6ae09:

    # pu "How about an apology!"
    pu "¿Qué tal una disculpa?"

# game/scripts/scriptbed.rpy:425
translate spanish gameover03_1121972d:

    # c "FUCK OFF!"
    c "¡VETE A LA MIERDA!"

# game/scripts/scriptbed.rpy:426
translate spanish gameover03_3276fdac:

    # c "You think you get to call the shots?! Just because you have a wand now?!"
    c "¿Crees que podrás tomar las decisiones? ¿Solo porque ahora tienes una varita?"

# game/scripts/scriptbed.rpy:428
translate spanish gameover03_383af3d6:

    # c "I BET YOU DON'T EVEN KNOW HOW TO USE IT YOU MORONIC PRETENTIOUS LOSER."
    c "APUESTO QUE NI SIQUIERA SABES USARLA TU IMBECIL PRETENCIOSO PERDEDOR."

# game/scripts/scriptbed.rpy:431
translate spanish gameover03_3dd10cf7:

    # pu "I could keep you here all day Coco."
    pu "Podría tenerte aquí todo el día Coco."

# game/scripts/scriptbed.rpy:434
translate spanish gameover03_098511bb:

    # n "Coco spits at Angel's dead body."
    n "Coco escupe al cadáver de Ángel."

# game/scripts/scriptbed.rpy:437
translate spanish gameover03_e1d7d22b:

    # pu "Or maybe not."
    pu "O tal vez no."

# game/scripts/scriptbed.rpy:441
translate spanish gameover03_e24222a9:

    # n "With one twist of the wand Coco's neck breaks." with vpunch
    n "Con un giro de la varita, el cuello de Coco se rompe." with vpunch

# game/scripts/scriptbed.rpy:443
translate spanish gameover03_fe017b01:

    # n "Her body drops limp on the ground." with vpunch
    n "Su cuerpo cae inerte al suelo." with vpunch

# game/scripts/scriptbed.rpy:445
translate spanish gameover03_b6ddaf80:

    # pu "Ugh no fair. Maybe in another life I'd get to see her beg."
    pu "Uf, no es justo. Quizás en otra vida la vería suplicar."

# game/scripts/scriptbed.rpy:447
translate spanish gameover03_6d87a766:

    # pu "What do you think of all this Olive?"
    pu "¿Qué opinas de todo esto de Olive?"

# game/scripts/scriptbed.rpy:449
translate spanish gameover03_07abc845:

    # o "..."
    o "..."

# game/scripts/scriptbed.rpy:450
translate spanish gameover03_26aa7cd1:

    # n "Olive is unresponsive but still breathing."
    n "Olive no responde pero aún respira."

# game/scripts/scriptbed.rpy:452
translate spanish gameover03_78da9aaf:

    # pu "Sorry you're still up. I had to save some of this for Sparky, he's a pretty big dog after all!"
    pu "Lo siento, tu todavía estás despierta. Tuve que guardar algo para Sparky, ¡después de todo, es un perro bastante grande!"

# game/scripts/scriptbed.rpy:453
translate spanish gameover03_a3394fdf:

    # pu "That's why he's so much more useful to me than you!"
    pu "¡Por eso me es mucho más útil que tú!"

# game/scripts/scriptbed.rpy:455
translate spanish gameover03_07abc845_1:

    # o "..."
    o "..."

# game/scripts/scriptbed.rpy:457
translate spanish gameover03_37c3e1d3:

    # pu "Hmm... Actually maybe you COULD help me with something!"
    pu "Hmm... ¡En realidad tal vez tu PODRÍAS ayudarme con algo!"

# game/scripts/scriptbed.rpy:459
translate spanish gameover03_f3f5e406:

    # pu "I need someone to practice this wand on! Everything is easier with magic from what I can tell!"
    pu "¡Necesito a alguien con quien practicar esta varita! ¡Todo es más fácil con magia!"

# game/scripts/scriptbed.rpy:460
translate spanish gameover03_b44cf789:

    # pu "Skinning, gutting, amputating."
    pu "Desollar, destripar, amputar."

# game/scripts/scriptbed.rpy:462
translate spanish gameover03_bb863257:

    # pu "Nooo those are all pretty vanilla at this point! Maybe I'll turn you inside out. Or maybe I'll summon bugs behind your eyes!"
    pu "¡Nooo, todos esos son bastante básicos! Tal vez te ponga del revés. ¡O tal vez invoque insectos detrás de tus ojos!"

# game/scripts/scriptbed.rpy:465
translate spanish gameover03_5a6579c7:

    # n "Olive tries to move,"
    n "Olive intenta moverse,"

# game/scripts/scriptbed.rpy:467
translate spanish gameover03_68db1d1d:

    # n "But can't budge."
    n "Pero no puedo ceder."

# game/scripts/scriptbed.rpy:469
translate spanish gameover03_1ede7258:

    # pu "Aww so cute!"
    pu "¡Qué lindo!"

# game/scripts/scriptbed.rpy:470
translate spanish gameover03_f52f828b:

    # pu "This will be SO."
    pu "¡Esto sera."

# game/scripts/scriptbed.rpy:472
translate spanish gameover03_b8b53e34:

    # pu "MUCH."
    pu "MUY."

# game/scripts/scriptbed.rpy:474
translate spanish gameover03_786dee27:

    # pu "FUN!"
    pu "DIVERTIDO!"

# game/scripts/scriptbed.rpy:496
translate spanish gameover03_169fcbcf:

    # n "Coco runs for the door!"
    n "¡Coco corre hacia la puerta!"

# game/scripts/scriptbed.rpy:500
translate spanish gameover03_656e78e6:

    # n "The undead cat sends a burst of violet light at Coco!"
    n "¡El gato zombie envía un estallido de luz violeta a Coco!"

# game/scripts/scriptbed.rpy:504
translate spanish gameover03_1b70bcd3:

    # n "But she manages to escape just in time!"
    n "¡Pero logra escapar justo a tiempo!"

# game/scripts/scriptbed.rpy:506
translate spanish gameover03_26810efe:

    # pu "DAMN IT!"
    pu "¡MIERDA!"

# game/scripts/scriptbed.rpy:508
translate spanish gameover03_af1ef5c4:

    # pu "Whatever."
    pu "Lo que sea."

# game/scripts/scriptbed.rpy:511
translate spanish gameover03_658cc921:

    # n "He binds the door shut using his newfound magic wand." with vpunch
    n "Él cierra la puerta usando su nueva varita mágica." with vpunch

# game/scripts/scriptbed.rpy:513
translate spanish gameover03_481ef174:

    # pu "I guess she never really cared about you huh?"
    pu "Supongo que a ella nunca le importaste, ¿eh?"

# game/scripts/scriptbed.rpy:514
translate spanish gameover03_e7992433:

    # pu "That's no fun. I really wanted her to cry as I popped your eyes out."
    pu "Eso no es divertido. Tenía muchas ganas de que llorara mientras te sacaba los ojos."

# game/scripts/scriptbed.rpy:518
translate spanish gameover03_b40cad1d:

    # pu "Like this!" with vpunch
    pu "¡Como esto!" with vpunch

# game/scripts/scriptbed.rpy:520
translate spanish gameover03_07abc845_2:

    # o "..."
    o "..."

# game/scripts/scriptbed.rpy:522
translate spanish gameover03_0672c8ed:

    # pu "Ugh HOW DARE SHE RUN OFF!"
    pu "Ugh,¡COMO SE ATREVE A ESCAPAR!"

# game/scripts/scriptbed.rpy:523
translate spanish gameover03_d45eb529:

    # pu "Will anyone even care when you're gone?!"
    pu "¿A alguien le importarás cuando te vayas?"

# game/scripts/scriptbed.rpy:525
translate spanish gameover03_cef58da8:

    # pu "I'm sure they resent you for gathering them all here to begin with."
    pu "Estoy seguro de que, para empezar, te molestan por reunirlos a todos aquí."

# game/scripts/scriptbed.rpy:527
translate spanish gameover03_07abc845_3:

    # o "..."
    o "..."

# game/scripts/scriptbed.rpy:529
translate spanish gameover03_61aa7316:

    # pu "What NOTHING?!"
    pu "¡¿Qué NADA?!"

# game/scripts/scriptbed.rpy:530
translate spanish gameover03_b608a419:

    # pu "Don't you feel guilty?"
    pu "¿No te sientes culpable?"

# game/scripts/scriptbed.rpy:532
translate spanish gameover03_f9f7bea6:

    # pu "Maybe you should pay your friends back somehow."
    pu "Quizás deberías pagarles a tus amigos de alguna manera."

# game/scripts/scriptbed.rpy:536
translate spanish gameover03_f3770f9d:

    # pu "An eye for an eye!" with vpunch
    pu "¡Ojo por ojo!" with vpunch

# game/scripts/scriptbed.rpy:538
translate spanish gameover03_07abc845_4:

    # o "..."
    o "..."

# game/scripts/scriptbed.rpy:540
translate spanish gameover03_01e75714:

    # pu "Hmm. I'm kind of talking to myself here huh? It really makes me feel crazier than I probably should."
    pu "Mmm. Estoy como hablando solo aquí eh Realmente me hace sentir más loco de lo que probablemente estoy."

# game/scripts/scriptbed.rpy:541
translate spanish gameover03_1b7720ad:

    # pu "Let's just end this!"
    pu "¡Solo terminemos con esto!"

# game/scripts/scriptbed.rpy:556
translate spanish bedbunk_27070ff0:

    # n "A zombie is having a snooze in the top bunk!"
    n "¡Un zombi está durmiendo una siesta en la litera superior!"

# game/scripts/scriptbed.rpy:561
translate spanish bedbunk_ce5f1ef7:

    # c "MY BED!! It'll take eons to get the smell of dead dog out of the sheets!!"
    c "¡¡MI CAMA!! ¡¡Se necesitarán eones para quitar el olor a perro muerto de las sábanas!!"

# game/scripts/scriptbed.rpy:564
translate spanish bedbunk_f0f24040:

    # n "The zombie groans and rolls over."
    n "El zombie gime y se da vuelta."

# game/scripts/scriptbed.rpy:571
translate spanish bedbunk_990fd678:

    # n "The top bunk is neatly made and covered in cute color coordinated cushions while the lower bunk is messy and a little gothic in its decor."
    n "La litera superior está cuidadosamente hecha y cubierta con lindos cojines de colores coordinados, mientras que la litera inferior es desordenada y un poco gótica en su decoración."

# game/scripts/scriptbed.rpy:578
translate spanish bedbunk_e44dc9b1:

    # o "One's cute and one's s-spooky, but Angel and Coco are both cute AND spooky. I w-wonder which bunk belongs to who!"
    o "Una es linda y la otra espeluznante, pero Angel y Coco son lindos Y espeluznantes. ¡Me pregunto cual pertenece a quién!"

# game/scripts/scriptbed.rpy:583
translate spanish beddesk_47268f18:

    # n "One is covered in witchcraft paraphernalia while the other looks like a tornado hit a bookshelf and remade it into a desk."
    n "Uno está cubierto de elemntos de brujería, mientras que el otro parece que un tornado golpeó una estantería y lo transformo en un escritorio."

# game/scripts/scriptbed.rpy:587
translate spanish beddesk_47268f18_1:

    # n "One is covered in witchcraft paraphernalia while the other looks like a tornado hit a bookshelf and remade it into a desk."
    n "Uno está cubierto de elementos de brujería, mientras que el otro parece que un tornado golpeo una estantería y lo transformo en un escritorio."

# game/scripts/scriptbed.rpy:592
translate spanish beddesk_f116af4c:

    # o "Look at all these books and potions! Coco must be SUPER smart!"
    o "¡Mira todos estos libros y pociones! ¡Coco debe ser SÚPER inteligente!"

# game/scripts/scriptbed.rpy:595
translate spanish beddesk_0f476756:

    # s "Yeah!!"
    s "¡¡Sí!!"

# game/scripts/scriptbed.rpy:597
translate spanish beddesk_115b8880:

    # s "I have a lot of respect for people who can just sit for hours and study."
    s "Tengo mucho respeto por las personas que pueden simplemente sentarse durante horas y estudiar."

# game/scripts/scriptbed.rpy:599
translate spanish beddesk_e7c18aa9:

    # s "Just thinking about it makes me want to run around in circles."
    s "Sólo de pensarlo me dan ganas de correr en círculos."

# game/scripts/scriptbed.rpy:603
translate spanish beddesk_78234c46:

    # o "I b-bet you could do anything if you put your mind to it!!"
    o "¡¡Apuesto a que podrías hacer cualquier cosa si te lo propones!!"

# game/scripts/scriptbed.rpy:608
translate spanish beddesk_47268f18_2:

    # n "One is covered in witchcraft paraphernalia while the other looks like a tornado hit a bookshelf and remade it into a desk."
    n "Uno está cubierto de elementos de brujería, mientras que el otro parece que un tornado golpeo una estantería y lo transformo en un escritorio."

# game/scripts/scriptbed.rpy:615
translate spanish beddesk_77f3c66e:

    # o "Wow!! I bet you get a lot of cool things d-done here!"
    o "¡¡Guau!! ¡Apuesto a que aquí se hacen muchas cosas interesantes!"

# game/scripts/scriptbed.rpy:619
translate spanish beddesk_3a460f9b:

    # c "Damn right I do!"
    c "¡Maldita sea, lo hago!"

# game/scripts/scriptbed.rpy:621
translate spanish beddesk_5c42f2ba:

    # c "I can brew face-melting potions and send demons to the depths of Inferno!"
    c "¡Puedo preparar pociones que derriten la cara y enviar demonios a las profundidades del infierno!"

# game/scripts/scriptbed.rpy:624
translate spanish beddesk_6f4c6a80:

    # o "What's Inf-furno?"
    o "¿Qué es Inf-fuerno?"

# game/scripts/scriptbed.rpy:627
translate spanish beddesk_619ec7f4:

    # c "I hear it's hot, firey and incredibly painful just being there."
    c "He oído que es caliente, ardiente e increíblemente doloroso el hecho de estar allí."

# game/scripts/scriptbed.rpy:628
translate spanish beddesk_7d52763c:

    # c "There's also no catnip."
    c "Tampoco hay catnip."

# game/scripts/scriptbed.rpy:631
translate spanish beddesk_9f2730bb:

    # o "I-is that bad?"
    o "¿E-eso es malo?"

# game/scripts/scriptbed.rpy:634
translate spanish beddesk_014d0311:

    # c "Very."
    c "Muy."

# game/scripts/scriptbed.rpy:647
translate spanish bedcircle_b933f303:

    # o "I hope Sparky knows how to use magic..."
    o "Espero que Sparky sepa usar magia..."

# game/scripts/scriptbed.rpy:652
translate spanish bedcircle_8da1ecff:

    # c "The most a dog like him could do is start a small fire."
    c "Lo máximo que podría hacer un perro como él es iniciar un pequeño fuego."

# game/scripts/scriptbed.rpy:654
translate spanish bedcircle_0640c161:

    # c "Which would be enough to open a portal if he drew the circle correctly but I don't think we should take a chance on that."
    c "Lo cual sería suficiente para abrir un portal si dibujara el círculo correctamente, pero no creo que debamos arriesgarnos con eso."

# game/scripts/scriptbed.rpy:656
translate spanish bedcircle_738dc8c2:

    # c "One wrong move and he'll burst into flames."
    c "Un movimiento en falso y estallará."

# game/scripts/scriptbed.rpy:663
translate spanish bedcircle_1a342e91:

    # n "There's a magic circle permanently etched into the floor of the room."
    n "Hay un círculo mágico grabado permanentemente en el suelo de la habitación."

# game/scripts/scriptbed.rpy:667
translate spanish bedcircle_1a342e91_1:

    # n "There's a magic circle permanently etched into the floor of the room."
    n "Hay un círculo mágico grabado permanentemente en el suelo de la habitación."

# game/scripts/scriptbed.rpy:669
translate spanish bedcircle_c5eb7b2b:

    # s "I wonder how any of this magic stuff works..."
    s "Me pregunto cómo funciona todo esto de la mágia..."

# game/scripts/scriptbed.rpy:670
translate spanish bedcircle_32a797ff:

    # s "It'd be helpful to know how to use magic, right?"
    s "Sería útil saber cómo usar la magia, ¿verdad?"

# game/scripts/scriptbed.rpy:673
translate spanish bedcircle_7ea62f47:

    # o "Do you want to be a w-witch Sparky?!"
    o "¿Quieres ser un b-brujo Sparky?"

# game/scripts/scriptbed.rpy:676
translate spanish bedcircle_01e6b234:

    # s "EH?!"
    s "¡¿EH?!"

# game/scripts/scriptbed.rpy:678
translate spanish bedcircle_798e86d6:

    # s "I mean, if it meant I could be of more use of course!"
    s "Quiero decir, si eso significara que podría ser más util, ¡por supuesto!"

# game/scripts/scriptbed.rpy:679
translate spanish bedcircle_1ba42046:

    # s "It's not great knowing I was the weakest link..."
    s "No es genial saber que yo era el eslabón más débil..."

# game/scripts/scriptbed.rpy:682
translate spanish bedcircle_72cf4219:

    # o "W-weakest?! But you're s-so tall and cool and-"
    o "¡¿El más débil?! Pero eres t-tan alto, genial y-"

# game/scripts/scriptbed.rpy:685
translate spanish bedcircle_0bc0c8d5:

    # s "Ahahah thanks Olive, but you know what I mean right?"
    s "Jajaja gracias Olive, pero sabes a lo que me refiero, ¿verdad?"

# game/scripts/scriptbed.rpy:688
translate spanish bedcircle_d1446e31:

    # s "I never want to be possessed again..."
    s "No quiero volver a ser poseído nunca más..."

# game/scripts/scriptbed.rpy:693
translate spanish bedcircle_1a342e91_2:

    # n "There's a magic circle permanently etched into the floor of the room."
    n "Hay un círculo mágico grabado permanentemente en el suelo de la habitación."

# game/scripts/scriptbed.rpy:698
translate spanish bedcircle_23786ca8:

    # n "Coco glares at Olive before they can step any closer to it."
    n "Coco mira a Olive antes de que ellos puedan acercarse mas."

# game/scripts/scriptbed.rpy:702
translate spanish bedcircle_670736ab:

    # n "Coco smiles at Olive!"
    n "¡Coco le sonríe a Olive!"

# game/scripts/scriptbed.rpy:706
translate spanish bedcircle_1a342e91_3:

    # n "There's a magic circle permanently etched into the floor of the room."
    n "Hay un círculo mágico grabado permanentemente en el suelo de la habitación."

# game/scripts/scriptbed.rpy:713
translate spanish bedcircle_faca6df6:

    # o "Wow!! You're really good at d-drawing Coco!"
    o "¡¡Guau!! ¡Eres muy buena dibujando, Coco!"

# game/scripts/scriptbed.rpy:717
translate spanish bedcircle_a62027e6:

    # c "WHAT DID I SAY ABOUT BOTHERING ME WHILE I'M WORKING?!"
    c "¡¿QUÉ DIJE DE MOLESTARME MIENTRAS TRABAJO?!"

# game/scripts/scriptbed.rpy:721
translate spanish bedcircle_49d70ef1:

    # n "Coco pushes Olive into the corner of the room and returns to her work."
    n "Coco empuja a Olive hacia un rincón de la habitación y vuelve a su trabajo."

# game/scripts/scriptbed.rpy:728
translate spanish bedcircle_33f1d1bb:

    # n "Olive looks at the circle from afar. Their tail wags."----
    n "Olive mira el círculo desde lejos. Ella menea la cola."

# game/scripts/scriptbed.rpy:731
translate spanish bedcircle_6113f989:

    # n "Coco nods approvingly."
    n "Coco asiente con aprobación."

# game/scripts/scriptbed.rpy:740
translate spanish bedwindow_10ebd0c5:

    # o "I w-wonder how far into the forest Sparky is right now..."
    o "Me pregunto qué tan lejos estará Sparky en el bosque en este momento..."

# game/scripts/scriptbed.rpy:749
translate spanish bedwindow_2dfb9ef6:

    # o "The zombies look like they're having s-so much fun!!"
    o "¡¡Parece que los zombies se están divirtiendo muchísimo!!"

# game/scripts/scriptbed.rpy:756
translate spanish bedwindow_4c0548d0:

    # o "I wish the z-zombies could come in and have a t-tea party..."
    o "Ojalá los z-zombies pudieran entrar y tener una fiesta de té..."

# game/scripts/scriptbed.rpy:763
translate spanish bedcoco_9607f8ee:

    # o "I think I've bothered her e-enough."
    o "Creo que ya la molesto bastante."

# game/scripts/scriptbed.rpy:773
translate spanish bedcoco_96e930d9:

    # o "Coco!! I like your r-room!"
    o "¡¡Coco!! ¡Me gusta tu h-habitación!"

# game/scripts/scriptbed.rpy:777
translate spanish bedcoco_602ecba8:

    # c "AUGHH what did I say about bothering me?!?"
    c "AUGHH ¿¡¿Qué dije sobre molestarme?!?"

# game/scripts/scriptbed.rpy:780
translate spanish bedcoco_91f583dc:

    # n "Olive whimpers in fear."
    n "Olive gime de miedo."

# game/scripts/scriptbed.rpy:782
translate spanish bedcoco_e5edbe26:

    # n "Coco sighs."
    n "Coco suspira."

# game/scripts/scriptbed.rpy:784
translate spanish bedcoco_5cfcc1dd:

    # c "Sorry Olive I just need the utmost focus if I'm going to fix this mess!!"
    c "Lo siento, Olive, ¡solo necesito la máxima concentración si quiero arreglar este desastre!"

# game/scripts/scriptbed.rpy:788
translate spanish bedcoco_ecf1952c:

    # n "Olive stares at Coco."
    n "Olive mira fijamente a Coco."

# game/scripts/scriptbed.rpy:789
translate spanish bedcoco_62157099:

    # n "Coco is focused on her work."
    n "Coco está concentrada en su trabajo."

# game/scripts/scriptbed.rpy:790
translate spanish bedcoco_7851a32d:

    # n "Olive continues staring."
    n "Olive continúa mirando."

# game/scripts/scriptbed.rpy:792
translate spanish bedcoco_3270baef:

    # n "Coco notices them from the sound of their tail wagging."
    n "Coco los nota por el sonido de su cola moviendo."

# game/scripts/scriptbed.rpy:794
translate spanish bedcoco_1e3b2765:

    # c "What."
    c "Qué."

# game/scripts/scriptbed.rpy:796
translate spanish bedcoco_b83809cb:

    # n "Olive remains silent aside from their tail."
    n "Olive permanece en silencio aparte de su cola."

# game/scripts/scriptbed.rpy:798
translate spanish bedcoco_c3de668a:

    # c "WHAT."
    c "QUÉ."

# game/scripts/scriptbed.rpy:800
translate spanish bedcoco_07abc845:

    # o "..."
    o "..."

# game/scripts/scriptbed.rpy:803
translate spanish bedcoco_b757adda:

    # c "OLIVE! WHAT!! WHAT DO YOU WANT!!! HOLY CATS!!" with vpunch
    c "¡OLIVE! ¡¿QUÉ?! ¡¿QUÉ QUIERES?! ¡SANTOS GATOS!" with vpunch

# game/scripts/scriptbed.rpy:806
translate spanish bedcoco_745e2fa9:

    # o "Y-you said not to bother you. I'm n-not bothering you r-right?"
    o "D-dijiste que no te molestara. No te estoy molestando ¿v-verdad?"

# game/scripts/scriptbed.rpy:809
translate spanish bedcoco_97849296:

    # c "Oh. I guess not."
    c "Oh. Supongo que no."

# game/scripts/scriptbed.rpy:813
translate spanish bedcoco_2aad30e2:

    # c "Thanks for actually listening!"
    c "¡Gracias por escuchar!"

# game/scripts/scriptbed.rpy:815
translate spanish bedcoco_d41431e4:

    # c "Even if we're not chatting it's nice having company while I work!"
    c "Incluso si no estamos charlando, ¡es agradable tener compañía mientras trabajo!"

# game/scripts/scriptbed.rpy:818
translate spanish bedcoco_7f0d030e:

    # o "It m-must be a lot of work. I wish I could help someh-how."
    o "Debe ser mucho trabajo. Ojalá pudiera ayudar de alguna manera."

# game/scripts/scriptbed.rpy:821
translate spanish bedcoco_38778fc9:

    # c "This is something only I can do, but even if you were some kinda all-powerful sorcerer I don't think I'd want your help."
    c "Esto es algo que sólo yo puedo hacer, pero incluso si fueras un hechicero todopoderoso no creo que querría tu ayuda."

# game/scripts/scriptbed.rpy:823
translate spanish bedcoco_ee235463:

    # c "This is my fault. I need to fix it!"
    c "Esto es mi culpa. ¡Necesito arreglarlo!"

# game/scripts/scriptbed.rpy:825
translate spanish bedcoco_66fedf94:

    # c "I'm just stumped on how to go about it."
    c "Simplemente no sé cómo hacerlo."

# game/scripts/scriptbed.rpy:828
translate spanish bedcoco_e07f3030:

    # o "W-want to talk about it?"
    o "¿Quieres hablar de ello?"

# game/scripts/scriptbed.rpy:831
translate spanish bedcoco_10829ec9:

    # c "Ugh."
    c "Ugh."

# game/scripts/scriptbed.rpy:833
translate spanish bedcoco_9a737767:

    # c "See, I could just wipe them all out but that feels kind of wrong."
    c "Mira, podría simplemente borrarlos a todos, pero eso me parece un poco mal."

# game/scripts/scriptbed.rpy:834
translate spanish bedcoco_b1dc6dba:

    # c "Alternatively I was thinking..."
    c "Alternativamente estaba pensando..."

# game/scripts/scriptbed.rpy:836
translate spanish bedcoco_8dc924bf:

    # c "I owe you one birthday wish. I predicted that your wish was for every dog that died at Hachiko High to come back to life."
    c "Te debo un deseo de cumpleaños. Predije que tu deseo era que cada perro que murió en el instituto Hachiko volviera a la vida."

# game/scripts/scriptbed.rpy:839
translate spanish bedcoco_d31c3c98:

    # o "W-W-WOW!! I didn't even think of a wish but now that you s-say that I would LOVE for them all to come to my birthday party!!"
    o "W-W-WOW!! ¡¡Ni siquiera pensé en un deseo pero ahora que dices que me ENCANTARÍA que todos vinieran a mi fiesta de cumpleaños!!"

# game/scripts/scriptbed.rpy:840
translate spanish bedcoco_4db34748:

    # o "So you brought all these z-zombies back to life for me?!"
    o "¿Así que devolveras a la vida a todos estos z-zombis para mi?"

# game/scripts/scriptbed.rpy:843
translate spanish bedcoco_d259ecdd:

    # c "No they came back on their own!! Well, they came back halfway. They're still undead."
    c "¡¡No, ellos regresaron solos!! Bueno, regresaron a mitad de camino. Todavía no estan muertos."

# game/scripts/scriptbed.rpy:845
translate spanish bedcoco_9da38633:

    # c "I can't figure out how they came back let alone how to get them back to their normal selves. Healing requires a lot of magic and a lot of focus."
    c "No puedo entender cómo regresaron y mucho menos cómo hacer que vuelvan a su estado normal. La curación requiere mucha magia y mucha concentración."

# game/scripts/scriptbed.rpy:847
translate spanish bedcoco_5b16b0d5:

    # c "Every second I waste is a second where something could go terribly wrong."
    c "Cada segundo que pierdo es un segundo en el que algo podría salir terriblemente mal."

# game/scripts/scriptbed.rpy:850
translate spanish bedcoco_cb98e54d:

    # o "Oh! I-I'll leave you to it then!"
    o "¡Oh! ¡Entonces te dejo con eso!"

# game/scripts/scriptbed.rpy:851
translate spanish bedcoco_64a1ffed:

    # o "If they knew how hard you were working I b-bet they'd really appreciate it!!"
    o "¡Si supieran lo duro que estás trabajando, apuesto a que realmente lo apreciarían!"

# game/scripts/scriptbed.rpy:854
translate spanish bedcoco_19dde1db:

    # c "Thanks Olive! Even though you're a total pain in the neck I'm glad you came to visit me!"
    c "¡Gracias Olive! Aunque eres un verdadero dolor de cabeza, ¡me alegra que hayas venido a visitarme!"

# game/scripts/scriptbed.rpy:866
translate spanish gameover01_ecf74c66:

    # o "P-please Sparky!! W-W-WAKE UP!!"
    o "¡¡P-por favor Sparky!! ¡¡DESPIERTA!!"

# game/scripts/scriptbed.rpy:869
translate spanish gameover01_e9dc7e90:

    # n "Olive is backed up against a wall..."
    n "Olive está apoyada contra una pared..."

# game/scripts/scriptbed.rpy:871
translate spanish gameover01_21f547a8:

    # o "We're f-furiends! You're just tired, you don't want to hurt anyone!"
    o "¡Somos a-amigos! ¡Simplemente estás cansado, no quieres lastimar a nadie!"

# game/scripts/scriptbed.rpy:874
translate spanish gameover01_4868356e:

    # se "..."
    se "..."

# game/scripts/scriptbed.rpy:876
translate spanish gameover01_d0700e89:

    # o "I-I just think you'll be really really s-sad when you wake up and find out you've hurt everyone!!"
    o "¡¡Sólo creo que estarás realmente muy triste cuando te despiertes y descubras que has lastimado a todos!!"

# game/scripts/scriptbed.rpy:879
translate spanish gameover01_4868356e_1:

    # se "..."
    se "..."

# game/scripts/scriptbed.rpy:886
translate spanish gameover01_3862b8f7:

    # n "A zombie cat appears out of the shadows!"
    n "¡Un gato zombie aparece entre las sombras!"

# game/scripts/scriptbed.rpy:888
translate spanish gameover01_e6fe20ae:

    # pu "Ginger! What are you doing just standing there?!"
    pu "¡Ginger! ¡¿Qué haces ahí parado?!"

# game/scripts/scriptbed.rpy:890
translate spanish gameover01_d145ecf3:

    # pu "I didn't tranquilize the threat for nothing, right?"
    pu "No tranquilicé a la amenaza por nada, ¿verdad?"

# game/scripts/scriptbed.rpy:892
translate spanish gameover01_c47eaba4:

    # sg "..."
    sg "..."

# game/scripts/scriptbed.rpy:894
translate spanish gameover01_4f0c980e:

    # n "Sparky takes one step towards the undead cat."
    n "Sparky da un paso hacia el gato zombie."

# game/scripts/scriptbed.rpy:896
translate spanish gameover01_1e9b3e1f:

    # pu "Ginger?"
    pu "¿Ginger?"

# game/scripts/scriptbed.rpy:899
translate spanish gameover01_26e116e4:

    # n "The cat is grabbed by the throat!" with vpunch
    n "¡El gato está agarrado por la garganta!" with vpunch

# game/scripts/scriptbed.rpy:901
translate spanish gameover01_14e46bb8:

    # pu "ACK!!"
    pu "¡¡ACK!!"

# game/scripts/scriptbed.rpy:904
translate spanish gameover01_0c425a2a:

    # n "Sparky tears his head straight off!" with vpunch
    n "¡Sparky se arranca la cabeza!" with vpunch

# game/scripts/scriptbed.rpy:907
translate spanish gameover01_5cc264a3:

    # o "AHHH!!" with vpunch
    o "¡¡AHHH!!" with vpunch

# game/scripts/scriptbed.rpy:909
translate spanish gameover01_c47eaba4_1:

    # sg "..."
    sg "..."

# game/scripts/scriptbed.rpy:911
translate spanish gameover01_436451cd:

    # sg "... Why isn't it stopping."
    sg "... ¿Por qué no se detiene?"

# game/scripts/scriptbed.rpy:912
translate spanish gameover01_aea2a1c5:

    # sg "I still hear her..."
    sg "Todavía la escucho..."

# game/scripts/scriptbed.rpy:914
translate spanish gameover01_4a9762a3:

    # sg "I'm too tired..."
    sg "Estoy demasiado cansado..."

# game/scripts/scriptbed.rpy:915
translate spanish gameover01_8241fe5a:

    # sg "To fight anymore..."
    sg "Para luchar más..."

# game/scripts/scriptbed.rpy:920
translate spanish gameover01_dc216a96:

    # n "Sparky hugs Olive tightly."
    n "Sparky abraza fuertemente a Olive."

# game/scripts/scriptbed.rpy:922
translate spanish gameover01_619244b7:

    # n "His arms find their way around their neck."
    n "Sus brazos encuentran su camino alrededor de su cuello."

# game/scripts/scriptbed.rpy:925
translate spanish gameover01_72c4336f:

    # n "With one quick snap everything goes dark." with vpunch
    n "Con un chasquido rápido todo se oscurece." with vpunch

# game/scripts/scriptbed.rpy:947
translate spanish gameover01_9b94a7fc:

    # o "P-please whoever you are now!"
    o "¡P-por favor quienquiera que seas ahora!"

# game/scripts/scriptbed.rpy:948
translate spanish gameover01_67aae31f:

    # o "I-I don't know why you're doing this..."
    o "N-no sé por qué estás haciendo esto..."

# game/scripts/scriptbed.rpy:951
translate spanish gameover01_e9dc7e90_1:

    # n "Olive is backed up against a wall..."
    n "Olive está apoyada contra una pared..."

# game/scripts/scriptbed.rpy:953
translate spanish gameover01_5691181c:

    # o "Th-there's got to be a reas-"
    o "Tiene que haber una razon-"

# game/scripts/scriptbed.rpy:955
translate spanish gameover01_6c58613c:

    # n "Sparky grabs Olive's lower jaw in one paw, and the top half of their head with the other." with vpunch
    n "Sparky agarra la mandíbula inferior de Olive con una pata y la mitad superior de su cabeza con la otra." with vpunch

# game/scripts/scriptbed.rpy:957
translate spanish gameover01_31b67a97:

    # n "They paw at his arms and struggle to get out of his grip."
    n "Ella le apoya las patas en los brazos y lucha por soltarse."

# game/scripts/scriptbed.rpy:959
translate spanish gameover01_9cbf6020:

    # se "This pathetic dog..."
    se "Esta perra patética..."

# game/scripts/scriptbed.rpy:960
translate spanish gameover01_d5d8d9f8:

    # se "Is really one of the pests that hurt you?"
    se "¿Es realmente una de las plagas que te hace daño?"

# game/scripts/scriptbed.rpy:963
translate spanish gameover01_4770ac22:

    # o "?!"
    o "¡¿?!"

# game/scripts/scriptbed.rpy:970
translate spanish gameover01_3862b8f7_1:

    # n "A zombie cat appears out of the shadows!"
    n "¡Un gato zombie aparece entre las sombras!"

# game/scripts/scriptbed.rpy:972
translate spanish gameover01_b49c36b9:

    # pu "Yes! They and their friends killed every dog at Hachiko High."
    pu "¡Sí! Ella y sus amigos mataron a todos los perros en el instituto Hachiko."

# game/scripts/scriptbed.rpy:973
translate spanish gameover01_bee4503b:

    # pu "They even stole my body!"
    pu "¡Hasta me robaron mi cuerpo!"

# game/scripts/scriptbed.rpy:976
translate spanish gameover01_46b5a856:

    # se "Then it only makes sense to take theirs as a toll."
    se "Entonces lo logico es que ellos paguen."

# game/scripts/scriptbed.rpy:979
translate spanish gameover01_9276dfcc:

    # n "The cat gives Sparky a big hug."
    n "El gato le da un gran abrazo a Sparky."

# game/scripts/scriptbed.rpy:982
translate spanish gameover01_903c76c5:

    # n "Sparky strengthens his grip on Olives face,"
    n "Sparky fortalece su agarre en la cara de Olive."

# game/scripts/scriptbed.rpy:985
translate spanish gameover01_51097334:

    # n "And tears their jaws apart!" with vpunch
    n "¡Y le destroza la mandíbula!" with vpunch

# game/scripts/scriptbed.rpy:999
translate spanish gameover02_da8f1595:

    # n "Olive grabs at the magical wires binding Angel!"
    n "¡Olive agarra los cables mágicos que atan a Angel!"

# game/scripts/scriptbed.rpy:1000
translate spanish gameover02_bf983143:

    # n "They claw and bite but the wires won't come undone!"
    n "¡Arañan y muerden, pero los cables no se deshacen!"

# game/scripts/scriptbed.rpy:1002
translate spanish gameover02_d2935505:

    # pu "Aww you're cute, the way a rat is cute."
    pu "Oh, eres linda, eres una linda una rata."

# game/scripts/scriptbed.rpy:1003
translate spanish gameover02_6c39be3a:

    # pu "Hmm that gives me an idea..."
    pu "Mmmm eso me da una idea..."

# game/scripts/scriptbed.rpy:1005
translate spanish gameover02_67712662:

    # pu "Let's dissect you!"
    pu "¡Vamos a disecarte!"

# game/scripts/scriptbed.rpy:1009
translate spanish gameover02_c9775d50:

    # n "Olive jumps on the cat! The wand is knocked out of his paws." with vpunch
    n "¡Olive salta sobre el gato! ¡Le quita la varita de las patas!" with vpunch

# game/scripts/scriptbed.rpy:1011
translate spanish gameover02_2a107734:

    # n "The magic, now under no one's control, releases Angel!"
    n "¡La magia, ahora bajo sin control de nadie, libera a Angel!"

# game/scripts/scriptbed.rpy:1013
translate spanish gameover02_2c34077e:

    # n "He immediately pounces for the wand!"
    n "¡Inmediatamente se lanza hacia la varita!"

# game/scripts/scriptbed.rpy:1015
translate spanish gameover02_cea1a2c3:

    # pu "AUGH YOU DISGUSTING MUTTS!"
    pu "¡AUGH, TU CUCHO ASQUEROSO!"

# game/scripts/scriptbed.rpy:1016
translate spanish gameover02_a08e9d14:

    # pu "GINGER!"
    pu "¡GINGER!"

# game/scripts/scriptbed.rpy:1021
translate spanish gameover02_c281abbf:

    # n "Sparky, or... Ginger, grabs Olive and throws them onto Angel!" with vpunch
    n "¡Sparky, o... Ginger, agarra a Olive y la lanza hacia Angel!" with vpunch

# game/scripts/scriptbed.rpy:1024
translate spanish gameover02_97931c5a:

    # n "Angel sends a flash of blue light at Ginger!" with vpunch
    n "¡Angel envía un destello de luz azul a Ginger!" with vpunch

# game/scripts/scriptbed.rpy:1030
translate spanish gameover02_2d12a7c5:

    # sg "ACK!!"
    sg "¡¡ACK!!"

# game/scripts/scriptbed.rpy:1032
translate spanish gameover02_315399aa:

    # a "!!!" with vpunch
    a "!!!" with vpunch

# game/scripts/scriptbed.rpy:1034
translate spanish gameover02_8dfc3543:

    # a "O-OLIVE!"
    a "¡O-OLIVE!"

# game/scripts/scriptbed.rpy:1037
translate spanish gameover02_7fa33022:

    # o "HNNG!! I-it hurts!!"
    o "¡¡HNNG!! ¡¡Duele!!"

# game/scripts/scriptbed.rpy:1040
translate spanish gameover02_65f2fd34:

    # pu "AHAHAHAHAH!!"
    pu "¡¡AJAJAJAJAJA!!"

# game/scripts/scriptbed.rpy:1043
translate spanish gameover02_248b9c91:

    # n "The cat just keeps laughing."
    n "El gato sigue riendo."

# game/scripts/scriptbed.rpy:1046
translate spanish gameover02_416b69be:

    # n "The sound gets quieter and quieter."
    n "El sonido se vuelve cada vez más silencioso."

# game/scripts/scriptbed.rpy:1049
translate spanish gameover02_e7e75983:

    # n "Until it all fades away."
    n "Hasta que todo se desvanezca."

# game/scripts/scriptbed.rpy:1071
translate spanish gameover02_a479d0e2:

    # o "I-I'M SORRY!!"
    o "¡¡LO-LO SIENTO!!"

# game/scripts/scriptbed.rpy:1074
translate spanish gameover02_3f517678:

    # n "Olive dashes for the door!"
    n "¡Olive corre hacia la puerta!"

# game/scripts/scriptbed.rpy:1076
translate spanish gameover02_6c77ba4a:

    # pu "AHAHAH so you chose this cowardly dog as your new companion huh?"
    pu "AHAHAH entonces elegiste a este perro cobarde como tu nuevo compañero ¿eh?"

# game/scripts/scriptbed.rpy:1078
translate spanish gameover02_31395818:

    # pu "Sparky, you're free to do whatever you want with his friend as long as you make it last!"
    pu "Sparky, ¡eres libre de hacer lo que quieras con su amigo siempre y cuando lo hagas durar!"

# game/scripts/scriptbed.rpy:1087
translate spanish gameover02_1cecef4c:

    # o "AHH!! NO P-PLEASE SPARKY!!"
    o "¡¡AH!! ¡¡NO P-POR FAVOR SPARKY!!"

# game/scripts/scriptbed.rpy:1090
translate spanish gameover02_c671354b:

    # n "Olive's paws rattle on the doorknob but it won't budge!"
    n "Las patas de Olive sacude la manija de la puerta, ¡pero no se mueve!"

# game/scripts/scriptbed.rpy:1091
translate spanish gameover02_9c235a2d:

    # n "It seems to be magically sealed."
    n "Parece estar sellado mágicamente."

# game/scripts/scriptbed.rpy:1097
translate spanish gameover02_8a3a002e:

    # n "His paw slams against the door, trapping them." with vpunch
    n "Su pata se estrella contra la puerta, atrapándolas." with vpunch

# game/scripts/scriptbed.rpy:1099
translate spanish gameover02_d688ff30:

    # o "Please, I-I don't know why you're doing this o-or who you are now."
    o "Por favor, no sé por qué estás haciendo esto o siquiera quién eres ahora."

# game/scripts/scriptbed.rpy:1101
translate spanish gameover02_6f3c7010:

    # n "Sparky grabs Olive's arm, twisting it into an unnatural position." with vpunch
    n "Sparky agarra el brazo de Olive, girándolo en una posición antinatural." with vpunch

# game/scripts/scriptbed.rpy:1103
translate spanish gameover02_32c4b525:

    # o "AHHH j-j-just tell us what you want! WE CAN HELP YOU!!"
    o "¡AHHH s-s-solo dinos lo que quieres! ¡¡PODEMOS AYUDARTE!!"

# game/scripts/scriptbed.rpy:1106
translate spanish gameover02_0050d83f:

    # se "I already have everything I want."
    se "Ya tengo todo lo que quiero."

# game/scripts/scriptbed.rpy:1110
translate spanish gameover02_88a566ba:

    # n "Sparky snaps Olive's arm like a twig." with vpunch
    n "Sparky rompe el brazo de Olive como si fuera una ramita." with vpunch

# game/scripts/scriptbed.rpy:1111
translate spanish gameover02_40e3eb1d:

    # n "They howl with pain,"
    n "Ella aúlla del dolor,"

# game/scripts/scriptbed.rpy:1115
translate spanish gameover02_3311a5cb:

    # n "And do so for every bone in their arms," with vpunch
    n "Sparky le rompe el brazo a Olive como si fuera una ramita. Y hace lo mismo con cada hueso de sus brazos," with vpunch

# game/scripts/scriptbed.rpy:1119
translate spanish gameover02_ebcd4aaf:

    # n "And then their legs," with vpunch
    n "Y luego sus piernas" with vpunch

# game/scripts/scriptbed.rpy:1123
translate spanish gameover02_69c53837:

    # n "Until they're completely crushed." with vpunch
    n "Hasta que estén completamente aplastadas." with vpunch

# game/scripts/scriptbed.rpy:1138
translate spanish gameover0601_103a077f:

    # n "They slam the door!" with vpunch
    n "Ellas cierran la puerta!" with vpunch

# game/scripts/scriptbed.rpy:1144
translate spanish gameover0601_ae1133d3:

    # n "With knives, magic and zombies on the other side it breaks open pretty quickly." with vpunch
    n "Con cuchillos, magia y zombies en el otro lado, se abre bastante rápido." with vpunch

# game/scripts/scriptbed.rpy:1146
translate spanish gameover0601_11c1f558:

    # o "AHH NO!!"
    o "AHH NO!!"

# game/scripts/scriptbed.rpy:1149
translate spanish gameover0601_9ec7bffe:

    # p "Here's Patches!"
    p "¡Aquí está patches!"

# game/scripts/scriptbed.rpy:1153
translate spanish gameover0601_e67fe92d:

    # n "Olive backs up to the other side of the room."
    n "Olive retrocede hasta el otro lado de la habitación."

# game/scripts/scriptbed.rpy:1154
translate spanish gameover0601_66f08c1d:

    # n "They end up against the window."
    n "Terminan contra la ventana."

# game/scripts/scriptbed.rpy:1163
translate spanish gameover0602_3ff07f64:

    # n "Coco is happily sitting in the tree as planned!"
    n "¡Coco está felizmente sentada en el árbol como estaba planeado!"

# game/scripts/scriptbed.rpy:1165
translate spanish gameover0602_dab2fd97:

    # o "Coco!!"
    o "¡¡Coco!!"

# game/scripts/scriptbed.rpy:1167
translate spanish gameover0602_98f5de7d:

    # n "Olive quickly pushes the window open!"
    n "¡Olive rápidamente abre la ventana!"

# game/scripts/scriptbed.rpy:1169
translate spanish gameover0602_6528fbec:

    # o "COCO! YOU'RE OKAY!!"
    o "¡COCO! ¡¡ESTÁS BIEN!!"

# game/scripts/scriptbed.rpy:1171
translate spanish gameover0602_0f5b10d3:

    # c "OLIVE!! IT WORKED!"
    c "¡¡OLIVE!! ¡FUNCIONÓ!"

# game/scripts/scriptbed.rpy:1172
translate spanish gameover0602_97f64b43:

    # c "I TOLD YA-"
    c "TE LO DIJE-"

# game/scripts/scriptbed.rpy:1176
translate spanish gameover0602_1271e340:

    # n "A knife pierces Olive's throat!" with vpunch
    n "¡Un cuchillo atraviesa la garganta de Olive!" with vpunch

# game/scripts/scriptbed.rpy:1177
translate spanish gameover0602_cf5ecdce:

    # c "O-OLIVE?!"
    c "¡¿O-OLIVE?!"

# game/scripts/scriptbed.rpy:1179
translate spanish gameover0602_8edbf2e0:

    # "" with vpunch
    "" with vpunch

# game/scripts/scriptbed.rpy:1182
translate spanish gameover0602_e176fb36:

    # n "Patches leans out of the window over Olive's dead body."
    n "Patches se asoma por la ventana pisando el cadáver de Olive."

# game/scripts/scriptbed.rpy:1184
translate spanish gameover0602_58bdab51:

    # p "Aww little kitty's stuck in a tree?"
    p "¿Aww pequeño gatito atrapado en el árbol?"

# game/scripts/scriptbed.rpy:1186
translate spanish gameover0602_12401d77:

    # p "I'll help cut you down!"
    p "¡Te ayudaré cortar!"

# game/scripts/scriptbed.rpy:1190
translate spanish gameover0602_27498883:

    # n "Before Patches can send a burst of magic Coco dashes off the tree into another, and then another."
    n "Antes de que Patches pueda enviar una ráfaga de magia, Coco sale corriendo del árbol hacia otro, y luego hacia otro."

# game/scripts/scriptbed.rpy:1192
translate spanish gameover0602_8feb57de:

    # n "She's gone in the blink of an eye."
    n "Ella se fue en un abrir y cerrar de ojos."

# game/scripts/scriptbed.rpy:1195
translate spanish gameover0602_cd1f2137:

    # p "Well, 4 out of 5 is still pretty good."
    p "Bueno, 4 de 5 sigue siendo bastante bueno."

# game/scripts/scriptbed.rpy:1220
translate spanish gameover0602_85bef4b6:

    # o "Coco?!"
    o "¡¿Coco?!"

# game/scripts/scriptbed.rpy:1223
translate spanish gameover0602_6648d7f5:

    # p "Yikes. I think she's still twitching!!"
    p "Vaya. ¡¡Creo que ella todavía está temblando!!"

# game/scripts/scriptbed.rpy:1226
translate spanish gameover0602_fb74db35:

    # o "N-N-NOOoOoOoOo!!"
    o "¡¡N-N-NOOoOoOoOo!!"

# game/scripts/scriptbed.rpy:1229
translate spanish gameover0602_7833e82e:

    # p "Those zombies are good for something after all!"
    p "¡Esos zombies sirven para algo después de todo!"

# game/scripts/scriptbed.rpy:1232
translate spanish gameover0602_1cb5c232:

    # p "Maybe I should let them have a go at you!"
    p "¡Quizás debería dejar que te ataquen!"

# game/scripts/scriptbed.rpy:1235
translate spanish gameover0602_6a0172c0:

    # o "W-WHAT?!"
    o "¡¿Q-QUÉ?!"

# game/scripts/scriptbed.rpy:1238
translate spanish gameover0602_4cac5e81:

    # p "FEEDING TIME PUPPIES!"
    p "¡HORA DE ALIMENTAR A LOS CACHORROS!"

# game/scripts/scriptbed.rpy:1242
translate spanish gameover0602_c11f60fd:

    # n "Zombies stream into the room!"
    n "¡Los zombis entran en la habitación!"

# game/scripts/scriptbed.rpy:1244
translate spanish gameover0602_c2175868:

    # o "NOoOoOo!!"
    o "¡¡NOoOoOo!!"

# game/scripts/scriptbed.rpy:1247
translate spanish gameover0602_8b6496cc:

    # n "The zombies tear into Olive's flesh." with vpunch
    n "Los zombies desgarran la carne de Olive." with vpunch

# game/scripts/scriptbed.rpy:1250
translate spanish gameover0602_46ae18bc:

    # p "Hehehehe!!" with vpunch
    p "Jejejeje!!" with vpunch

# game/scripts/scriptbed.rpy:1252
translate spanish gameover0602_be37161c:

    # p "5 out of 5."
    p "5 de 5."

# game/scripts/scriptbed.rpy:1280
translate spanish bedyesscream_7a00c044:

    # n "Olive and their friends find Coco in a tussle with a zombie!!"
    n "¡Olive y sus amigos encuentran a Coco peleando con un zombie!"

# game/scripts/scriptbed.rpy:1282
translate spanish bedyesscream_3508243a:

    # c "AUGH!! GET OFF ME YOU UNDEAD BASTARD!!" with vpunch
    c "¡¡¡AUGH!!! ¡¡¡QUÍTATE DE MÍ, BASTARDO!!!" with vpunch

# game/scripts/scriptbed.rpy:1285
translate spanish bedyesscream_4a2001a2:

    # pu "Huh?! Angel is that you?!"
    pu "¡¿Eh?! Angel eres tú?!"

# game/scripts/scriptbed.rpy:1286
translate spanish bedyesscream_3f2ab58c:

    # pu "And you brought everyone, fantastic!"
    pu "Y trajiste a todos, ¡fantástico!"

# game/scripts/scriptbed.rpy:1289
translate spanish bedyesscream_83134fc6:

    # a "GET AWAY FROM HER!!!"
    a "¡¡¡ALEJATE DE ELLA!!!"

# game/scripts/scriptbed.rpy:1292
translate spanish bedyesscream_944d9006:

    # pu "Or wha-"
    pu "¿O qué-?"

# game/scripts/scriptbed.rpy:1305
translate spanish bedyesscream_96545ed1:

    # n "Sparky pins Angel's undead body to the ground." with vpunch
    n "Sparky inmoviliza el cuerpo zombie de Angel contra el suelo." with vpunch

# game/scripts/scriptbed.rpy:1306
translate spanish bedyesscream_54ffd193:

    # n "He holds a fist threateningly above them."
    n "Sostiene un puño amenazador por encima de el."

# game/scripts/scriptbed.rpy:1308
translate spanish bedyesscream_a23d33c6:

    # s "You're behind all this aren't you?!"
    s "Tú estás detrás de todo esto, ¿no?"

# game/scripts/scriptbed.rpy:1311
translate spanish bedyesscream_cad6c1e2:

    # pu "WHOA wait wait wait Sparky!"
    pu "¡EH Espera, espera, espera, Sparky!"

# game/scripts/scriptbed.rpy:1312
translate spanish bedyesscream_27df51f5:

    # pu "This isn't you! You're not a violent dog!!"
    pu "¡Este no eres tú! ¡¡No eres un perro violento!!"

# game/scripts/scriptbed.rpy:1315
translate spanish bedyesscream_811ec47d:

    # pu "P-please don't hurt me! I just wanted Coco to fix this body so I could go back to being alive!"
    pu "¡P-por favor no me hagas daño! ¡Solo quería que Coco arreglara este cuerpo para volver a estar vivo!"

# game/scripts/scriptbed.rpy:1318
translate spanish bedyesscream_c9d2b18b:

    # s "R-really?"
    s "¿E-en serio?"

# game/scripts/scriptbed.rpy:1321
translate spanish bedyesscream_386701b8:

    # n "Sparky suddenly jolts in pain." with vpunch
    n "De repente Sparky sobresalta del dolor." with vpunch

# game/scripts/scriptbed.rpy:1323
translate spanish bedyesscream_f123af81:

    # n "He falls over, knocked out cold." with vpunch
    n "Se desploma y queda inconsciente." with vpunch

# game/scripts/scriptbed.rpy:1325
translate spanish bedyesscream_cc230738:

    # n "Angel's dead body holds up a syringe and ''winks'' at the others."
    n "El cadáver de Angel sostiene una jeringa y ''guiña'' a los demás."

# game/scripts/scriptbed.rpy:1332
translate spanish bedyesscream_9676515c:

    # b "WHAT?! What the hell is that?!"
    b "¡¿QUÉ?! ¡¿Qué diablos es eso?!"

# game/scripts/scriptbed.rpy:1335
translate spanish bedyesscream_79f98c68:

    # o "SPARKY!!"
    o "¡¡SPARKY!!"

# game/scripts/scriptbed.rpy:1338
translate spanish bedyesscream_7736a414:

    # n "Olive runs to Sparky and tries to shake him awake."
    n "Olive corre hacia Sparky y trata de despertarlo."

# game/scripts/scriptbed.rpy:1340
translate spanish bedyesscream_6e4ee123:

    # pu "HEHEHEH!"
    pu "¡JEJEJE!"

# game/scripts/scriptbed.rpy:1342
translate spanish bedyesscream_37ac0374:

    # pu "Hmm what's this?"
    pu "Mmmm ¿qué es esto?"

# game/scripts/scriptbed.rpy:1348
translate spanish bedyesscream_4bf55d98:

    # c "W-WHAT?! WHEN?!"
    c "¡¿Q-QUÉ?! ¡¿CUANDO?!"

# game/scripts/scriptbed.rpy:1350
translate spanish bedyesscream_8e830dee:

    # c "GIVE IT BACK!!"
    c "¡¡DEVUELVELO!!"

# game/scripts/scriptbed.rpy:1352
translate spanish bedyesscream_8eee6d4a:

    # n "Coco runs towards Angel's undead body,"
    n "Coco corre hacia el cuerpo zombie de Angel."

# game/scripts/scriptbed.rpy:1360
translate spanish bedyesscream_af9f3b8d:

    # n "Only to be sent flying back by a burst of energy from her own wand!" with vpunch
    n "¡Solo para ser enviada volando de regreso por una explosión de energía de su propia varita!" with vpunch

# game/scripts/scriptbed.rpy:1362
translate spanish bedyesscream_aa5e5633:

    # pu "This'll take some getting used to but at least I have all of you to practice on!"
    pu "Me llevará un tiempo acostumbrarme a esto, ¡pero al menos los tengo a todos para practicar!"

# game/scripts/scriptbed.rpy:1367
translate spanish bedyesscream_5d85881f:

    # a "Who are you?!"
    a "¡¿Quién eres?!"

# game/scripts/scriptbed.rpy:1370
translate spanish bedyesscream_e2ded6cf:

    # pu "After all the time we spent together you can't tell who I am?"
    pu "¿Después de todo el tiempo que pasamos juntos no puedes decir quién soy?"

# game/scripts/scriptbed.rpy:1373
translate spanish bedyesscream_fcf90cf7:

    # a "B-but... Patches?"
    a "P-pero... ¿Patches?"

# game/scripts/scriptbed.rpy:1374
translate spanish bedyesscream_98591694:

    # a "I took your body."
    a "Tomé tu cuerpo."

# game/scripts/scriptbed.rpy:1377
translate spanish bedyesscream_85ee3297:

    # p "But you didn't take my soul."
    p "Pero no te tomaste mi alma."

# game/scripts/scriptbed.rpy:1379
translate spanish bedyesscream_af539578:

    # p "Now here I am in your old body! Taking from you what you took from me! Kind of romantic huh?"
    p "¡Ahora aquí estoy en tu viejo cuerpo! ¡Quitándote lo que me quitaste! Algo romántico, ¿eh?"

# game/scripts/scriptbed.rpy:1395
translate spanish bedyesscream_5ae83895:

    # n "Meanwhile... Sparky is lying in Olive's lap."
    n "Mientras tanto... Sparky está acostado en el regazo de Olive."

# game/scripts/scriptbed.rpy:1396
translate spanish bedyesscream_87cbf8dd:

    # n "He's beginning to wake up!"
    n "¡Está empezando a despertar!"

# game/scripts/scriptbed.rpy:1399
translate spanish bedyesscream_8cb263a9:

    # o "Sparky!!"
    o "¡¡Sparky!!"

# game/scripts/scriptbed.rpy:1402
translate spanish bedyesscream_e97da39a:

    # n "He grabs Olive by the throat." with vpunch
    n "Él agarra a Olive por la garganta." with vpunch

# game/scripts/scriptbed.rpy:1404
translate spanish bedyesscream_511da213:

    # o "ACKK!!"
    o "¡¡ACKK!!"

# game/scripts/scriptbed.rpy:1412
translate spanish bedyesscream_4b9ff197:

    # n "Coco tries to knock Sparky out with a textbook." with vpunch
    n "Coco intenta noquear a Sparky con un libro de texto." with vpunch

# game/scripts/scriptbed.rpy:1414
translate spanish bedyesscream_7dd82877:

    # n "But she only manages to break his hold on Olive."
    n "Pero ella sólo logra liberar a Olive."

# game/scripts/scriptbed.rpy:1416
translate spanish bedyesscream_80f0a7ca:

    # c "ENOUGH! RUN!!!"
    c "¡SUFICIENTE! ¡¡¡CORRER!!!"

# game/scripts/scriptbed.rpy:1418
translate spanish bedyesscream_fafcaa21:

    # "{nw}"
    "{nw}"

# game/scripts/scriptbed.rpy:1447
translate spanish bednoscream_a44cecdc:

    # c "HUAHH?!? OLIVE?! How did you get in here?!" with vpunch
    c "¿¡HUAHH!? ¡¿OLIVE?! ¡¿Cómo entraste aquí?!" with vpunch

# game/scripts/scriptbed.rpy:1451
translate spanish bednoscream_48c2bd32:

    # c "HUAHH?!? How did you guys get in here?!"
    c "¿¡¿HUAH?!? ¡¿Cómo llegaron aquí?!"

# game/scripts/scriptbed.rpy:1454
translate spanish bednoscream_11695a57:

    # o "I-I unlocked the door!"
    o "¡Abrí la puerta!"

# game/scripts/scriptbed.rpy:1457
translate spanish bednoscream_03bffa4c:

    # c "What?! B-but I hid all the keys! And in incredibly obscure places!"
    c "¡¿Qué?! ¡P-pero escondí todas las llaves! ¡Y en lugares increíblemente inhóspitos!"

# game/scripts/scriptbed.rpy:1460
translate spanish bednoscream_cec9751a:

    # c "AUGH I guess it'd make sense that a nosy dog like you would find them all."
    c "AUGH Supongo que tendría sentido que una perrita entrometida como tú las encontrara a todas."

# game/scripts/scriptbed.rpy:1462
translate spanish bednoscream_907beb38:

    # c "Well WHATEVER. Since it's your birthday I'll let it slide just this once."
    c "Bueno LO QUE SEA. Como es tu cumpleaños, lo dejaré pasar por esta vez."

# game/scripts/scriptbed.rpy:1465
translate spanish bednoscream_8bcb2aea:

    # o "W-wow!"
    o "¡G-guau!"

# game/scripts/scriptbed.rpy:1468
translate spanish bednoscream_8738be05:

    # c "Feel free to explore but DO NOT bother me while I work!"
    c "¡Siéntete libre de explorar pero NO me molestes mientras trabajo!"

# game/scripts/scriptbed.rpy:1471
translate spanish bednoscream_8bf8461c:

    # o "Okie d-dokie!"
    o "¡Okie d-dokie!"

# game/scripts/scriptbed.rpy:1477
translate spanish bednoscream_3e8955f4:

    # c "AUGH I guess it'd make sense that a bunch of nosy dogs like you would find them all."
    c "AUGH Supongo que tendría sentido que un grupo de perros entrometidos como tú las encontrara a todas."

# game/scripts/scriptbed.rpy:1481
translate spanish bednoscream_235d9f92:

    # a "I... I'm sorry..."
    a "Yo... lo siento..."

# game/scripts/scriptbed.rpy:1484
translate spanish bednoscream_d08ae456:

    # c "ACK!! I mean, n-not you Angel!"
    c "¡¡ACK!! Quiero decir, ¡t-tú no, Angel!"

# game/scripts/scriptbed.rpy:1486
translate spanish bednoscream_9fd9847e:

    # c "I know you're a good kitty on the inside. I'm just cranky because of work!"
    c "Sé que eres un buen gatito por dentro. ¡Estoy de mal humor por el trabajo!"

# game/scripts/scriptbed.rpy:1490
translate spanish bednoscream_de4791b7:

    # a "Aww... Thanks Coco."
    a "Aww... Gracias Coco."

# game/scripts/scriptbed.rpy:1494
translate spanish bednoscream_ac3dd83d:

    # c "NOW GET OUT!"
    c "¡AHORA VAYANSE!"

# game/scripts/scriptbed.rpy:1500
translate spanish bednoscream_d5bb8e18:

    # b "Yeah pretty impressive right Coco?!"
    b "Sí, bastante impresionante, ¿verdad Coco?"

# game/scripts/scriptbed.rpy:1502
translate spanish bednoscream_8884d6f2:

    # b "Maybe we're pretty capable after all! Capable enough to help you out with your work!"
    b "¡Quizás seamos bastante capaces después de todo! ¡Lo suficientemente capaz para ayudarte con tu trabajo!"

# game/scripts/scriptbed.rpy:1504
translate spanish bednoscream_874e061a:

    # n "Brownie works her smooth moves and puts her arm around Coco's shoulder. She gives her a big goofy wink."
    n "Brownie trabaja con movimientos suaves y pasa su brazo alrededor del hombro de Coco. Ella le da un guiño tonto."

# game/scripts/scriptbed.rpy:1506
translate spanish bednoscream_d19f855d:

    # c "..."
    c "..."

# game/scripts/scriptbed.rpy:1508
translate spanish bednoscream_2cd5b7f0:

    # c "GET OUT!"
    c "¡VAYANSE!"

# game/scripts/scriptbed.rpy:1513
translate spanish bednoscream_b034f7d3:

    # c "Whatever, GET OUT!"
    c "Como sea, ¡VAYANSE!"

# game/scripts/scriptbed.rpy:1518
translate spanish bednoscream_1909fb2e:

    # o "WAIT! S-S-Sparky needs your help with his, uhh, sleepwalking!"
    o "¡ESPERA! ¡S-S-Sparky necesita tu ayuda con su, uhh, sonambulismo!"

# game/scripts/scriptbed.rpy:1522
translate spanish bednoscream_2df1ace1:

    # a "Wait, uh... It appears Sparky is under some sort of affliction..."
    a "Espera, eh... Parece que Sparky le pasa algo..."

# game/scripts/scriptbed.rpy:1523
translate spanish bednoscream_297b5337:

    # a "It could just be sleepwalking, but we thought it'd be safer if we had you confirm it wasn't something more..."
    a "Podría ser simplemente sonambulismo, pero pensamos que sería más seguro si confirmáramos que no es algo más..."

# game/scripts/scriptbed.rpy:1525
translate spanish bednoscream_297c4a89:

    # a "Sinister..."
    a "Siniestro..."

# game/scripts/scriptbed.rpy:1528
translate spanish bednoscream_eea0276c:

    # c "You interrupted my work. For sleepwalking."
    c "Interrumpiste mi trabajo. Por sonambulismo."

# game/scripts/scriptbed.rpy:1531
translate spanish bednoscream_8652e331:

    # s "I'm sorry Coco. I think it's more than just sleepwalking..."
    s "Lo siento Coco. Creo que es más que simplemente sonambulismo..."

# game/scripts/scriptbed.rpy:1533
translate spanish bednoscream_cb1b722c:

    # s "Everytime I sleep I see memories of Hachiko High."
    s "Cada vez que duermo veo recuerdos del instituto Hachiko."

# game/scripts/scriptbed.rpy:1534
translate spanish bednoscream_6c585024:

    # s "The dead bodies... The demons."
    s "Los cadáveres... Los demonios."

# game/scripts/scriptbed.rpy:1536
translate spanish bednoscream_ebd60bf7:

    # s "But it feels like these memories aren't my own! In these dreams I stare at the inside of a bloody bathroom stall for hours, or I'm cut in half, again and again and again."
    s "¡Pero siento que estos recuerdos no son míos! En estos sueños miro fijamente el interior de un baño ensangrentado durante horas, o me cortan por la mitad, una y otra y otra vez."

# game/scripts/scriptbed.rpy:1539
translate spanish bednoscream_62db8658:

    # s "And w-when I wake up my room is completely wrecked! Or the people around me are terrified or hurt!"
    s "¡Y cuando me despierto mi habitación está completamente destrozada! ¡O la gente que me rodea está aterrorizada o herida!"

# game/scripts/scriptbed.rpy:1543
translate spanish bednoscream_0c2e0ba6:

    # c "And you don't remember anything?!"
    c "¡¿Y no recuerdas nada?!"

# game/scripts/scriptbed.rpy:1546
translate spanish bednoscream_0838f787:

    # s "No!! Nothing!"
    s "¡¡No!! ¡Nada!"

# game/scripts/scriptbed.rpy:1551
translate spanish bednoscream_c7a1eb82:

    # b "Wait wait! Sparky's turnin' into a psychopath!!"
    b "¡Espera, espera! ¡¡Sparky se está convirtiendo en un psicópata!!"

# game/scripts/scriptbed.rpy:1554
translate spanish bednoscream_14cfa49a:

    # s "I-I wouldn't say it like that!"
    s "¡Yo no lo diría así!"

# game/scripts/scriptbed.rpy:1557
translate spanish bednoscream_3ed21c16:

    # c "Whaaaat, isn't he like, the biggest wuss of you dogs?"
    c "¿Qué, no es él el más cobarde de ustedes, perros?"

# game/scripts/scriptbed.rpy:1560
translate spanish bednoscream_3df98560:

    # o "No way!! He's heckin' handsome and cool and tal-"--------
    o "¡¡De ninguna manera!! Es asombroso, genial y alto-"

# game/scripts/scriptbed.rpy:1563e
translate spanish bednoscream_b075132e:

    # b "And insaaaaane!"
    b "¡Y looooooco!"

# game/scripts/scriptbed.rpy:1566
translate spanish bednoscream_2ca575cf:

    # c "And what did he do that was so insane?"
    c "¿Y qué hizo el para que fuera tan ''loco''?"

# game/scripts/scriptbed.rpy:1569
translate spanish bednoscream_6ce6cc6a:

    # n "Brownie scampers up to Coco and whispers in her ear."
    n "Brownie se acerca a Coco y le susurra al oído."

# game/scripts/scriptbed.rpy:1571
translate spanish bednoscream_6c4e84cc:

    # n "With every passing breath Coco's face gradually twists into a look of disgust."
    n "Con cada respiración que pasa, el rostro de Coco gradualmente se retuerce en una expresión de disgusto."

# game/scripts/scriptbed.rpy:1575
translate spanish bednoscream_cd17376e:

    # c "EUGH!! YOU SAID THAT?! TO BROWNIE?!"
    c "¡¡EUGH!! ¡¿LE DIJISTE ESO?! ¡¿A BROWNIE?!"

# game/scripts/scriptbed.rpy:1578
translate spanish bednoscream_2929d433:

    # s "What?!? What did I say?!"
    s "¿¡¿Qué?!? ¡¿Qué dije?!"

# game/scripts/scriptbed.rpy:1581
translate spanish bednoscream_da1f0bcd:

    # c "BLECH you're the worst kind of scumbag!!"
    c "¡¡AGH!! ¡¡Eres una puta basura!!"

# game/scripts/scriptbed.rpy:1583
translate spanish bednoscream_218d6587:

    # c "... Wait, you don't remember?"
    c "... Espera, ¿no te acuerdas?"

# game/scripts/scriptbed.rpy:1586
translate spanish bednoscream_fff056a8:

    # s "No!! I don't remember saying anything to her!"
    s "¡¡No!! ¡No recuerdo haberle dicho nada!"

# game/scripts/scriptbed.rpy:1589
translate spanish bednoscream_0a83caaa:

    # c "Hmm."
    c "Mmm."

# game/scripts/scriptbed.rpy:1591
translate spanish bednoscream_67f0021c:

    # c "You need to fall asleep."
    c "Necesitas quedarte dormido."

# game/scripts/scriptbed.rpy:1595
translate spanish bednoscream_195a6167:

    # b "WHAT?!"
    b "¡¿QUÉ?!"

# game/scripts/scriptbed.rpy:1598
translate spanish bednoscream_5ea2de9f:

    # c "Don't worry, I'll be here the whole time! If he's possessed we need to draw the demon out before we can banish it!"
    c "¡No te preocupes, estaré aquí todo el tiempo! Si está poseído, ¡tenemos que sacar al demonio antes de poder desterrarlo!"

# game/scripts/scriptbed.rpy:1600
translate spanish bednoscream_253ef366:

    # c "And if he's not possessed we'll put him in a mental institution where he'll waste away for the rest of his short life!"
    c "¡Y si no está poseído lo meteremos en una institución mental donde consumirá el resto de su corta vida de mierda!"

# game/scripts/scriptbed.rpy:1604
translate spanish bednoscream_0b1ae20a:

    # s "WHAT?!"
    s "¡¿QUÉ?!"

# game/scripts/scriptbed.rpy:1607
translate spanish bednoscream_a0dd5a7f:

    # c "I'll be here the whole time! If you're possessed we need to draw the demon out before we can banish it!"
    c "¡Estaré aquí todo el tiempo! Si estás poseído, ¡tenemos que sacar al demonio antes de poder desterrarlo!"

# game/scripts/scriptbed.rpy:1609
translate spanish bednoscream_a41f9753:

    # c "And if you're not possessed I'll put you in a mental institution where you'll waste away for the rest of your short life!"
    c "¡Y si no está poseído te meteré en una institución mental donde consumirás el resto de tu corta vida de mierda!"

# game/scripts/scriptbed.rpy:1612
translate spanish bednoscream_69b71d56:

    # s "I... WHAT."
    s "YO... QUÉ."

# game/scripts/scriptbed.rpy:1615
translate spanish bednoscream_d576284e:

    # c "Yeesh I'm just kidding!"
    c "¡Sí, solo estoy bromeando...!"

# game/scripts/scriptbed.rpy:1616
translate spanish bednoscream_1eaaa35b:

    # c "Lie down Sparky."
    c "Recuestate Sparky."

# game/scripts/scriptbed.rpy:1624
translate spanish bednoscream_b271e7da:

    # s "... A-alright then."
    s "... E-está bien."

# game/scripts/scriptbed.rpy:1626
translate spanish bednoscream_8b3b6702:

    # n "Sparky lies down on the ground."
    n "Sparky se recuesta en el suelo."

# game/scripts/scriptbed.rpy:1631
translate spanish bednoscream_57fb73f3:

    # c "In the BED you animal!!"
    c "¡¡En la CAMA animal!!"

# game/scripts/scriptbed.rpy:1634
translate spanish bednoscream_d271f006:

    # s "OH! Right."
    s "¡OH! Ok."

# game/scripts/scriptbed.rpy:1636
translate spanish bednoscream_f6a52145:

    # n "Sparky lies down on the bed."
    n "Sparky se recuesta en la cama."

# game/scripts/scriptbed.rpy:1638
translate spanish bednoscream_ce3b5ee6:

    # s "If I get out of control do whatever it takes to stop me."
    s "Si me salgo de control haz lo que sea necesario para detenerme."

# game/scripts/scriptbed.rpy:1641
translate spanish bednoscream_702c10ea:

    # c "Ugh do you really doubt me that much? You're fine Sparky, now close your eyes."
    c "Uf, ¿realmente dudas tanto de mí? Estáras bien Sparky, ahora cierra los ojos."

# game/scripts/scriptbed.rpy:1644
translate spanish bednoscream_fb197560:

    # n "Sparky reluctantly closes his eyes."
    n "Sparky cierra los ojos."

# game/scripts/scriptbed.rpy:1645
translate spanish bednoscream_f65e89c1:

    # n "In spite of the pressuring stares of his friends his body relaxes."
    n "A pesar de las miradas de sus amigos, su cuerpo se relaja."

# game/scripts/scriptbed.rpy:1653
translate spanish bednoscream_f9820ef8:

    # n "The burden of three days with no sleep has him drifting off in just under a minute."
    n "La carga de tres días sin dormir lo hace quedarse dormido en poco menos de un minuto."

# game/scripts/scriptbed.rpy:1655
translate spanish bednoscream_11b007a0:

    # n "He snores softly."
    n "Él ronca suavemente."

# game/scripts/scriptbed.rpy:1657
translate spanish bednoscream_5e02243d:

    # o "Aww he's doin' a big snore."
    o "Aww, el está roncando."

# game/scripts/scriptbed.rpy:1666
translate spanish bednoscream_4f13693e:

    # s "!" with vpunch
    s "!" with vpunch

# game/scripts/scriptbed.rpy:1668
translate spanish bednoscream_fd98db4b:

    # c "Sparky? I-is that you?"
    c "¿Sparky? ¿E-eres tú?"

# game/scripts/scriptbed.rpy:1670
translate spanish bednoscream_4868356e:

    # se "..."
    se "..."

# game/scripts/scriptbed.rpy:1672
translate spanish bednoscream_3a0a61e3:

    # x "" with vpunch
    x "" with vpunch

# game/scripts/scriptbed.rpy:1673
translate spanish bednoscream_b679db60:

    # n "Coco's scream rings through the room!"
    n "¡El grito de Coco resuena por la habitación!"

# game/scripts/scriptbed.rpy:1675
translate spanish bednoscream_e72ef7a1:

    # b "COCO?!"
    b "¡¿COCO?!"

# game/scripts/scriptbed.rpy:1676
translate spanish bednoscream_f7b887e5:

    # n "Amidst the sound of shuffling Olive scrambles towards the lightswitch in a total panic."
    n "Con el sonido de pasos arrastrandose, Olive corre hacia el interruptor de la luz presa del pánico total."

# game/scripts/scriptbed.rpy:1683
translate spanish bednoscream_5ae9e77c:

    # n "They manage to hit it, only to find Brownie on top of Coco!"
    n "¡Logra golpearlo, solo para encontrar a Brownie encima de Coco!"

# game/scripts/scriptbed.rpy:1685
translate spanish bednoscream_5de44ed9:

    # c "B-B-BROWNIE! WHAT ARE YOU DOING?!"
    c "¡B-B-BROWNIE! ¡¿QUÉ ESTÁS HACIENDO?!"

# game/scripts/scriptbed.rpy:1688
translate spanish bednoscream_97cf8724:

    # b "I, I THOUGHT-"
    b "Yo, yo pensé-"

# game/scripts/scriptbed.rpy:1691
translate spanish bednoscream_b186ea0f:

    # c "Get off me!!"
    c "¡¡Suéltame!!"

# game/scripts/scriptbed.rpy:1693
translate spanish bednoscream_f1eced95:

    # n "Brownie shoots up like an arrow."
    n "Brownie salta como una flecha fuera de coco."

# game/scripts/scriptbed.rpy:1694
translate spanish bednoscream_18304b50:

    # n "Sparky is standing silently in the middle of the room."
    n "Sparky está de pie en silencio en medio de la habitación."

# game/scripts/scriptbed.rpy:1696
translate spanish bednoscream_f9dcbb05:

    # c "Sparky? Is that still you?"
    c "¿Sparky? ¿Sigues siendo tú?"

# game/scripts/scriptbed.rpy:1699
translate spanish bednoscream_638218f1:

    # se "You..."
    se "Tú..."

# game/scripts/scriptbed.rpy:1701
translate spanish bednoscream_9a9979fc:

    # se "You two are so cute! I can't believe you were going to sacrifice yourself for her! What was your name? Brownie?"
    se "¡Ustedes dos son tan lindas! ¡No puedo creer que fueras a sacrificarte por ella! ¿Cuál era tu nombre? ¿Brownie?"

# game/scripts/scriptbed.rpy:1704
translate spanish bednoscream_850ef128:

    # b "..."
    b "..."

# game/scripts/scriptbed.rpy:1706
translate spanish bednoscream_611ba564:

    # b "Shut the hell up."
    b "Cállate de una puta vez."

# game/scripts/scriptbed.rpy:1709
translate spanish bednoscream_d36e552f:

    # c "Get to the point demon."
    c "Vamos al grano, demonio."

# game/scripts/scriptbed.rpy:1712
translate spanish bednoscream_013b8e28:

    # se "I love a good romance."
    se "Me encantaria tener un buen romance."

# game/scripts/scriptbed.rpy:1714
translate spanish bednoscream_f7c48bd8:

    # se "Not sure what they're doing here though."
    se "Aunque no estoy seguro qué están haciendo aquí."

# game/scripts/scriptbed.rpy:1717
translate spanish bednoscream_78ce03d2:

    # o "M-me?"
    o "¿Y-yo?"

# game/scripts/scriptbed.rpy:1720
translate spanish bednoscream_cb5ea769:

    # se "Yes. I've been watching you and honestly you're a very gross dog."
    se "Sí. Te he estado observando y, sinceramente, eres un perro muy asqueroso."

# game/scripts/scriptbed.rpy:1721
translate spanish bednoscream_52328c59:

    # se "How can you just love everyone? Your love is so impure, so watered down."
    se "¿Cómo puedes simplemente amar a todos? Tu amor es tan impuro, tan diluido."

# game/scripts/scriptbed.rpy:1725
translate spanish bednoscream_9d232b53:

    # se "I'll kill you first."
    se "Te mataré a ti primero."

# game/scripts/scriptbed.rpy:1728
translate spanish bednoscream_cb24ff51:

    # o "HUH?!"
    o "¡¿EH?!"

# game/scripts/scriptbed.rpy:1731
translate spanish bednoscream_d033a495:

    # c "LIKE HELL YOU WILL!"
    c "¡SOLO INTENTALO IMBECIL!"

# game/scripts/scriptbed.rpy:1734
translate spanish bednoscream_d84785ea:

    # n "Coco begins to wave her wand but Sparky dashes towards her at an unnatural speed!"
    n "¡Coco comienza a agitar su varita pero Sparky corre hacia ella a una velocidad sobrenatural!"

# game/scripts/scriptbed.rpy:1738
translate spanish bednoscream_a543e730:

    # n "He grabs her by the throat with such force she drops her wand." with vpunch
    n "Él la agarra por el cuello con tanta fuerza que ella deja caer su varita." with vpunch

# game/scripts/scriptbed.rpy:1740
translate spanish bednoscream_c7da0103:

    # c "ACK!"
    c "¡ACK!"

# game/scripts/scriptbed.rpy:1743
translate spanish bednoscream_be7a5980:

    # b "COCO!!"
    b "¡¡COCO!!"

# game/scripts/scriptbed.rpy:1746
translate spanish bednoscream_6424ea63:

    # se "Any last words for your friend?"
    se "¿Algunas últimas palabras para tu amigo?"

# game/scripts/scriptbed.rpy:1749
translate spanish bednoscream_9964a30a:

    # n "Brownie grabs a desk chair and swings it at Sparky's legs!" with vpunch
    n "¡Brownie agarra una silla de escritorio y la golpea contra las piernas de Sparky!" with vpunch

# game/scripts/scriptbed.rpy:1752
translate spanish bednoscream_d89981fa:

    # n "Before it can make contact he crushes it against the ground with a single stomp." with vpunch
    n "Antes de que siquiera pueda hacer contacto, lo aplasta contra el suelo con un solo pisotón." with vpunch

# game/scripts/scriptbed.rpy:1754
translate spanish bednoscream_4517fc3e:

    # se "Too bad."
    se "Que pena."

# game/scripts/scriptbed.rpy:1759
translate spanish bednoscream_a57ae132:

    # n "He crushes Coco's neck in his fist!" with vpunch
    n "¡Él aplasta el cuello de Coco con su puño!" with vpunch

# game/scripts/scriptbed.rpy:1765
translate spanish bednoscream_c36adad3:

    # n "He slams her limp body into Brownie's knocking them both to the ground." with vpunch
    n "Él estrella su cuerpo inerte contra el de Brownie, tirándolos a ambos al suelo." with vpunch

# game/scripts/scriptbed.rpy:1767
translate spanish bednoscream_89305fe4:

    # o "NO!!"
    o "¡¡NO!!"

# game/scripts/scriptbed.rpy:1771
translate spanish bednoscream_d56e461d:

    # n "Olive runs between Sparky and their friends!"
    n "¡Olive corre entre Sparky y sus amigos!"

# game/scripts/scriptbed.rpy:1773
translate spanish bednoscream_224c269b:

    # o "PLEASE SPARKY!! Wake up wake up wake up!!"
    o "¡¡POR FAVOR SPARKY!! ¡¡Despierta, despierta, despierta!!"

# game/scripts/scriptbed.rpy:1777
translate spanish bednoscream_9b22a8db:

    # n "Sparky grabs Olive by their lower jaw without hesitation."
    n "Sparky agarra a Olive por la mandíbula inferior sin siquiera dudarlo."

# game/scripts/scriptbed.rpy:1779
translate spanish bednoscream_6d8a57c4:

    # se "Stop interrupting you filthy mutt."
    se "Deja de interrumpir, chucho asqueroso."

# game/scripts/scriptbed.rpy:1783
translate spanish bednoscream_5bcbd9ca:

    # n "He tears Olive's head in half as Brownie watches in horror." with vpunch
    n "Él parte la cabeza de Olive por la mitad mientras Brownie observa horrorizado." with vpunch

# game/scripts/scriptbed.rpy:1786
translate spanish bednoscream_135bc20e:

    # b "N-NO!!"
    b "¡¡N-NO!!"

# game/scripts/scriptbed.rpy:1790
translate spanish bednoscream_c7275291:

    # se "You're next." with vpunch
    se "Tu eres la siguiente." with vpunch

# game/scripts/scriptbed.rpy:1799
translate spanish bednoscream_c748eaa6:

    # o "C-COCO!!"
    o "¡¡COCO!!"

# game/scripts/scriptbed.rpy:1800
translate spanish bednoscream_1b5ac04f:

    # n "Olive scrambles towards the lightswitch."
    n "Olive corre hacia el interruptor de la luz."

# game/scripts/scriptbed.rpy:1809
translate spanish bednoscream_2489a5e4:

    # n "They manage to hit it only to find Coco's unmoving body on the ground nearby."
    n "Se las arreglan para golpearlo sólo para encontrar el cuerpo inmóvil de Coco en el suelo cercano."

# game/scripts/scriptbed.rpy:1812
translate spanish bednoscream_a6aa117f:

    # a "COCO!!"
    a "¡¡COCO!!"

# game/scripts/scriptbed.rpy:1813
translate spanish bednoscream_7188b404:

    # n "Olive scrambles towards the lightswitch!"
    n "¡Olive corre hacia el interruptor de la luz!"

# game/scripts/scriptbed.rpy:1828
translate spanish bednoscream_d9d0a6e1:

    # n "They manage to hit it only to find Coco unconscious in the arms of... Angel?"
    n "Logran golpearlo sólo para encontrar a Coco inconsciente en los brazos de... ¿Angel?"

# game/scripts/scriptbed.rpy:1830
translate spanish bednoscream_83e63a39:

    # a "... WHAT?!"
    a "... ¡¿QUÉ?!"

# game/scripts/scriptbed.rpy:1832
translate spanish bednoscream_ea200ddf:

    # n "Angel backs away in disbelief."
    n "Angel retrocede incrédulo."

# game/scripts/scriptbed.rpy:1835
translate spanish bednoscream_e3654a02:

    # n "His undead body drops Coco to the floor." with vpunch
    n "Su cuerpo zombie deja caer a Coco al suelo." with vpunch

# game/scripts/scriptbed.rpy:1837
translate spanish bednoscream_b93d1dfb:

    # pu "Surprised?"
    pu "¿Sorprendido?"

# game/scripts/scriptbed.rpy:1840
translate spanish bednoscream_9618e64f:

    # a "YOU CUT MY HAIR?!"
    a "¡¿TU CORTASTE MI PELO?!"

# game/scripts/scriptbed.rpy:1841
translate spanish bednoscream_334d086c:

    # a "WHATEVER. JUST GET THE FUCK AWAY FROM MY SISTER!"
    a "LO QUE SEA. ¡ALEJATE DE MI HERMANA, HIJO DE PUTA!"

# game/scripts/scriptbed.rpy:1844
translate spanish bednoscream_88a3711a:

    # n "The undead assailant snickers."
    n "El agresor zombie se ríe disimuladamente."

# game/scripts/scriptbed.rpy:1846
translate spanish bednoscream_6bb54a73:

    # a "Who are you?! Why are you doing this? Are you the one behind the rest of the zombies?"
    a "¡¿Quién eres?! ¿Por qué haces esto? ¿Eres tú el que está detrás del resto de zombies?"

# game/scripts/scriptbed.rpy:1847
translate spanish bednoscream_de2264d8:

    # a "I-if this is because we killed you all... I'm sorry."
    a "S-si esto es porque los matamos a todos... lo siento."

# game/scripts/scriptbed.rpy:1849
translate spanish bednoscream_10f722fb:

    # a "... I'm really sorry..."
    a "... lo siento mucho..."

# game/scripts/scriptbed.rpy:1850
translate spanish bednoscream_53f1d2cb:

    # a "When Coco wakes up we can fix you-"
    a "Cuando Coco despierte podremos arreglarte."

# game/scripts/scriptbed.rpy:1853
translate spanish bednoscream_bb688109:

    # pu "Coco's not waking up."
    pu "Coco no se despierta."

# game/scripts/scriptbed.rpy:1854
translate spanish bednoscream_9fcbd9fa:

    # pu "Right Sparky?"
    pu "¿Verdad, Sparky?"

# game/scripts/scriptbed.rpy:1862
translate spanish bednoscream_a0f344d2:

    # se "Yup!"
    se "¡Sí!"

# game/scripts/scriptbed.rpy:1865
translate spanish bednoscream_ec77e385:

    # o "N-no!!"
    o "¡¡N-no!!"

# game/scripts/scriptbed.rpy:1869
translate spanish bednoscream_eb57def3:

    # pu "Pass me the wand."
    pu "Pásame la varita."

# game/scripts/scriptbed.rpy:1872
translate spanish bednoscream_9566fecc:

    # a "NO!!" with vpunch
    a "NO!!" with vpunch

# game/scripts/scriptbed.rpy:1874
translate spanish bednoscream_5bb6d132:

    # n "Angel tries to pounce on the zombie!"
    n "¡Angel intenta abalanzarse sobre el zombie!"

# game/scripts/scriptbed.rpy:1876
translate spanish bednoscream_ce9cde35:

    # n "Sparky grabs the wand from Coco's body before Angel can intervene."
    n "Sparky agarra la varita del cuerpo de Coco antes de que Angel pueda intervenir."

# game/scripts/scriptbed.rpy:1878
translate spanish bednoscream_a12d8918:

    # n "He tosses it into the corpse's waiting paws."
    n "Lo arroja a las garras del cadáver."

# game/scripts/scriptbed.rpy:1882
translate spanish bednoscream_b3af046c:

    # n "With one wave of the wand Angel is bound in magic!" with vpunch
    n "¡Con un movimiento de su varita el Angel queda atado a la magia!" with vpunch

# game/scripts/scriptbed.rpy:1883
translate spanish bednoscream_d9dfb813:

    # a "MMPHH!!"
    a "MMPHH!!"

# game/scripts/scriptbed.rpy:1886
translate spanish bednoscream_8661ed13:

    # o "AHH!!!"
    o "¡¡¡AHH!!!"

# game/scripts/scriptbed.rpy:1889
translate spanish bednoscream_4868356e_1:

    # se "..."
    se "..."

# game/scripts/scriptbed.rpy:1890
translate spanish bednoscream_44a7f967:

    # n "Sparky steps towards Olive."
    n "Sparky avanza hacia hacia Olive."

# game/scripts/scriptbed.rpy:1904
translate spanish purrgatory_e03130d0:

    # o "Where a-am I?"
    o "¿Dónde estoy?"

# game/scripts/scriptbed.rpy:1906
translate spanish purrgatory_ac0e8c15:

    # o "H-hew-hello?!"
    o "¡¿H-ho-hola?!"

# game/scripts/scriptbed.rpy:1909
translate spanish purrgatory_30f9bb1a:

    # p "Ugh."
    p "Ugh."

# game/scripts/scriptbed.rpy:1912
translate spanish purrgatory_e77a5c5a:

    # o "P-PATCHES! Are you okay?!"
    o "P-PATCHES! ¡¿Estás bien?!"

# game/scripts/scriptbed.rpy:1915
translate spanish purrgatory_27f3e7b2:

    # p "What the."
    p "Qué carajos."

# game/scripts/scriptbed.rpy:1917
translate spanish purrgatory_adbf4acb:

    # p "Oh for DOG'S SAKE."
    p "Oh, POR TODOS LOS PERROS."

# game/scripts/scriptbed.rpy:1919
translate spanish purrgatory_a158592b:

    # n "Patches looks at his transparent paws for a moment,"
    n "Patches mira sus patas transparentes por un momento,"

# game/scripts/scriptbed.rpy:1923
translate spanish purrgatory_e9137124:

    # n "And then suddenly slaps Olive in the face!" with vpunch
    n "¡Y de repente le da una bofetada a Olive en la cara!" with vpunch

# game/scripts/scriptbed.rpy:1925
translate spanish purrgatory_9b66e002:

    # o "AHH!!"
    o "¡¡AHH!!"

# game/scripts/scriptbed.rpy:1928
translate spanish purrgatory_7d30e740:

    # p "Did that hurt?"
    p "¿Eso te dolió?"

# game/scripts/scriptbed.rpy:1931
translate spanish purrgatory_21979d88:

    # o "O-oh n-n-not really. It was really scary though!"
    o "O-oh n-n-no realmente. ¡Aunque fue aterrador!"

# game/scripts/scriptbed.rpy:1934
translate spanish purrgatory_ce916da0:

    # p "AUGHH!! I can't even pass the rest of eternity torturing you? This place is far worse than Inferno."
    p "¡¡AUGHH!! ¿Ni siquiera puedo pasar el resto de la eternidad torturándote? Este lugar es mucho peor que Infierno."

# game/scripts/scriptbed.rpy:1937
translate spanish purrgatory_3d66e0e5:

    # o "We're not in Infurno? W-where are we?"
    o "¿No estamos en infierno? ¿D-dónde estamos?"

# game/scripts/scriptbed.rpy:1940
translate spanish purrgatory_b4f76472:

    # p "We're in purgatory you dolt."
    p "Estamos en el purgatorio, idiota."

# game/scripts/scriptbed.rpy:1942
translate spanish purrgatory_d11bab48:

    # p "We didn't make it all the way through Ginger's shitty portal and now we're stuck here, alone, for all eternity."
    p "No logramos atravesar el portal de mierda de Ginger y ahora estamos atrapados aquí, solos, por toda la eternidad."

# game/scripts/scriptbed.rpy:1945
translate spanish purrgatory_f57cf439:

    # o "But I'm not alone. I h-have you!"
    o "Pero no estoy sola. ¡Te t-tengo a ti!"

# game/scripts/scriptbed.rpy:1948
translate spanish purrgatory_20cbb32f:

    # p "Oh and it's in love with me too now."
    p "Ah, y ahora también estás enamorada de mí."

# game/scripts/scriptbed.rpy:1951
translate spanish purrgatory_bdd1b598:

    # o "HUH?!? I-I'm not an it!"
    o "¿¡¿EH?!? ¡Yo no!"

# game/scripts/scriptbed.rpy:1954
translate spanish purrgatory_037e4055:

    # p "No. You're a disgusting mutt that just shares love with everyone like a wild animal."
    p "No. Eres una cucha asquerosa que comparte su amor con todos como un animal salvaje."

# game/scripts/scriptbed.rpy:1956
translate spanish purrgatory_d74e5aa6:

    # p "You're no use to me unless you live for me, and only me."
    p "No me sirves de nada a menos que vivas para mí, y sólo para mí."

# game/scripts/scriptbed.rpy:1959
translate spanish purrgatory_a4fa7e2f:

    # o "WhAaAaAat?!"
    o "¡¿QuéEeEeEe?!"

# game/scripts/scriptbed.rpy:1961
translate spanish purrgatory_a857a831:

    # o "It's okay to l-love lots of people Patches!"
    o "¡Está bien amar a mucha gente, Patches!"

# game/scripts/scriptbed.rpy:1963
translate spanish purrgatory_6252ed5c:

    # o "D-don't you have p-parents you love? Or f-friends?"
    o "¿N-no tienes p-padres a los que amas? ¿O amigos?"

# game/scripts/scriptbed.rpy:1966
translate spanish purrgatory_8fd57643:

    # p "You know what Olive, I think I'd rather be alone for all eternity than listen to this after-school-special drivel."
    p "¿Sabes que Olive? Creo que prefiero estar solo por toda la eternidad que escuchar esa tontería."

# game/scripts/scriptbed.rpy:1969
translate spanish purrgatory_c459fd52:

    # n "Patches begins floating away in the void of Purrgatory."
    n "Patches comienza a flotar en el vacío del Purrgatorio."

# game/scripts/scriptbed.rpy:1971
translate spanish purrgatory_4995d34c:

    # o "H-hey Patches! Wait!"
    o "¡Hey, Patches! ¡Espera!"

# game/scripts/scriptbed.rpy:1974
translate spanish purrgatory_cb4a0933:

    # o "When you were forced out of your body you ended up in Infurno with Ginger and the zombie dogs, right?"
    o "Cuando te obligaron a salir de tu cuerpo terminaste en Infierno con Ginger y los perros zombies, ¿verdad?"

# game/scripts/scriptbed.rpy:1977
translate spanish purrgatory_71789062:

    # p "Correct. Your point?"
    p "Correcto. ¿Por que?"

# game/scripts/scriptbed.rpy:1980
translate spanish purrgatory_7ee616ae:

    # o "How did you get back?"
    o "¿Cómo volviste?"

# game/scripts/scriptbed.rpy:1983
translate spanish purrgatory_1cd708ab:

    # p "I got lucky."
    p "Tuve suerte."

# game/scripts/scriptbed.rpy:1984
translate spanish purrgatory_a3c9667a:

    # p "I found the soul of a powerful esper and got her to fall in love with me. She followed my every whim."
    p "Encontré a un alma poderosa y logré que se enamorara de mí. Ella siguió todos mis caprichos."

# game/scripts/scriptbed.rpy:1986
translate spanish purrgatory_3525b20c:

    # p "It was a lot of fun playing with her honestly!"
    p "¡Fue muy divertido jugar con ella honestamente!"

# game/scripts/scriptbed.rpy:1988
translate spanish purrgatory_8562b25d:

    # p "But now I won't be able to come back unless someone from the outside lets me out."
    p "Pero ahora no podré volver a menos que alguien de fuera me deje salir."

# game/scripts/scriptbed.rpy:1991
translate spanish purrgatory_ed1854b8:

    # p "And Ginger probably won't come back for me if she knows I'll kill all her new friends... She's always been..."
    p "Y Ginger probablemente no volverá por mí, sabe que mataré a todos sus nuevos amigos... Ella siempre ha sido..."

# game/scripts/scriptbed.rpy:1993
translate spanish purrgatory_1179a11c:

    # n "Patches shudders."
    n "Patches se estremece."

# game/scripts/scriptbed.rpy:1995
translate spanish purrgatory_bace0c16:

    # p "Sentimental."
    p "Sentimental."

# game/scripts/scriptbed.rpy:1998
translate spanish purrgatory_fbf9016d:

    # o "D-do you think she'd come back for me?"
    o "¿Crees que ella volvería por mí?"

# game/scripts/scriptbed.rpy:2001
translate spanish purrgatory_7562b65f:

    # n "Patches eyes Olive up and down."
    n "Patches mira a Olive de arriba a abajo."

# game/scripts/scriptbed.rpy:2003
translate spanish purrgatory_3a014462:

    # p "That's a very good point Olive, maybe we SHOULD stick together!"
    p "Ese es un muy buen punto, Olive, ¡quizás DEBERÍAMOS permanecer unidos!"

# game/scripts/scriptbed.rpy:2006
translate spanish purrgatory_e1ca30b4:

    # n "Patches grabs Olive's arm hard enough to hurt if they were alive to feel anything." with vpunch
    n "Patches agarra el brazo de Olive con tanta fuerza que le doleria si tan solo Patches estuviera vivo." with vpunch

# game/scripts/scriptbed.rpy:2008
translate spanish purrgatory_bfea1ffe:

    # p "I'm not letting you go until we're out of here, for as long as it takes!"
    p "¡No te dejaré ir hasta que salgamos de aquí, por el tiempo que sea necesario!"

# game/scripts/scriptbed.rpy:2011
translate spanish purrgatory_7852f809:

    # o "O-okie dokie Patches!"
    o "¡O-okie dokie Patches!"

# game/scripts/scriptbed.rpy:2021
translate spanish purrgatorymenu_bc6b2556:

    # o "I've always w-wondered, why did you kill Angel in the f-first place?"
    o "Siempre me he preguntado, ¿por qué mataste a Angel en primer lugar?"

# game/scripts/scriptbed.rpy:2024
translate spanish purrgatorymenu_ec2f02c4:

    # p "It was fun."
    p "Fue divertido."

# game/scripts/scriptbed.rpy:2027
translate spanish purrgatorymenu_8d90a23f:

    # o "NOoOoOoOo why did you REALLY kill him?"
    o "NOoOoOoOo ¿por qué REALMENTE lo mataste?"

# game/scripts/scriptbed.rpy:2028
translate spanish purrgatorymenu_e0ac46d1:

    # o "Back in Coco's room you called him a traitor!"
    o "¡En la habitación de Coco lo llamaste traidor!"

# game/scripts/scriptbed.rpy:2031
translate spanish purrgatorymenu_784589d3:

    # p "Oh, that?"
    p "Ah, ¿eso?"

# game/scripts/scriptbed.rpy:2033
translate spanish purrgatorymenu_4924b6f7:

    # p "Forget it."
    p "Olvídalo."

# game/scripts/scriptbed.rpy:2036
translate spanish purrgatorymenu_f6209b53:

    # n "Olive sulks."
    n "Olive se muestra malhumorada."

# game/scripts/scriptbed.rpy:2038
translate spanish purrgatorymenu_e2cbfe63:

    # o "Fine, I'll just guess until I get it right!"
    o "Bien, ¡adivinaré hasta que lo haga bien!"

# game/scripts/scriptbed.rpy:2040
translate spanish purrgatorymenu_5f1972d0:

    # o "Was he s-super mean to you?!"
    o "¡¿Fue súper malo contigo?!"

# game/scripts/scriptbed.rpy:2043
translate spanish purrgatorymenu_cde92cc7:

    # p "No."
    p "No."

# game/scripts/scriptbed.rpy:2046
translate spanish purrgatorymenu_684dc10b:

    # o "Did he hit you?"
    o "¿Te golpeó?"

# game/scripts/scriptbed.rpy:2049
translate spanish purrgatorymenu_329e0c56:

    # p "No..."
    p "No..."

# game/scripts/scriptbed.rpy:2051
translate spanish purrgatorymenu_47b41adc:

    # o "Hmm..."
    o "Mmm..."

# game/scripts/scriptbed.rpy:2056
translate spanish purrgatorymenu_a96bdb05:

    # o "... Did he break your heart?"
    o "... ¿Te rompió el corazón?"

# game/scripts/scriptbed.rpy:2060
translate spanish purrgatorymenu_4c8bce56:

    # p "Talk about something else."
    p "Habla de otra cosa."

# game/scripts/scriptbed.rpy:2066
translate spanish purrgatorymenu_fcaac736:

    # o "... Did he betray you?"
    o "... ¿Te traicionó?"

# game/scripts/scriptbed.rpy:2068
translate spanish purrgatorymenu_c8ea8a4a:

    # p "..."
    p "..."

# game/scripts/scriptbed.rpy:2072
translate spanish purrgatorymenu_256c79b8:

    # p "Hmm, good guess!"
    p "Mmmm, ¡buena suposición!"

# game/scripts/scriptbed.rpy:2074
translate spanish purrgatorymenu_ba652cfa:

    # p "He turned his back on me..."
    p "Me dio la espalda..."

# game/scripts/scriptbed.rpy:2076
translate spanish purrgatorymenu_5715cac9:

    # p "Even when he knew he was the only one I cared about..."
    p "Incluso cuando sabía que él era el único que me importaba..."

# game/scripts/scriptbed.rpy:2079
translate spanish purrgatorymenu_02881e14:

    # p "I MEAN." with vpunch
    p "DIGO" with vpunch

# game/scripts/scriptbed.rpy:2080
translate spanish purrgatorymenu_9c76410a:

    # p "I HATE HIM. I HATE HIM AND I'VE ALWAYS HATED HIM!!"
    p "LO ODIO. ¡¡LO ODIO Y SIEMPRE LO HE ODIADO!!"

# game/scripts/scriptbed.rpy:2083
translate spanish purrgatorymenu_03f91f97:

    # o "Eep."
    o "Eeep."

# game/scripts/scriptbed.rpy:2091
translate spanish purrgatorymenu_5406b3ff:

    # o "What do you do for f-fun?"
    o "¿Qué haces para divertirte?"

# game/scripts/scriptbed.rpy:2092
translate spanish purrgatorymenu_4ccb3ee4:

    # o "Y-you were in the library lots at s-school r-right?"
    o "Estabas en la biblioteca de la escuela, ¿verdad?"

# game/scripts/scriptbed.rpy:2094
translate spanish purrgatorymenu_aa5b7c2d:

    # o "Do you like reading?"
    o "¿Te gusta leer?"

# game/scripts/scriptbed.rpy:2097
translate spanish purrgatorymenu_dc1e1d86:

    # p "It's fun but mostly I like cutting up bad dogs into tiny little pieces!"
    p "¡Es divertido, pero sobre todo me gusta cortar perros malos en pedacitos pequeños!"

# game/scripts/scriptbed.rpy:2100
translate spanish purrgatorymenu_af10330c:

    # o "I-is that really th-that much fun?"
    o "¿Es eso realmente tan divertido?"

# game/scripts/scriptbed.rpy:2103
translate spanish purrgatorymenu_2c11b276:

    # p "It feels very... Productive."
    p "Se siente muy... Productivo."

# game/scripts/scriptbed.rpy:2104
translate spanish purrgatorymenu_8d8beb61:

    # p "Like cleaning dust off a bookshelf."
    p "Como limpiar el polvo de una estantería."

# game/scripts/scriptbed.rpy:2106
translate spanish purrgatorymenu_2c110d0e:

    # p "It's self care in a way!"
    p "¡Es cuidado personal en cierto modo!"

# game/scripts/scriptbed.rpy:2107
translate spanish purrgatorymenu_8e838d71:

    # p "Getting rid of the toxic people in your life that only want to hurt you."
    p "Deshacerte de las personas tóxicas en tu vida que sólo quieren hacerte daño."

# game/scripts/scriptbed.rpy:2110
translate spanish purrgatorymenu_35eee338:

    # o "Y-you'd kill me if y-you had the chance, right?"
    o "Me matarías si tuvieras la oportunidad, ¿verdad?"

# game/scripts/scriptbed.rpy:2113
translate spanish purrgatorymenu_fc0a8ae0:

    # p "Absolutely!"
    p "¡Absolutamente!"

# game/scripts/scriptbed.rpy:2116
translate spanish purrgatorymenu_cf79d713:

    # o "B-but I d-don't think I've ever hurt you!"
    o "¡P-pero no creo haberte lastimado nunca!"

# game/scripts/scriptbed.rpy:2119
translate spanish purrgatorymenu_bea233b1:

    # p "Ugh, that's what you think! I know what side you're on."
    p "¡Ugh, eso es lo que piensas! Sé de qué lado estás."

# game/scripts/scriptbed.rpy:2121
translate spanish purrgatorymenu_08a85e55:

    # p "You're with everyone else, and I'm everyone's enemy."
    p "Estás con todos los demás y yo soy el enemigo de todos."

# game/scripts/scriptbed.rpy:2124
translate spanish purrgatorymenu_c9babf6b:

    # o "N-NO!! H-how could you say that!! I w-want to be friends, not enemies!"
    o "¡¡N-NO!! ¡¡C-cómo pudiste decir eso!! ¡Quiero ser tu amigo, no tu enemigo!"

# game/scripts/scriptbed.rpy:2127
translate spanish purrgatorymenu_c8ea8a4a_1:

    # p "..."
    p "..."

# game/scripts/scriptbed.rpy:2130
translate spanish purrgatorymenu_b0bd2bdf:

    # p "Of course you do."
    p "Por supuesto que sí."

# game/scripts/scriptbed.rpy:2138
translate spanish purrgatorymenu_cc243df2:

    # o "It's pretty confusing s-seeing you look so much like Angel!"
    o "¡Es bastante confuso ver que te pareces tanto a Angel!"

# game/scripts/scriptbed.rpy:2142
translate spanish purrgatorymenu_d5670890:

    # p "I don't look like Angel. HE looks like ME."
    p "No me parezco a Angel. ÉL se parece a MI."

# game/scripts/scriptbed.rpy:2145
translate spanish purrgatorymenu_f073c7a9:

    # o "Oh r-r-right!"
    o "¡Oh, b-b-bien!"

# game/scripts/scriptbed.rpy:2147
translate spanish purrgatorymenu_07abc845:

    # o "..."
    o "..."

# game/scripts/scriptbed.rpy:2149
translate spanish purrgatorymenu_ec0acddd:

    # o "Do you miss your old body?"
    o "¿Extrañas tu antiguo cuerpo?"

# game/scripts/scriptbed.rpy:2152
translate spanish purrgatorymenu_ef3cdc51:

    # p "Not at all! How could it compare to this rotting corpse of the one who-"
    p "¡No del todo! ¿Pero cómo podrías compararlo con el cadáver podrido de aquel que...?"

# game/scripts/scriptbed.rpy:2154
translate spanish purrgatorymenu_906122de:

    # p "Who betrayed me! And then had his sister come to my school and destroy EVERYTHING!!"
    p "¡Que me traicionó! ¡¡Y luego su hermana vino a mi escuela y destruyó TODO!!"

# game/scripts/scriptbed.rpy:2157
translate spanish purrgatorymenu_94b6fda9:

    # o "S-so... You don't miss your old body?"
    o "E-entonces... ¿No extrañas tu antiguo cuerpo?"

# game/scripts/scriptbed.rpy:2160
translate spanish purrgatorymenu_580e35c5:

    # p "I like my old body. I miss it but I know I won't be far from it for long."
    p "Me gusta mi viejo cuerpo. Lo extraño pero sé que no estaré lejos de el por mucho tiempo."

# game/scripts/scriptbed.rpy:2161
translate spanish purrgatorymenu_a87fc40d:

    # p "I'll take it back and maybe even give Angel a new body!"
    p "¡Lo retiraré de el y tal vez incluso le dé a Angel un cuerpo nuevo!"

# game/scripts/scriptbed.rpy:2164
translate spanish purrgatorymenu_a28ac9bc:

    # p "Just so I can torture it!!"
    p "¡¡Solo para poder torturarlo!!"

# game/scripts/scriptbed.rpy:2167
translate spanish purrgatorymenu_ab9916a4:

    # o "That sounded so nice except for the t-torture part!"
    o "¡Eso sonó tan bien excepto por la parte de la tortura!"

# game/scripts/scriptbed.rpy:2175
translate spanish purrgatorymenu_0651aa02:

    # n "Olive gives Patches a huge hug!!" with vpunch
    n "¡¡¡Olive le da un gran abrazo a Patches!!!" with vpunch

# game/scripts/scriptbed.rpy:2177
translate spanish purrgatorymenu_94f823b6:

    # p "WHY. WHY ARE YOU DOING THIS?!"
    p "POR QUÉ. ¡¿POR QUÉ ESTÁS HACIENDO ESTO?!"

# game/scripts/scriptbed.rpy:2179
translate spanish purrgatorymenu_3be81118:

    # p "You JUST punched me!"
    p "¡SOLO me golpeaste!"

# game/scripts/scriptbed.rpy:2182
translate spanish purrgatorymenu_4558b0fb:

    # o "I don't know, m-maybe you haven't had a hug in a while."
    o "No lo sé, tal vez hace tiempo que no te abrazan."

# game/scripts/scriptbed.rpy:2184
translate spanish purrgatorymenu_95d9f90d:

    # o "I know I could always go for a hug!"
    o "¡Sé que un abrazo siempre ayuda!"

# game/scripts/scriptbed.rpy:2187
translate spanish purrgatorymenu_b71fb5b5:

    # n "Olive hugs him really hard."
    n "Olive lo abraza muy fuerte."

# game/scripts/scriptbed.rpy:2190
translate spanish purrgatorymenu_cfa8407a:

    # n "He can't seem to fight them off so he just lets them hug him."
    n "Parece que Patches no puede luchar contra ella, así que simplemente deja que lo abrace."

# game/scripts/scriptbed.rpy:2197
translate spanish purrgatorymenu_78c0e54e:

    # o "Hey P-Patches... Bad dogs should be punished, right?"
    o "Emm P-Patches... Los perros malos deberían ser castigados, ¿verdad?"

# game/scripts/scriptbed.rpy:2200
translate spanish purrgatorymenu_f867f752:

    # p "Oh yes. Punished dearly."
    p "Oh sí. Castigados duramente."

# game/scripts/scriptbed.rpy:2204
translate spanish purrgatorymenu_f5915fae:

    # n "Olive punches Patches in the face!" with vpunch
    n "¡Olive golpea a Patches en la cara!" with vpunch

# game/scripts/scriptbed.rpy:2206
translate spanish purrgatorymenu_b0c36f9c:

    # n "He feels nothing but is still pretty pissed!"
    n "¡Pero no siente nada!"

# game/scripts/scriptbed.rpy:2208
translate spanish purrgatorymenu_69dcf131:

    # p "WHAT THE HELL WAS THAT FOR?!"
    p "¡¿PARA QUÉ DEMONIOS FUE ESO?!"

# game/scripts/scriptbed.rpy:2210
translate spanish purrgatorymenu_403d64fb:

    # p "You JUST hugged me!"
    p "¡SOLO me abrazaste!"

# game/scripts/scriptbed.rpy:2213
translate spanish purrgatorymenu_a02b5251:

    # n "Olive growls softly."
    n "Olive gruñe suavemente."

# game/scripts/scriptbed.rpy:2216
translate spanish purrgatorymenu_be40d33d:

    # o "You're a b-bad dog! You're here because you're b-b-bad and you don't know how to talk to people!"
    o "¡Eres un perro malo! ¡Estás aquí porque eres m-m-malo y no sabes cómo hablar con la gente!"

# game/scripts/scriptbed.rpy:2218
translate spanish purrgatorymenu_c8ea8a4a_2:

    # p "..."
    p "..."

# game/scripts/scriptbed.rpy:2222
translate spanish purrgatorymenu_c8ea8a4a_3:

    # p "..."
    p "..."

# game/scripts/scriptbed.rpy:2229
translate spanish purrgatorymenu_bb3c9e70:

    # n "Olive curls up against Patches."
    n "Olive se acurruca contra Patches."

# game/scripts/scriptbed.rpy:2231
translate spanish purrgatorymenu_fed8be39:

    # p "What the FUCK are you doing?!"
    p "¡¿Qué MIERDA estás haciendo?!"

# game/scripts/scriptbed.rpy:2234
translate spanish purrgatorymenu_e950441d:

    # o "I'm going to n-nap until Ginger comes to g-get us!"
    o "¡Voy a tomar una siesta hasta que Ginger venga a buscarnos!"

# game/scripts/scriptbed.rpy:2237
translate spanish purrgatorymenu_f3200c41:

    # p "Well nap somewhere else!!"
    p "¡¡Pues toma una siesta en otro sitio!!"

# game/scripts/scriptbed.rpy:2240
translate spanish purrgatorymenu_8f435786:

    # o "B-but what if she comes and you're not with me!!"
    o "¡¡P-pero qué pasa si ella viene y no estás conmigo!!"

# game/scripts/scriptbed.rpy:2241
translate spanish purrgatorymenu_998a7c15:

    # o "We need to s-stick together if we're both going to get out!"
    o "¡Necesitamos permanecer unidos si queremos salir ambos!"

# game/scripts/scriptbed.rpy:2244
translate spanish purrgatorymenu_87be6119:

    # p "Why do you want ME to get out?!" with vpunch
    p "¿Por qué quieres que YO salga?" with vpunch

# game/scripts/scriptbed.rpy:2245
translate spanish purrgatorymenu_8fc09bb7:

    # p "After everything I've said so far don't you realize I'm just going to continue tormenting you and your friends!!"
    p "Después de todo lo que he dicho hasta ahora, ¿no te das cuenta de que voy a seguir atormentándote a ti y a tus amigos?"

# game/scripts/scriptbed.rpy:2257
translate spanish gameover08_aa6db0e4:

    # o "But you d-don't deserve to be trapped in Purrgatory furever."
    o "Pero no mereces estar atrapado en el Purrgatorio para siempre."

# game/scripts/scriptbed.rpy:2259
translate spanish gameover08_c62ccc38:

    # o "I trust that y-you'll be a good boy and not hurt anyone!"
    o "¡Confío en que serás un buen chico y no lastimarás a nadie!"

# game/scripts/scriptbed.rpy:2262
translate spanish gameover08_c8ea8a4a:

    # p "..."
    p "..."

# game/scripts/scriptbed.rpy:2264
translate spanish gameover08_70cc8550:

    # n "Olive curls up once more."
    n "Olive se acurruca una vez más."

# game/scripts/scriptbed.rpy:2266
translate spanish gameover08_7b489f6a:

    # o "I'll make sure you get out of here and get a slice of my birthday cake!"
    o "¡Me aseguraré de que salgas de aquí y consigas un trozo de mi pastel de cumpleaños!"

# game/scripts/scriptbed.rpy:2269
translate spanish gameover08_944fcac7:

    # n "Olive promptly falls asleep."
    n "Olive rápidamente se queda dormida."

# game/scripts/scriptbed.rpy:2286
translate spanish gameover08_07abc845:

    # o "..."
    o "..."

# game/scripts/scriptbed.rpy:2289
translate spanish gameover08_bd22477f:

    # n "Olive silently curls up leaving some space between them and Patches."
    n "Olive se acurruca silenciosamente dejando algo de espacio entre ella y Patches."

# game/scripts/scriptbed.rpy:2291
translate spanish gameover08_c32b0c25:

    # n "After some time they fall asleep..."
    n "Después de un tiempo se quedan dormidos..."

# game/scripts/scriptbed.rpy:2303
translate spanish purrgatoryend_c7cfdb95:

    # n "A portal appears in the void."
    n "Aparece un portal en el vacío."

# game/scripts/scriptbed.rpy:2304
translate spanish purrgatoryend_529dc330:

    # n "Olive and Patches are asleep."
    n "Olive y Patches están dormidos."

# game/scripts/scriptbed.rpy:2305
translate spanish purrgatoryend_62a9a671:

    # n "A paw reaches out and grabs Olive's leg, pulling them through the portal."
    n "Una pata se extiende y agarra la pierna de Olive, empujándola a través del portal."

translate spanish strings:

    # game/scripts/scriptbed.rpy:335
    old "{color=#a9d4ff}Inspect bunkbed.{/color}"
    new "{color=#a9d4ff}Inspeccionar la litera.{/color}"

    # game/scripts/scriptbed.rpy:335
    old "{color=#a9d4ff}Inspect desks.{/color}"
    new "{color=#a9d4ff}Inspeccionar los escritorios.{/color}"

    # game/scripts/scriptbed.rpy:335
    old "{color=#a9d4ff}Inspect magic circle.{/color}"
    new "{color=#a9d4ff}Inspeccionar el círculo mágico.{/color}"

    # game/scripts/scriptbed.rpy:335
    old "{color=#a9d4ff}Inspect window.{/color}"
    new "{color=#a9d4ff}Inspeccionar ventana.{/color}"

    # game/scripts/scriptbed.rpy:335
    old "{color=#a9d4ff}Talk to Coco.{/color}"
    new "{color=#a9d4ff}Hablar con Coco.{/color}"

    # game/scripts/scriptbed.rpy:401
    old "Coco fights."
    new "Coco pelea."

    # game/scripts/scriptbed.rpy:401
    old "{color=#ffffff66}Coco fights.{/color}"
    new "{color=#ffffff66}Coco pelea.{/color}"

    # game/scripts/scriptbed.rpy:401
    old "{color=#ffffff66}Coco runs.{/color}"
    new "{color=#ffffff66}Coco corre.{/color}"

    # game/scripts/scriptbed.rpy:401
    old "Coco runs."
    new "Coco corre."

    # game/scripts/scriptbed.rpy:709
    old "Compliment Coco."
    new "Felicitar a Coco."

    # game/scripts/scriptbed.rpy:709
    old "Admire it silently."
    new "Admírarlo en silencio."

    # game/scripts/scriptbed.rpy:769
    old "Stare at Coco."
    new "Mirar fijamente a Coco."

    # game/scripts/scriptbed.rpy:860
    old "Beg Sparky."
    new "Suplicarle a Sparky."

    # game/scripts/scriptbed.rpy:860
    old "{color=#ffffff66}Beg Sparky.{/color}"
    new "{color=#ffffff66}Suplicarle a Sparky.{/color}"

    # game/scripts/scriptbed.rpy:860
    old "{color=#ffffff66}Beg the spirit.{/color}"
    new "{color=#ffffff66}Suplicarle al espíritu.{/color}"

    # game/scripts/scriptbed.rpy:860
    old "Beg the spirit."
    new "Suplicarle al espíritu."

    # game/scripts/scriptbed.rpy:993
    old "Save Angel."
    new "Salvar a Angel."

    # game/scripts/scriptbed.rpy:993
    old "{color=#ffffff66}Save Angel.{/color}"
    new "{color=#ffffff66}Salvar a Angel.{/color}"

    # game/scripts/scriptbed.rpy:993
    old "{color=#ffffff66}Run away.{/color}"
    new "{color=#ffffff66}Huir.{/color}"

    # game/scripts/scriptbed.rpy:993
    old "Run away."
    new "Huir."

    # game/scripts/scriptbed.rpy:1157
    old "Coco survives."
    new "Coco sobrevive."

    # game/scripts/scriptbed.rpy:1157
    old "{color=#ffffff66}Coco survives.{/color}"
    new "{color=#ffffff66}Coco sobrevive.{/color}"

    # game/scripts/scriptbed.rpy:1157
    old "{color=#ffffff66}Coco dies.{/color}"
    new "{color=#ffffff66}Coco muere.{/color}"

    # game/scripts/scriptbed.rpy:1157
    old "Coco dies."
    new "Coco muere."

    # game/scripts/scriptbed.rpy:2016
    old "Ask about Angel."
    new "Preguntar por Angel."

    # game/scripts/scriptbed.rpy:2016
    old "Ask about hobbies."
    new "Preguntar por aficiones."

    # game/scripts/scriptbed.rpy:2016
    old "Ask about his body."
    new "Preguntar por su cuerpo."

    # game/scripts/scriptbed.rpy:2016
    old "Give Patches a hug."
    new "Darle un abrazo a Patches."

    # game/scripts/scriptbed.rpy:2016
    old "Give Patches a punch."
    new "Darle un puñetazo a Patches."

    # game/scripts/scriptbed.rpy:2016
    old "Nap."
    new "Siesta."

    # game/scripts/scriptbed.rpy:2052
    old "Heart break."
    new "Corazón roto."

    # game/scripts/scriptbed.rpy:2052
    old "Betrayal."
    new "Traición."

    # game/scripts/scriptbed.rpy:2249
    old "Promise to save Patches."
    new "Prometer salvar a Patches."

    # game/scripts/scriptbed.rpy:2249
    old "{color=#ffffff66}Promise to save Patches.{/color}"
    new "{color=#ffffff66}Prometer salvar a Patches.{/color}"

    # game/scripts/scriptbed.rpy:2249
    old "{color=#ffffff66}Say nothing.{/color}"
    new "{color=#ffffff66}Callar.{/color}"

    # game/scripts/scriptbed.rpy:2249
    old "Say nothing."
    new "Callar."

