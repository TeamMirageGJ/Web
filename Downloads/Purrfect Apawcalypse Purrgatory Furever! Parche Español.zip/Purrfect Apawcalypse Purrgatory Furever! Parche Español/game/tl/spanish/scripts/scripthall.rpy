# TODO: Translation updated at 2024-11-25 12:57

# game/scripts/scripthall.rpy:16
translate spanish hallintro_fe0c528e:

    # o "ANGEL!! BROWNIE!"
    o "¡¡ANGEL!! ¡BROWNIE!"

# game/scripts/scripthall.rpy:19
translate spanish hallintro_88f678aa:

    # b "Olly!!"
    b "¡¡Oly!!"

# game/scripts/scripthall.rpy:22
translate spanish hallintro_7d73d27f:

    # a "Where's Coco?"
    a "¿Dónde está Coco?"

# game/scripts/scripthall.rpy:25
translate spanish hallintro_da0615e2:

    # o "Sh-she's okay!"
    o "¡El-ella está bien!"

# game/scripts/scripthall.rpy:27
translate spanish hallintro_4e070ce1:

    # o "A-actually she might be stuck in a tree but we can help her later!"
    o "De hecho, puede que esté atrapada en un árbol, ¡pero podemos ayudarla más tarde!"

# game/scripts/scripthall.rpy:31
translate spanish hallintro_c21b8775:

    # n "Olive hands Brownie the pan and Angel the pot."
    n "Olive le entrega a Brownie la sartén y a Angel la olla."

# game/scripts/scripthall.rpy:33
translate spanish hallintro_2b91f9dc:

    # b "Angel! Caught with pot, how shameful!"
    b "¡Angel! ¡Atrapado con la 'hierba', qué vergüenza!"

# game/scripts/scripthall.rpy:36
translate spanish hallintro_b2d13670:

    # a "She's been making these horrible jokes since you and Coco left."
    a "Ha estado haciendo chistes horribles desde que tú y Coco se fueron."

# game/scripts/scripthall.rpy:41
translate spanish hallintro_efa8b87f:

    # n "Something slams into the bedroom door!" with vpunch
    n "¡Algo golpea la puerta del dormitorio!" with vpunch

# game/scripts/scripthall.rpy:43
translate spanish hallintro_0d15324c:

    # b "Alright let's get serious!"
    b "¡Muy bien, pongámonos serios!"

# game/scripts/scripthall.rpy:46
translate spanish hallintro_596836ba:

    # a "I'm taking out Patches."
    a "Yo me encargo de Patches."

# game/scripts/scripthall.rpy:49
translate spanish hallintro_5098a742:

    # n "Brownie and Angel push the heavy flower pot out of the way."
    n "Brownie y Angel apartan la pesada maceta."

# game/scripts/scripthall.rpy:59
translate spanish hallintro_3c4e4f38:

    # n "Sparky bursts out of the room!" with vpunch
    n "¡Sparky sale corriendo de la habitación!" with vpunch

# game/scripts/scripthall.rpy:62
translate spanish hallintro_b056b16f:

    # n "He grabs Brownie!" with vpunch
    n "¡Él agarra a Brownie!" with vpunch

# game/scripts/scripthall.rpy:64
translate spanish hallintro_ba20c9d9:

    # b "ACK!!"
    b "¡¡ACK!!"

# game/scripts/scripthall.rpy:69
translate spanish hallintro_606bf070:

    # n "Angel slams his pot into the back of Sparky's head." with vpunch
    n "Angel golpea con su olla la parte posterior de la cabeza de Sparky." with vpunch

# game/scripts/scripthall.rpy:71
translate spanish hallintro_8bb0547b:

    # n "It does a little more than just knock him out." with vpunch
    n "Hace un poco más que simplemente dejarlo inconsciente." with vpunch

# game/scripts/scripthall.rpy:73
translate spanish hallintro_e60216c7:

    # b "OH JEEZ!! I guess I'll take Patches then!"
    b "¡¡OH DIOS!! ¡Supongo que entonces elegiré a Patches!"

# game/scripts/scripthall.rpy:83
translate spanish hallintro_d5069ae0:

    # p "You'll do what now?"
    p "¿Qué es lo que piensas hacer?"

# game/scripts/scripthall.rpy:88
translate spanish hallintro_8b5a57f6:

    # n "A flurry of knives rains down on Brownie!" with vpunch
    n "¡Una ráfaga de cuchillos cae sobre Brownie!" with vpunch

# game/scripts/scripthall.rpy:92
translate spanish hallintro_031e7a40:

    # n "She tries to block the storm with her pan but there's too many!" with vpunch
    n "Ella intenta bloquear la tormenta con su sartén ¡pero hay demasiados!" with vpunch

# game/scripts/scripthall.rpy:93
translate spanish hallintro_0f7a2bfe:

    # b "AGHH!!"
    b "¡¡AGHH!!"

# game/scripts/scripthall.rpy:96
translate spanish hallintro_76a42031:

    # n "Angel swings his pot at Patches." with vpunch
    n "Angel lanza su olla hacia Patches." with vpunch

# game/scripts/scripthall.rpy:102
translate spanish hallintro_3922284b:

    # n "It's too late." with vpunch
    n "Es demasiado tarde." with vpunch

# game/scripts/scripthall.rpy:105
translate spanish hallintro_5cc264a3:

    # o "AHHH!!" with vpunch
    o "¡¡AHHH!!" with vpunch

# game/scripts/scripthall.rpy:109
translate spanish hallintro_2fc48725:

    # n "Olive runs for the bedroom!"
    n "¡Olive corre hacia el dormitorio!"

# game/scripts/scripthall.rpy:128
translate spanish hallintro_eea3fd04:

    # n "The bedroom door has broken down!"
    n "¡La puerta del dormitorio se ha roto!"

# game/scripts/scripthall.rpy:133
translate spanish hallintro_d30e6cfb:

    # n "Sparky grabs Brownie!" with vpunch
    n "¡Sparky agarra a Brownie!" with vpunch

# game/scripts/scripthall.rpy:135
translate spanish hallintro_83c2d000:

    # b "AGHH WHY ME?! Isn't Angel the one you're all mad at?!"
    b "AGHH ¡¿POR QUÉ YO?! ¿No es Angel con quien estás enojado?"

# game/scripts/scripthall.rpy:138
translate spanish hallintro_282b0d9e:

    # a "Wow thanks..."
    a "Vaya, gracias..."

# game/scripts/scripthall.rpy:140
translate spanish hallintro_5bb35625:

    # n "Sparky grips Brownie's neck!"
    n "¡Sparky agarra el cuello de Brownie!"

# game/scripts/scripthall.rpy:144
translate spanish hallintro_da4321a9:

    # n "Olive jumps on Sparky's back almost knocking him over!" with vpunch
    n "¡Olive salta sobre la espalda de Sparky y casi lo derriba!" with vpunch

# game/scripts/scripthall.rpy:146
translate spanish hallintro_ccdbc4d0:

    # n "Brownie escapes his grasp!"
    n "¡Brownie se escapa de sus manos!"

# game/scripts/scripthall.rpy:148
translate spanish hallintro_a511c6af:

    # o "BAD DOG!!"
    o "¡¡PERRO MALO!!"

# game/scripts/scripthall.rpy:158
translate spanish hallintro_8c5eba37:

    # c "MOVE OLIVE!"
    c "¡MUÉVETE OLIVE!"

# game/scripts/scripthall.rpy:161
translate spanish hallintro_ebf6e452:

    # n "Olive instinctively hops off of Sparky, narrowly missing a fatal blow."
    n "Olive salta de Sparky por puro instinto y evita por los pelos un golpe fatal."

# game/scripts/scripthall.rpy:167
translate spanish hallintro_feba574d:

    # n "Coco smashes Sparky's head in with the toilet lid." with vpunch
    n "Coco golpea la cabeza de Sparky con la tapa del inodoro." with vpunch

# game/scripts/scripthall.rpy:169
translate spanish hallintro_28e628d2:

    # n "His body falls to the floor." with vpunch
    n "Su cuerpo cae al suelo." with vpunch

# game/scripts/scripthall.rpy:171
translate spanish hallintro_07d75417:

    # o "AHHHHHH!!"
    o "¡¡AHHHHHH!!"

# game/scripts/scripthall.rpy:174
translate spanish hallintro_af0e251f:

    # c "Now's not the time, we still need..."
    c "Ahora no es el momento, todavía necesitamos..."

# game/scripts/scripthall.rpy:178
translate spanish hallintro_74287147:

    # n "Coco notices out of the corner of her eye. Zombies are rising from the living room."
    n "Coco alcanza a ver de reojo que unos zombis surgen de la sala de estar."

# game/scripts/scripthall.rpy:180
translate spanish hallintro_d4ea7499:

    # c "What?! When did they..."
    c "¡¿Qué?! ¿Cuándo ellos...?"

# game/scripts/scripthall.rpy:189
translate spanish hallintro_d615f059:

    # p "You broke my toy!"
    p "¡Rompiste mi juguete!"

# game/scripts/scripthall.rpy:191
translate spanish hallintro_73a60a07:

    # p "Do you have any idea how long it took to whittle down his psyche?"
    p "¿Tienes alguna idea de cuánto tiempo tardé en reducir su psique?"

# game/scripts/scripthall.rpy:194
translate spanish hallintro_27f31c70:

    # n "Without hesitation Coco lunges at Patches!"
    n "¡Sin dudarlo, Coco se abalanza sobre Patches!"

# game/scripts/scripthall.rpy:197
translate spanish hallintro_54bec2dd:

    # n "He stops her in her tracks," with vpunch
    n "Él la detiene en seco," with vpunch

# game/scripts/scripthall.rpy:202
translate spanish hallintro_45a4e759:

    # n "And breaks her neck!" with vpunch
    n "¡Y le rompe el cuello!" with vpunch

# game/scripts/scripthall.rpy:213
translate spanish hallintro_8aaf1cfe:

    # b "AHHH! COCO!"
    b "¡AHHH! ¡COCO!"

# game/scripts/scripthall.rpy:216
translate spanish hallintro_3d07fbfc:

    # p "It'd be pretty easy to kill you all here but I think the zombies deserve a little justice too."
    p "Sería bastante fácil acabar con ustedes aquí, pero creo que los zombies también merecen un poco de justicia."

# game/scripts/scripthall.rpy:222
translate spanish hallintro_70cdca5d:

    # n "Olive manages to jump onto Patches!" with vpunch
    n "¡Olive logra saltar sobre Patches!" with vpunch

# game/scripts/scripthall.rpy:223
translate spanish hallintro_decdf478:

    # p "AHHH!"
    p "¡AHHH!"

# game/scripts/scripthall.rpy:227
translate spanish hallintro_ccf0aea7:

    # n "Brownie grabs Olive's and Angel's paws and runs to the bathroom."
    n "Brownie agarra las patas de Olive y Angel y corre hacia el baño."

# game/scripts/scripthall.rpy:233
translate spanish hallintro_cccbac77:

    # n "But Patches traps Angel before he can slip through the door!" with vpunch
    n "¡Pero Patches atrapa a Angel antes de que pueda atravesar la puerta!" with vpunch

# game/scripts/scripthall.rpy:263
translate spanish hallintro_ccbd1138:

    # n "Olive and Coco make it upstairs to find Brownie knocked down at Sparky's feet."
    n "Olive y Coco suben las escaleras y encuentran a Brownie derribada a los pies de Sparky."

# game/scripts/scripthall.rpy:264
translate spanish hallintro_96a821f4:

    # n "Angel has Sparky in a chokehold but it doesn't seem to phase him."
    n "Angel tiene a Sparky estrangulado pero eso no parece afectarlo."

# game/scripts/scripthall.rpy:269
translate spanish hallintro_fe4344bd:

    # n "Sparky stomps on Brownie's leg breaking it!" with vpunch
    n "¡Sparky pisotea la pierna de Brownie y se la rompe!" with vpunch

# game/scripts/scripthall.rpy:270
translate spanish hallintro_153066f1:

    # b "AaAaHHHHHHHHHHHHHH!!"
    b "¡¡AaaaHHHHHHHHHHHHHH!!"

# game/scripts/scripthall.rpy:273
translate spanish hallintro_8edbf2e0:

    # "" with vpunch
    "" with vpunch

# game/scripts/scripthall.rpy:276
translate spanish hallintro_cc8ea4cc:

    # n "He grabs hold of Angel's arm from around his neck," with vpunch
    n "Él agarra el brazo de Angel," with vpunch

# game/scripts/scripthall.rpy:279
translate spanish hallintro_f88b46fc:

    # n "And crushes it in his grip!" with vpunch
    n "¡Y lo aplasta!" with vpunch

# game/scripts/scripthall.rpy:281
translate spanish hallintro_dc854106:

    # a "UGGGHHHH!!!"
    a "¡¡¡UGGGHHHH!!!"

# game/scripts/scripthall.rpy:284
translate spanish hallintro_1680e2c4:

    # n "Sparky swings Angel by his broken arm onto the ground." with vpunch
    n "Sparky balancea a Angel por su brazo roto y lo tira al suelo." with vpunch

# game/scripts/scripthall.rpy:286
translate spanish hallintro_0e1071c6:

    # o "ST-STOP!! WHO ARE YOU?! WHY ARE YOU DOING THIS?!"
    o "¡¡PARA!! ¡¿QUIÉN ERES?! ¡¿POR QUÉ ESTÁS HACIENDO ESTO?!"

# game/scripts/scripthall.rpy:289
translate spanish hallintro_5027f7d1:

    # n "All Sparky does is shoot Olive a smile."
    n "Todo lo que Sparky hace es sonreírle a Olive."

# game/scripts/scripthall.rpy:292
translate spanish hallintro_044186f8:

    # n "Sparky slams into the ground as though gravity had multiplied." with vpunch
    n "Sparky se estrella contra el suelo como si la gravedad se hubiera multiplicado." with vpunch

# game/scripts/scripthall.rpy:293
translate spanish hallintro_976183e0:

    # s "AGH!"
    s "¡AGH!"

# game/scripts/scripthall.rpy:302
translate spanish hallintro_d5fa9df2:

    # c "I'll make you feel a pain WORSE THEN DEATH!!!"
    c "¡¡¡Te haré sentir un dolor PEOR QUE LA MUERTE!!!"

# game/scripts/scripthall.rpy:304
translate spanish hallintro_969fc6a1:

    # c "Once you're out of that body that is!"
    c "¡Una vez que estés fuera de ese cuerpo!"

# game/scripts/scripthall.rpy:307
translate spanish hallintro_968cd29d:

    # s "AAAaAaAaAaHHHHH!!!" with vpunch
    s "AAAaAaAaAaHHHHH!!!" with vpunch

# game/scripts/scripthall.rpy:312
translate spanish hallintro_f2b54e24:

    # n "Whatever soul is inhabiting Sparky's body is forced out!" with vpunch
    n "Cualquier alma que habite el cuerpo de Sparky es expulsada a la fuerza!" with vpunch

# game/scripts/scripthall.rpy:322
translate spanish hallintro_0cfb1091:

    # n "The soul looks a little disoriented."
    n "El alma parece un poco desorientada."

# game/scripts/scripthall.rpy:323
translate spanish hallintro_7f30a428:

    # g "AHH!"
    g "¡AHH!"

# game/scripts/scripthall.rpy:325
translate spanish hallintro_d504f5c9:

    # o "TH-THAT DOG!!"
    o "¡¡E-ESE PERRO!!"

# game/scripts/scripthall.rpy:332
translate spanish hallintro_be6a728a:

    # n "The ghostly dog escapes through a wall."
    n "El perro fantasmal se escapa por una pared."

# game/scripts/scripthall.rpy:334
translate spanish hallintro_f4d64cf7:

    # c "AGH WHO CARES!!! ANGEL!"
    c "¡¡¡A QUIÉN LE IMPORTA!!! ¡ANGEL!"

# game/scripts/scripthall.rpy:340
translate spanish hallintro_97fa453f:

    # n "Coco runs to Angel and Brownie's sides."
    n "Coco corre hacia Angel y Brownie."

# game/scripts/scripthall.rpy:342
translate spanish hallintro_143cd3fd:

    # c "Angel are you okay?! Brownie?!"
    c "Angel ¿estás bien? ¡¿Brownie?!"

# game/scripts/scripthall.rpy:345
translate spanish hallintro_aad247d3:

    # a "Ughh."
    a "Ughh."

# game/scripts/scripthall.rpy:348
translate spanish hallintro_7c9a5129:

    # b "Ow."
    b "Ay."

# game/scripts/scripthall.rpy:351
translate spanish hallintro_06148f9d:

    # c "Is that really all you have to say?!?"
    c "¿¡¿Eso es realmente todo lo que tienen para decir?!?"

# game/scripts/scripthall.rpy:354
translate spanish hallintro_7a3b7a11:

    # b "Um..."
    b "Eh..."

# game/scripts/scripthall.rpy:355
translate spanish hallintro_6a2cd7be:

    # b "I'm a little stunned at everything that's happened and I'm in a lot of pain so YES. OW IS ALL I HAVE TO SAY."
    b "Estoy un poco atónita por todo lo que ha pasado y tengo mucho dolor así que SÍ. AHORA ES TODO LO QUE TENGO QUE DECIR."

# game/scripts/scripthall.rpy:358
translate spanish hallintro_fe8decb6:

    # a "UUUGH..."
    a "UUUGH..."

# game/scripts/scripthall.rpy:360
translate spanish hallintro_dddd77b6:

    # a "... I'm just glad I didn't hold the door while Brownie made 'your-mom' jokes for nothing."
    a "... Me habría gustado no haber sostenido la puerta mientras Brownie hacía bromas sobre 'tu mamá' en vano."

# game/scripts/scripthall.rpy:363
translate spanish hallintro_e2b63042:

    # b "I thought I could take him down with sick burns!!"
    b "¡¡Pensé que podría derribarlo con chistes enfermizos!!"

# game/scripts/scripthall.rpy:368
translate spanish hallintro_8699fe08:

    # c "I'm just glad you're okay. Both of you."
    c "¡Me alegro de que estén bien!"

# game/scripts/scripthall.rpy:371
translate spanish hallintro_850ef128:

    # b "..."
    b "..."

# game/scripts/scripthall.rpy:374
translate spanish hallintro_c3316425:

    # o "Th-that dog..."
    o "E-ese perro..."

# game/scripts/scripthall.rpy:376
translate spanish hallintro_dc51283b:

    # o "Oh w-wait! Sparky!! Is he okay?!"
    o "¡Oh, espera! Sparky!! ¡¿Está bien?!"

# game/scripts/scripthall.rpy:379
translate spanish hallintro_fce0e490:

    # c "It might take a moment for his soul to find his way back to his body."
    c "Puede que su alma tarde un momento en encontrar el camino de regreso a su cuerpo."

# game/scripts/scripthall.rpy:381
translate spanish hallintro_7cdb93d7:

    # n "Sparky's body starts to stir."
    n "El cuerpo de Sparky comienza a agitarse."

# game/scripts/scripthall.rpy:383
translate spanish hallintro_a0aced23:

    # c "Oh! That's him now!"
    c "¡Oh! ¡Ese es él ahora!"

# game/scripts/scripthall.rpy:392
translate spanish hallintro_7c55a43d:

    # n "Sparky coughs a bit and slowly sits up dazed."
    n "Sparky tose un poco y lentamente se sienta aturdido."

# game/scripts/scripthall.rpy:394
translate spanish hallintro_78f787f7:

    # s "... O-Olive?"
    s "... ¿O-Olive?"

# game/scripts/scripthall.rpy:396
translate spanish hallintro_1cd8c9ec:

    # s "Brownie?! ACK! Is your leg broken?!"
    s "¡¿Brownie?! ¡ACK! ¡¿Tienes la pierna rota?!"

# game/scripts/scripthall.rpy:401
translate spanish hallintro_ee69a170:

    # b "Uh, YEAH. YOU BROKE IT."
    b "Eh, SÍ. LA ROMPISTE."

# game/scripts/scripthall.rpy:404
translate spanish hallintro_1ca0c8a3:

    # s "WHAT?!?!"
    s "¡¿¡¿QUÉ?!?!"

# game/scripts/scripthall.rpy:406
translate spanish hallintro_14b61f60:

    # s "O-oh no oh fuck."
    s "O-oh no oh mierda."

# game/scripts/scripthall.rpy:407
translate spanish hallintro_f8b3cef5:

    # s "I can't believe it. I can't believe I let him knock me out and now look at you!!"
    s "No puedo creerlo. ¡¡No puedo creer que me haya dejado noquear y ahora miren cómo están!!"

# game/scripts/scripthall.rpy:410
translate spanish hallintro_8ddcffb5:

    # a "... You seem to have broken my arm as well..."
    a "... Parece que también me has roto el brazo..."

# game/scripts/scripthall.rpy:413
translate spanish hallintro_cbd3fd31:

    # s "NOOoOoOoOoOo!!!"
    s "¡¡¡NOOoOoOoOoOo!!!"

# game/scripts/scripthall.rpy:416
translate spanish hallintro_c2175868:

    # o "NOoOoOo!!"
    o "¡¡NOoOoOo!!"

# game/scripts/scripthall.rpy:419
translate spanish hallintro_5d920b0e:

    # b "AGHH don't start howling you guys it's so lame!"
    b "¡AGHH, no empiecen a aullar, muchachos, es tan lamentable!"

# game/scripts/scripthall.rpy:422
translate spanish hallintro_5a0cd73c:

    # s "Wait. I don't hear the voices anymore. How did you guys fix me?!"
    s "Esperen. Ya no escucho las voces. ¡¿Cómo me arreglaron?!"

# game/scripts/scripthall.rpy:428
translate spanish hallintro_ba4d80bc:

    # c "You were possessed!! I've forced the spirit out but she's flown away to Dog knows where; probably back to Patches for further instructions."
    c "¡¡Estabas poseído!! Expulsé al espíritu, pero huyó a sabra el perro dónde; probablemente con Patches para recibir más instrucciones."

# game/scripts/scripthall.rpy:430
translate spanish hallintro_7a842062:

    # c "Ugh they could attack us at any moment!"
    c "¡Uf, podrían atacarnos en cualquier momento!"

# game/scripts/scripthall.rpy:433
translate spanish hallintro_50d35880:

    # s "We NEED to find her!"
    s "¡NECESITAMOS encontrarla!"

# game/scripts/scripthall.rpy:436
translate spanish hallintro_3f998fda:

    # c "You have GOT to be kidding me! Now's not the time, we need to make a plan!"
    c "¡TIENES que estar bromeando! ¡Ahora no es el momento, tenemos que hacer un plan!"

# game/scripts/scripthall.rpy:439
translate spanish hallintro_0780bf31:

    # o "Th-the zombies! Th-they can help us!!"
    o "¡Lo-los zombies! ¡¡El-ellos pueden ayudarnos!!"

# game/scripts/scripthall.rpy:443
translate spanish hallintro_cdf63ec1:

    # b "ZOMBIES?!"
    b "¡¿ZOMBIS?!"

# game/scripts/scripthall.rpy:446
translate spanish hallintro_eaa5d0ef:

    # c "Oh right. I guess some of them are on our side now?"
    c "Ah, claro. ¿Supongo que algunos de ellos están de nuestro lado ahora?"

# game/scripts/scripthall.rpy:449
translate spanish hallintro_86940f42:

    # o "They're all on our s-side! They're all good friends and all good dogs!!!"
    o "¡Están todos de nuestro lado! ¡¡¡Todos son buenos amigos y buenos perros!!!"

# game/scripts/scripthall.rpy:452
translate spanish hallintro_f7ceef59:

    # n "Olive wiggles in excitement. Their friends do not share the same sentiment."
    n "Olive se mueve emocionada. Sus amigos no comparten el mismo sentimiento."

# game/scripts/scripthall.rpy:454
translate spanish hallintro_4c6e0794:

    # c "Alright. Let's go downstairs and make a plan with them. Can you walk Sparky?"
    c "Está bien. Bajemos y hagamos un plan con ellos. ¿Puedes caminar Sparky?"

# game/scripts/scripthall.rpy:457
translate spanish hallintro_8331446c:

    # n "Sparky stands up slowly, he's a little wobbly but seems to be well enough."
    n "Sparky se levanta lentamente, está un poco tambaleante pero parece estar bastante bien."

# game/scripts/scripthall.rpy:459
translate spanish hallintro_ea9b5b89:

    # s "Yup!"
    s "¡Si!"

# game/scripts/scripthall.rpy:462
translate spanish hallintro_557cb61b:

    # c "And you Brownie?"
    c "¿Y tú Brownie?"

# game/scripts/scripthall.rpy:465
translate spanish hallintro_611ba564:

    # b "Shut the hell up."
    b "Cállate de una puta vez."

# game/scripts/scripthall.rpy:469
translate spanish hallintro_313a5aac:

    # c "AHAHAH I'm just kidding. Sparky you're buff, you carry her."
    c "AHAHAH Sólo estoy bromeando. Sparky, eres grande, la llevarás."

# game/scripts/scripthall.rpy:472
translate spanish hallintro_cb4c8861:

    # s "I g-guess it's the least I could do."
    s "Supongo que es lo menos que puedo hacer."

# game/scripts/scripthall.rpy:475
translate spanish hallintro_3fa266d8:

    # n "Brownie reluctantly allows herself to be carried."
    n "Brownie se deja llevar a regañadientes."

# game/scripts/scripthall.rpy:497
translate spanish hallintro_4d5b5dfe:

    # n "The bedroom door slams shut behind them!" with vpunch
    n "¡La puerta del dormitorio se cierra de golpe detrás de ellos!" with vpunch

# game/scripts/scripthall.rpy:499
translate spanish hallintro_7f98b8e7:

    # o "AHH! I th-think we made Coco mad!"
    o "¡AH! ¡Creo que hicimos enojar a Coco!"

# game/scripts/scripthall.rpy:504
translate spanish hallintro_0759f665:

    # a "I don't like her when she's mad..."
    a "No me gusta cuando está enojada..."

# game/scripts/scripthall.rpy:509
translate spanish hallintro_a3eabf3e:

    # b "MAAAN we'd get rid of the zombies so much faster if she'd just let us help!"
    b "¡Diiios! ¡Acabaríamos con los zombis mucho más rápido si tan solo nos dejara ayudar!"

# game/scripts/scripthall.rpy:513
translate spanish hallintro_d35c29aa:

    # o "If we want to talk to Coco we'll n-need a better reason to bother her..."
    o "Si queremos hablar con Coco n-necesitaremos una razón mejor para molestarla..."

# game/scripts/scripthall.rpy:532
translate spanish hallintro_98986289:

    # n "Angel and Brownie slam the door behind them." with vpunch
    n "Angel y Brownie azotan la puerta tras de ellos." with vpunch

# game/scripts/scripthall.rpy:534
translate spanish hallintro_cd4c3f0a:

    # n "With Sparky pounding on the other side they struggle to keep it shut!"
    n "¡Con Sparky golpeando al otro lado, luchan por mantenerla cerrada!"

# game/scripts/scripthall.rpy:536
translate spanish hallintro_ee9934b4:

    # a "Quick, barricade the door!!"
    a "¡¡Rápido, bloqueen la puerta!!"

# game/scripts/scripthall.rpy:539
translate spanish hallintro_07ef6a0e:

    # b "W-we're not strong enough to hold it back!"
    b "¡N-no somos lo suficientemente fuertes para detenerlo!"

# game/scripts/scripthall.rpy:545
translate spanish hallintro_5572d5d3:

    # n "Coco and Olive drag a heavy flower pot from the hall to the door."
    n "Coco y Olive arrastran una pesada maceta desde el pasillo hasta la puerta."

# game/scripts/scripthall.rpy:554
translate spanish hallintro_0c90abcc:

    # n "Angel, Brownie and the pot just manage to hold the door shut but Sparky's already putting a crack in the door!"
    n "Angel, Brownie y la maceta apenas logran mantener la puerta cerrada, ¡pero Sparky ya la está agrietando!"

# game/scripts/scripthall.rpy:556
translate spanish hallintro_a5aa9ca3:

    # c "M-my wand!! THAT ZOMBIE TOOK MY WAND!"
    c "M-mi varita!! ¡ESE ZOMBIE TOMÓ MI VARITA!"

# game/scripts/scripthall.rpy:559
translate spanish hallintro_e8f8f29b:

    # b "I-isn't there another way to stop them?!"
    b "¡¿No hay otra manera de detenerlos?!"

# game/scripts/scripthall.rpy:562
translate spanish hallintro_26ff83f7:

    # c "Nonono this is why he targeted me. That wand is the only thing that can banish him for good. Oh for Cat's sake."
    c "¡No, no, no! Por eso me eligió como blanco. Esa varita es lo único que puede desterrarlo para siempre. ¡Ay, por el amor del Gato!"

# game/scripts/scripthall.rpy:564
translate spanish hallintro_93268040:

    # c "Okay okay we'll just have to do this the old fashioned way!"
    c "Está bien, ¡tendremos que hacer esto a la antigua!"

# game/scripts/scripthall.rpy:565
translate spanish hallintro_8721f2b2:

    # c "We need a weapon! We need to get my wand back and fighting is the only way!!"
    c "¡Necesitamos un arma! ¡¡Necesitamos recuperar mi varita y luchar es la única manera!!"

# game/scripts/scripthall.rpy:570
translate spanish hallintro_238b60ed:

    # o "What?! W-we're not going to hurt Sparky are we?!"
    o "¡¿Qué?! N-no vamos a lastimar a Sparky, ¿verdad?"

# game/scripts/scripthall.rpy:573
translate spanish hallintro_21eff139:

    # b "Uhh..."
    b "Eh..."

# game/scripts/scripthall.rpy:575
translate spanish hallintro_bb8e4b4e:

    # a "..."
    a "..."

# game/scripts/scripthall.rpy:577
translate spanish hallintro_b6ed249b:

    # c "Come on Olive, help me search! These two need to hold the door shut."
    c "¡Vamos Olive, ayúdame a buscar! Estos dos necesitan mantener la puerta cerrada."

# game/scripts/scripthall.rpy:580
translate spanish hallintro_e9f40650:

    # o "O-okay..."
    o "E-está bien..."

# game/scripts/scripthall.rpy:650
translate spanish hallmenubath_36a9298a:

    # n "Olive tries to open the door."
    n "Olive intenta abrir la puerta."

# game/scripts/scripthall.rpy:656
translate spanish hallmenubath_c5673842:

    # b "HEY!! Can't you knock first?!" with vpunch
    b "¡¡¡HEY!!! ¿No puedes tocar primero?" with vpunch

# game/scripts/scripthall.rpy:670
translate spanish hallportraits_1147d13e:

    # n "On the wall hangs a large portrait of Angel and Coco as kittens!"
    n "¡En la pared cuelga un gran retrato de Angel y Coco cuando eran gatitos!"

# game/scripts/scripthall.rpy:680
translate spanish hallportraits_a0eae2bd:

    # o "Angel and C-Coco were so cute as kittens!!"
    o "¡¡Angel y C-Coco eran tan lindos como gatitos!!"

# game/scripts/scripthall.rpy:683
translate spanish hallportraits_a93ba318:

    # g "That's Angel and Coco?!"
    g "¡¿Esos son Angel y Coco?!"

# game/scripts/scripthall.rpy:685
translate spanish hallportraits_3f61af9f:

    # g "No way..."
    g "De ninguna manera..."

# game/scripts/scripthall.rpy:686
translate spanish hallportraits_a237cb98:

    # g "They're so..."
    g "Son tan..."

# game/scripts/scripthall.rpy:689
translate spanish hallportraits_dc777305:

    # g "CUTE!!"
    g "¡¡LINDOS!!"

# game/scripts/scripthall.rpy:693
translate spanish hallportraits_7dea8e89:

    # n "Olive and Ginger gush over how cute these cats are."
    n "Olive y Ginger hablan con entusiasmo de lo lindos que son estos gatos."

# game/scripts/scripthall.rpy:713
translate spanish hallportraits_d41faa0c:

    # n "The zombies are appreciating the portrait."
    n "Los zombies aprecian el retrato."

# game/scripts/scripthall.rpy:714
translate spanish hallportraits_6d71e323:

    # n "It appears they don't recognize the cute kittens as the ones who killed them back at Hachiko High."
    n "Parece que no reconocen a los lindos gatitos como los que los mataron en el instituto Hachiko."

# game/scripts/scripthall.rpy:719
translate spanish hallportraits_c1d8743f:

    # c "I'd break this portrait over Patches' head if it meant we'd have to stop looking at it."
    c "Rompería este retrato sobre la cabeza de Patches si eso significara que tendríamos que dejar de verlo."

# game/scripts/scripthall.rpy:720
translate spanish hallportraits_4d6a0a59:

    # c "And also if it meant Patches keeled over and died."
    c "Y también si eso significaba que Patches se desplomaría y moriría."

# game/scripts/scripthall.rpy:723
translate spanish hallportraits_ba68060b:

    # o "I-it's a good thing we'd never d-do that, right?"
    o "E-es bueno que nunca h-hiciéramos eso, ¿verdad?"

# game/scripts/scripthall.rpy:742
translate spanish hallportraits_1c715b9a:

    # o "Y-you and Angel were so cute as kittens!"
    o "¡T-tú y Angel eran tan lindos como gatitos!"

# game/scripts/scripthall.rpy:745
translate spanish hallportraits_ca02378b:

    # c "Now's not the time Olive let's GO!"
    c "Ahora no es el momento Olive, ¡tenemos que irnos!"

# game/scripts/scripthall.rpy:748
translate spanish hallportraits_3ac665b2:

    # o "R-right!!"
    o "¡¡Correcto!!"

# game/scripts/scripthall.rpy:750
translate spanish hallportraits_7a3831bf:

    # n "Olive continues sniffing around for weapons."
    n "Olive continúa husmeando en busca de armas."

# game/scripts/scripthall.rpy:751
translate spanish hallportraits_d19f855d:

    # c "..."
    c "..."

# game/scripts/scripthall.rpy:754
translate spanish hallportraits_54642360:

    # c "Yeah we are pretty cute."
    c "Sí, somos muy lindos."

# game/scripts/scripthall.rpy:761
translate spanish hallportraits_1147d13e_1:

    # n "On the wall hangs a large portrait of Angel and Coco as kittens!"
    n "¡En la pared cuelga un gran retrato de Angel y Coco cuando eran gatitos!"

# game/scripts/scripthall.rpy:767
translate spanish hallportraits_6b4f4e99:

    # o "Angel and Coco as k-k-k-kittens?!?!"
    o "¿¡¿Angel y Coco como g-g-g-gatitos?!?!"

# game/scripts/scripthall.rpy:769
translate spanish hallportraits_f6a3e69f:

    # o "EVERYONE M-MUST SEE THIS!!"
    o "¡¡TODOS D-DEBEN VER ESTO!!"

# game/scripts/scripthall.rpy:778
translate spanish hallportraits_54b6aea5:

    # o "Y-You and Coco were so cute as kittens!"
    o "¡Tú y Coco eran tan lindos como gatitos!"

# game/scripts/scripthall.rpy:780
translate spanish hallportraits_bb12d861:

    # o "Angel!! You and Coco were so c-cute as kittens!"
    o "¡¡Angel!! ¡Tú y Coco eran tan lindos como gatitos!"

# game/scripts/scripthall.rpy:783
translate spanish hallportraits_e0f6bffb:

    # a "... Yeah..."
    a "... Sí..."

# game/scripts/scripthall.rpy:791
translate spanish hallportraits_b91d0ef7:

    # n "Angel looks somber."
    n "Angel parece sombrío."

# game/scripts/scripthall.rpy:793
translate spanish hallportraits_4694c2e8:

    # o "I-I mean you still look cute now!!"
    o "¡¡Quiero decir que todavía te ves lindo ahora!!"

# game/scripts/scripthall.rpy:796
translate spanish hallportraits_289f057b:

    # a "Ahaha th-that's not what bothers me... Mostly..."
    a "Ahaha e-eso no es lo que me molesta... Sobre todo..."

# game/scripts/scripthall.rpy:800
translate spanish hallportraits_cfb1dda2:

    # b "Is it being in the body of your own killer, constantly haunted by the thought of Patches taking it back from you in some violent plot?"
    b "¿Estar en el cuerpo de tu propio asesino, constantemente atormentado por la idea de que Patches te lo quite en algún complot violento?"

# game/scripts/scripthall.rpy:802
translate spanish hallportraits_bb8e4b4e:

    # a "..."
    a "..."

# game/scripts/scripthall.rpy:804
translate spanish hallportraits_210c06eb:

    # a "Yes."
    a "Sí."

# game/scripts/scripthall.rpy:805
translate spanish hallportraits_842b1721:

    # a "How did you know?"
    a "¿Cómo lo supiste?"

# game/scripts/scripthall.rpy:808
translate spanish hallportraits_e1ea4993:

    # b "Coco told me! She said you sleep with a toy skeleton to keep the nightmares away. Sounds counter-productive to me."
    b "¡Coco me lo dijo! Dijo que duermes con un esqueleto de juguete para mantener alejadas las pesadillas. Me parece contraproducente."

# game/scripts/scripthall.rpy:811
translate spanish hallportraits_957c0c3f:

    # a "Ugh Coco! My secrets!!"
    a "¡Uf Coco! Mis secretos!!"

# game/scripts/scripthall.rpy:815
translate spanish hallportraits_7529f3d4:

    # s "Wait, is it really possible that Patches' soul is in there with you?"
    s "Espera, ¿es realmente posible que el alma de Patches esté ahí contigo?"

# game/scripts/scripthall.rpy:816
translate spanish hallportraits_bd7e741c:

    # s "Do you ever hear him like... Talk to you?"
    s "¿Alguna vez lo oyes como... hablándote?"

# game/scripts/scripthall.rpy:819
translate spanish hallportraits_1ba6b5e3:

    # a "Oh not at all..."
    a "Ah, no del todo..."

# game/scripts/scripthall.rpy:821
translate spanish hallportraits_a87da9a7:

    # a "It is like him to remain dormant until the most entertaining moment though..."
    a "Aunque es propio de él permanecer inactivo hasta el momento más entretenido..."

# game/scripts/scripthall.rpy:824
translate spanish hallportraits_6a4df7d0:

    # b "How considerate!"
    b "¡Qué considerado!"

# game/scripts/scripthall.rpy:833
translate spanish hallportraits_e9ce610b:

    # a "... Whatever..."
    a "... Lo que sea..."

# game/scripts/scripthall.rpy:835
translate spanish hallportraits_0bafd5eb:

    # a "There's no point dwelling on the many horrific possibilities that lie ahead of us. Let's just forget about it."
    a "No ganamos nada dándole vueltas a las cosas horribles que podrían pasarnos. Mejor olvidémoslo."

# game/scripts/scripthall.rpy:846
translate spanish hallportraits_c467b0de:

    # a "I just worry about being in the body of my own killer, forever haunted by the idea of his soul overpowering my own in the fight for its control."
    a "Sólo me preocupa estar en el cuerpo de mi propio asesino, siempre atormentado por la idea de que su alma domine la mía en la lucha por el control."

# game/scripts/scripthall.rpy:850
translate spanish hallportraits_07abc845:

    # o "..."
    o "..."

# game/scripts/scripthall.rpy:852
translate spanish hallportraits_67b77715:

    # o "Haunted f-furever...?"
    o "¿A-Atormentado p-purr siempre...?"

# game/scripts/scripthall.rpy:855
translate spanish hallportraits_e1554201:

    # s "..."
    s "..."

# game/scripts/scripthall.rpy:857
translate spanish hallportraits_5a73fdc1:

    # s "I never thought of it like that. Is it really possible that Patches' soul is in there with you?"
    s "Nunca lo pensé así. ¿Es realmente posible que el alma de Patches esté ahí contigo?"

# game/scripts/scripthall.rpy:860
translate spanish hallportraits_6b427964:

    # n "Angel nods solemnly."
    n "Angel asiente solemnemente."

# game/scripts/scripthall.rpy:863
translate spanish hallportraits_b210d998:

    # a "... Regardless... There's no point dwelling on the many horrific possibilities that lie ahead of us. Let's just have fun now!"
    a "... De todos modos... No ganamos nada dándole vueltas a las cosas horribles que podrían pasarnos. ¡Divirtámonos ahora!"

# game/scripts/scripthall.rpy:866
translate spanish hallportraits_dc582fbf:

    # o "Y-yeah!"
    o "¡S-sí!"

# game/scripts/scripthall.rpy:877
translate spanish hallportraits_3fe52277:

    # o "Angel and Coco were so cute as kittens!"
    o "¡Angel y Coco eran tan lindos como gatitos!"

# game/scripts/scripthall.rpy:879
translate spanish hallportraits_bb12d861_1:

    # o "Angel!! You and Coco were so c-cute as kittens!"
    o "¡¡Angel!! ¡Tú y Coco eran tan lindos como gatitos!"

# game/scripts/scripthall.rpy:883
translate spanish hallportraits_39575858:

    # b "Yeesh I can't believe Coco used to be so small and feeble. It really is unlike her."
    b "Cieelos, no puedo creer que Coco fuera tan pequeña y débil. Realmente no es propio de ella."

# game/scripts/scripthall.rpy:886
translate spanish hallportraits_ff4ba5af:

    # s "Hard to believe these guys could grow up to become a bunch of dog killers."
    s "Es difícil creer que estos tipos pudieran convertirse en un grupo de asesinos de perros."

# game/scripts/scripthall.rpy:890
translate spanish hallportraits_b63e70b7:

    # s "Ahh no offense Angel."
    s "Ahh sin ofender Angel."

# game/scripts/scripthall.rpy:893
translate spanish hallportraits_577f25f4:

    # a "None taken."
    a "No me ofende."

# game/scripts/scripthall.rpy:896
translate spanish hallportraits_c588ce62:

    # o "But they're s-s-sorry now! They're our friends!!"
    o "¡Pero ahora se l-l-lamentan! ¡¡Son nuestros amigos!!"

# game/scripts/scripthall.rpy:900
translate spanish hallportraits_7c8ab46a:

    # b "Don't get them started Sparky you'll just get an earful of wholesome friendship-is-magic realtalk."
    b "No la hagas empezar, Sparky, o te dará todo un sermón cursi sobre cómo la amistad es mágica."

# game/scripts/scripthall.rpy:903
translate spanish hallportraits_9f994d5d:

    # a "Sparky's right... Coco and I must admit our wrong doing if we're ever to atone for them..."
    a "Sparky tiene razón... Coco y yo debemos admitir nuestras faltas si es que queremos redimirnos algún día..."

# game/scripts/scripthall.rpy:904
translate spanish hallportraits_07abc845_1:

    # o "..."
    o "..."

# game/scripts/scripthall.rpy:906
translate spanish hallportraits_33c1e283:

    # n "Olive turns towards the portrait in a huff."
    n "Olive se voltea hacia el retrato con indignación."

# game/scripts/scripthall.rpy:909
translate spanish hallportraits_4215fdcc:

    # o "I'm sorry widdle babies, Sparky doesn't mean it!"
    o "Lo siento, pequeñitos, ¡Sparky no lo dice en serio!"

# game/scripts/scripthall.rpy:911
translate spanish hallportraits_418dd575:

    # o "I'm sorry widdle babies, they don't mean it!"
    o "Lo siento, pequeñitos, ¡no lo dicen en serio!"

# game/scripts/scripthall.rpy:914
translate spanish hallportraits_6160e19b:

    # n "They give the portrait of Angel and Coco a kiss on their heads."
    n "Olive le da un beso en la cabeza a las figuras de Angel y Coco en el retrato."

# game/scripts/scripthall.rpy:923
translate spanish hallportraits_007e53f5:

    # b "Angel on the other hand, he really hasn't changed even now that he's in the body of a dog!"
    b "Angel, por otro lado, ¡realmente no ha cambiado incluso ahora que está en el cuerpo de un perro!"

# game/scripts/scripthall.rpy:926
translate spanish hallportraits_4c1276a2:

    # o "Aww you're r-r-right!! He's still the same little kitty no matter whose body he's in!"
    o "¡¡Aww tienes toda la razón!! ¡Sigue siendo el mismo gatito sin importar en qué cuerpo esté!"

# game/scripts/scripthall.rpy:934
translate spanish hallbath_165db4f5:

    # n "Olive knocks on the door."
    n "Olive llama a la puerta."

# game/scripts/scripthall.rpy:940
translate spanish hallbath_dbbce2a0:

    # b "Occupied!"
    b "¡Ocupado!"

# game/scripts/scripthall.rpy:943-------
translate spanish hallbath_d13a5d01:

    # a "Oh for Cat's sake."
    a "Oh, por el amor del Gato."

# game/scripts/scripthall.rpy:946
translate spanish hallbath_58650a48:

    # n "Angel opens the door."
    n "Angel abre la puerta."

# game/scripts/scripthall.rpy:955
translate spanish hallbath_bab674df:

    # s "Brownie?! You're still in there?"
    s "¡¿Brownie?! ¿Todavía estás ahí?"

# game/scripts/scripthall.rpy:957
translate spanish hallbath_d0616a09:

    # b "UUUGH."
    b "UUUGH."

# game/scripts/scripthall.rpy:959
translate spanish hallbath_ee0821fd:

    # n "Brownie opens the door."
    n "Brownie abre la puerta."

# game/scripts/scripthall.rpy:972
translate spanish hallbath_56dc28d2:

    # o "O-oh s-s-sorry! I'll come back later!"
    o "O-oh l-l-lo siento! ¡Volveré más tarde!"

# game/scripts/scripthall.rpy:974
translate spanish hallbath_56501981:

    # b "Huh? Olive?!?!"
    b "¿Eh? ¡¿¡¿Olive?!?!"

# game/scripts/scripthall.rpy:977
translate spanish hallbath_04a45f80:

    # n "The door whips open revealing a happy little corgi! She pulls Olive into the bathroom."
    n "¡La puerta se abre de golpe y revela una pequeña corgi feliz! Lleva a Olive al baño."

# game/scripts/scripthall.rpy:999
translate spanish hallbed_446d2349:

    # c "You realize at this point you're welcome in my room, right?"
    c "Te das cuenta de que a estas alturas tienes las puertas de mi habitación abiertas, ¿verdad?"

# game/scripts/scripthall.rpy:1002
translate spanish hallbed_f426e18c:

    # o "O-oh really? C-c-cool!"
    o "O-oh ¿en serio? ¡G-g-genial!"

# game/scripts/scripthall.rpy:1009
translate spanish hallbed_5eb7cf77:

    # g "I... I'm a little afraid to face him."
    g "Yo... tengo un poco de miedo de enfrentarlo."

# game/scripts/scripthall.rpy:1011
translate spanish hallbed_afb159f2:

    # s "It's okay, we'll be with you."
    s "Está bien, estaremos contigo."

# game/scripts/scripthall.rpy:1018
translate spanish hallbed_0e7add18:

    # g "Here goes."
    g "Aquí va."

# game/scripts/scripthall.rpy:1019
translate spanish hallbed_62195b4e:

    # n "Ginger opens the bedroom door."
    n "Ginger abre la puerta del dormitorio."

# game/scripts/scripthall.rpy:1026
translate spanish hallbed_6c5f23ef:

    # n "The note on the door reads: ''Happy birthday Olive! Sorry about the zombies. As recompense I owe you one birthday wish. - Coco''"
    n "La nota en la puerta dice: ''¡Feliz cumpleaños Olive! Perdón por los zombies. Como recompensa te debo un deseo de cumpleaños. - Coco''"

# game/scripts/scripthall.rpy:1036
translate spanish hallbed_57ffe0af:

    # n "Olive tries to open the door but it won't budge!"
    n "Olive intenta abrir la puerta, ¡pero no se mueve!"

# game/scripts/scripthall.rpy:1038
translate spanish hallbed_d5405a75:

    # a "Oh no!! It's locked!"
    a "¡¡Oh, no!! ¡Está cerrado!"

# game/scripts/scripthall.rpy:1041
translate spanish hallbed_f2df173b:

    # b "WHAT?! Don't you and Coco share a room?! Unlock it!"
    b "¡¿QUÉ?! ¿Coco y tú no comparten habitación? ¡Ábrela!"

# game/scripts/scripthall.rpy:1044
translate spanish hallbed_52e9e524:

    # a "No... When Coco works she needs absolute focus and privacy; even I don't know where she keeps the keys!"
    a "No... Cuando Coco trabaja necesita absoluta concentración y privacidad; ¡Ni siquiera yo sé dónde guarda las llaves!"

# game/scripts/scripthall.rpy:1045
translate spanish hallbed_f4ef0cd2:

    # a "Th-they're usually scattered around in obscure places."
    a "Generalmente están dispersas en lugares inhóspitos."

# game/scripts/scripthall.rpy:1048
translate spanish hallbed_e74a0db0:

    # s "We need to find them quick!"
    s "¡Necesitamos encontrarlas rápido!"

# game/scripts/scripthall.rpy:1061
translate spanish hallbed_edc91869:

    # n "Olive tries to open the door but it's locked! They can hear squabbling from behind the door."
    n "¡Olive intenta abrir la puerta pero está cerrada! Se oyen riñas detrás de la puerta."

# game/scripts/scripthall.rpy:1074
translate spanish hallbed_30adbaab:

    # n "Olive scrambles to unlock the door with their collection of keys."
    n "Olive se apresura a abrir la puerta con su colección de llaves."

# game/scripts/scripthall.rpy:1078
translate spanish hallbed_fa15e396:

    # n "It opens and the group enters."
    n "Se abre y el grupo entra."

# game/scripts/scripthall.rpy:1089
translate spanish hallbed_3c6ee1a6:

    # o "S-s-stay out?! I guess I should leave..."
    o "¡¿N-no pasar?! Supongo que debería irme..."

# game/scripts/scripthall.rpy:1094
translate spanish hallbed_34339ff1:

    # b "Stay out? Uuuuuugh what a buzzkill!"
    b "¿No pasar? Uuuuuugh qué aguafiestas"

# game/scripts/scripthall.rpy:1098
translate spanish hallbed_285e9cbb:

    # s "I hope Coco doesn't mind us interrupting her."
    s "Espero que a Coco no le importe que la interrumpamos."

# game/scripts/scripthall.rpy:1102
translate spanish hallbed_28294a78:

    # a "She'll mind... But it's a necessary inconvenience..."
    a "A ella le importará... Pero es un inconveniente necesario..."

# game/scripts/scripthall.rpy:1106
translate spanish hallbed_d30a1c75:

    # o "S-s-stay out?! I guess we should leave..."
    o "¡¿N-no pasar?! Supongo que deberíamos irnos..."

# game/scripts/scripthall.rpy:1109
translate spanish hallbed_f925bbfc:

    # o "Oh there's a small note!!"
    o "¡¡Ah, hay una pequeña nota!!"

# game/scripts/scripthall.rpy:1110
translate spanish hallbed_3417239a:

    # o "''Happy birthday Olive! Sorry about the zombies. As recompense I owe you one birthday wish. - Coco''"
    o "''¡Feliz cumpleaños Olive! Perdón por los zombies. Como recompensa te debo un deseo de cumpleaños. - Coco''"

# game/scripts/scripthall.rpy:1114
translate spanish hallbed_13496baa:

    # o "A birthday wish?! WOW!! Coco's the best!"
    o "¡¿Un deseo de cumpleaños?! ¡¡GUAU!! ¡Coco es la mejor!"

# game/scripts/scripthall.rpy:1119
translate spanish hallbed_e4548628:

    # a "Wow she must really like you! Coco's wishes are very valuable..."
    a "¡Vaya, a ella realmente le debes agradar! Los deseos de Coco son muy valiosos..."

# game/scripts/scripthall.rpy:1125
translate spanish hallbed_42a79a62:

    # o "I'm not going in. I d-d-don't want to get yelled at again."
    o "No voy a entrar. No quiero que me griten otra vez."

# game/scripts/scripthall.rpy:1132
translate spanish hallbed_1dd57ad9:

    # a "W-wait Olive we shouldn't-"
    a "E-espera Olive, no deberíamos-"

# game/scripts/scripthall.rpy:1134
translate spanish hallbed_e21bbc6e:

    # n "Olive tries to open the door but it's locked!"
    n "¡Olive intenta abrir la puerta pero está cerrada!"

# game/scripts/scripthall.rpy:1142
translate spanish hallbed_4719421b:

    # n "From behind the door they can hear yelling." with vpunch
    n "Desde detrás de la puerta se oyen gritos." with vpunch

# game/scripts/scripthall.rpy:1143
translate spanish hallbed_0817b515:

    # c "HEY READ THE SIGN MORON!!"
    c "¡¡OYE, LEE EL CARTEL IDIOTA!!"

# game/scripts/scripthall.rpy:1146
translate spanish hallbed_52338777:

    # o "EEP! I b-b-better go."
    o "¡EEP! S-s-será mejor que me vaya."

# game/scripts/scripthall.rpy:1153
translate spanish hallbed_cecb4803:

    # o "B-B-BUT SPARKY NEEDS YOUR HELP!!"
    o "¡¡P-P-PERO SPARKY NECESITA TU AYUDA!!"

# game/scripts/scripthall.rpy:1155
translate spanish hallbed_87871fc4:

    # c "LALALA I'M NOT LISTENING! SCRAM!"
    c "LALALA ¡NO ESTOY ESCUCHANDO! ¡LARGARSE!"

# game/scripts/scripthall.rpy:1158
translate spanish hallbed_23e889e0:

    # s "Damn it! Maybe she'll talk to us if we find a way in."
    s "¡Maldita sea! Quizás ella hable con nosotros si encontramos una manera de entrar."

# game/scripts/scripthall.rpy:1167
translate spanish hallbed_b4240b3f:

    # a "Ugh... We'll need to find a way in if we want her help..."
    a "Ugh... Tendremos que encontrar una manera de entrar si queremos su ayuda..."

# game/scripts/scripthall.rpy:1175
translate spanish hallbed_e64b8357:

    # o "EEP! W-we'd better go."
    o "¡EEP! Será mejor que nos vayamos."

# game/scripts/scripthall.rpy:1189
translate spanish hallbed_d00b7309:

    # n "Olive opens the door with their collection of keys!"
    n "¡Olive abre la puerta con su colección de llaves!"

# game/scripts/scripthall.rpy:1196
translate spanish hallbed_00bc31ef:

    # o "L-let's bother her later!"
    o "¡Vamos a molestarla más tarde!"

# game/scripts/scripthall.rpy:1207
translate spanish hallbed_0b418de6:

    # o "I should leave C-Coco alone!"
    o "¡Debería dejar a C-Coco en paz!"

# game/scripts/scripthall.rpy:1214
translate spanish hallbed_16930873:

    # a "We really shouldn't bother Coco unless we have a good reason to..."
    a "Realmente no deberíamos molestar a Coco a menos que tengamos una buena razón para..."

# game/scripts/scripthall.rpy:1218
translate spanish hallbed_19712fab:

    # b "Coco should just let us in."
    b "Coco debería dejarnos entrar."

# game/scripts/scripthall.rpy:1233
translate spanish hallangelbrownie_56a11e39:

    # n "Angel, Brownie and the flower pot are holding the door shut... For now."
    n "Angel, Brownie y la maceta mantienen la puerta cerrada... Por ahora."

# game/scripts/scripthall.rpy:1234
translate spanish hallangelbrownie_df49a086:

    # n "It sounds like Angel is ranting about Patches giving his old body a furcut."
    n "Parece que Angel se está quejando de que Patches le hizo un corte de pelo a su antiguo cuerpo."

# game/scripts/scripthall.rpy:1237
translate spanish hallangelbrownie_9a12938c:

    # c "Come on Olive we need to find a weapon!"
    c "¡Vamos Olive, necesitamos encontrar un arma!"

# game/scripts/scripthall.rpy:1250
translate spanish hallangelbrownie_b564923f:

    # o "Was that z-zombie really Patches?"
    o "¿Ese z-zombie era realmente Patches?"

# game/scripts/scripthall.rpy:1253
translate spanish hallangelbrownie_d1c6bab3:

    # a "... Undoubtedly."
    a "... Sin duda."

# game/scripts/scripthall.rpy:1256
translate spanish hallangelbrownie_7912aebd:

    # o "W-why is P-P-Patches so mean to you?"
    o "¿P-por qué P-P-Patches es tan malo contigo?"

# game/scripts/scripthall.rpy:1259
translate spanish hallangelbrownie_bb8e4b4e:

    # a "..."
    a "..."

# game/scripts/scripthall.rpy:1262
translate spanish hallangelbrownie_986417c6:

    # a "Before I met all of you, Patches and I were... Friends."
    a "Antes de conocerlos a todos, Patches y yo éramos... amigos."

# game/scripts/scripthall.rpy:1263
translate spanish hallangelbrownie_4dd6d240:

    # a "He really trusted me but I said something that really hurt his feelings..."
    a "Él realmente confiaba en mí pero dije algo que realmente hirió sus sentimientos..."

# game/scripts/scripthall.rpy:1266
translate spanish hallangelbrownie_1d23659d:

    # o "What'd you say?!"
    o "¡¿Qué dijiste?!"

# game/scripts/scripthall.rpy:1269
translate spanish hallangelbrownie_7380412d:

    # c "Oh just what we're all thinking now; That he's a twisted piece of shit who's unworthy of all relations."
    c "Oh, justo lo que todos estamos pensando ahora; Que es una puta mierda de persona que no merece ninguna relación."

# game/scripts/scripthall.rpy:1272
translate spanish hallangelbrownie_93bc4398:

    # a "Well I didn't quite say it like that."
    a "Bueno, no se lo dije así."

# game/scripts/scripthall.rpy:1273
translate spanish hallangelbrownie_d2775665:

    # a "I just told him what I thought of him and he didn't like it. Now he's holding a grudge against me like some kind of child."
    a "Sólo le dije lo que pensaba de él y no le gustó. Ahora me guarda rencor como una especie de crío."

# game/scripts/scripthall.rpy:1280
translate spanish hallangelbrownie_9d51c2a0:

    # o "It must feel horrible kn-knowing so many people h-hate you..."
    o "Debe ser horrible saber que tanta gente te odia..."

# game/scripts/scripthall.rpy:1284
translate spanish hallangelbrownie_616d6a0e:

    # o "It almost f-feels like Patches needs a hug..."
    o "Casi se siente como si Patches necesitara un abrazo..."

# game/scripts/scripthall.rpy:1287
translate spanish hallangelbrownie_4a74af48:

    # c "You're so soft Olive!"
    c "¡Eres tan suave Olive!"

# game/scripts/scripthall.rpy:1293
translate spanish hallangelbrownie_5b7e5011:

    # o "That does make him s-sound pretty bad..."
    o "Eso lo hace sonar bastante mal..."

# game/scripts/scripthall.rpy:1299
translate spanish hallangelbrownie_59eb7383:

    # o "S-someone should bite him!"
    o "¡Alguien debería morderlo!"

# game/scripts/scripthall.rpy:1305
translate spanish hallangelbrownie_9cbb38a0:

    # n "Sparky pounds on the door once more. The crack in the wood lengthens." with vpunch
    n "Sparky golpea la puerta una vez más. La grieta en la madera se alarga." with vpunch

# game/scripts/scripthall.rpy:1307
translate spanish hallangelbrownie_ca04010e:

    # b "As much as I LOVE hearing about how evil Patches is I think you guys'd better go find us a weapon!!"
    b "¡¡Por mucho que ME ENCANTA escuchar lo malvado que es Patches, creo que será mejor que vayan a buscar un arma!!"

# game/scripts/scripthall.rpy:1325
translate spanish gameover04_7fa0202c:

    # n "They're just hugging him though. Really tight."
    n "Aunque solo lo están abrazando. Realmente fuerte."

# game/scripts/scripthall.rpy:1327
translate spanish gameover04_696e8cff:

    # o "I'm sorry Patches!! I'm sorry Angel hurt your feelings and then you died and then you had to come back like this!!"
    o "¡¡Lo siento Patches!! ¡¡Lamento que Angel haya herido tus sentimientos y luego moriste y luego tuviste que regresar así!!"

# game/scripts/scripthall.rpy:1329
translate spanish gameover04_9b367322:

    # o "I hope it's not painful being a zombie."
    o "Espero que no sea doloroso ser un zombie."

# game/scripts/scripthall.rpy:1332
translate spanish gameover04_c8ea8a4a:

    # p "..."
    p "..."

# game/scripts/scripthall.rpy:1334
translate spanish gameover04_6e8f3a90:

    # p "GET THE FUCK OFF ME."
    p "¡SUÉLTAME DE UNA MALDITA VEZ!"

# game/scripts/scripthall.rpy:1338
translate spanish gameover04_6e0bb1c2:

    # n "Patches sends Olive flying!" with vpunch
    n "¡Patches envía a Olive a volar!" with vpunch

# game/scripts/scripthall.rpy:1341
translate spanish gameover04_8a6a021b:

    # n "They hit the wall and slide down into the waiting arms of a hoard of zombies!"
    n "¡Golpea la pared y se desliza hacia los brazos de una horda de zombis!"

# game/scripts/scripthall.rpy:1344
translate spanish gameover04_ba209263:

    # o "AHH WAIT!!"
    o "AHH ESPERA!!"

# game/scripts/scripthall.rpy:1348
translate spanish gameover04_cc904f43:

    # n "They mindlessly tear into Olive's flesh! Their friends make a futile attempt to fight the zombies off." with vpunch
    n "¡Desgarran sin pensar la carne de Olive! Sus amigos intentan en vano repeler a los zombis." with vpunch

# game/scripts/scripthall.rpy:1351
translate spanish gameover04_ba9a59ef:

    # n "Patches watches silently."
    n "Patches observa en silencio."

# game/scripts/scripthall.rpy:1373
translate spanish gameover04_0d78241f:

    # n "Olive angrily bites Patches all over!"
    n "¡Olive muerde enojada a Patches por todas partes!"

# game/scripts/scripthall.rpy:1374
translate spanish gameover04_b0600ebe:

    # n "Their nubby teeth don't do much."
    n "Sus dientitos no sirven de mucho."

# game/scripts/scripthall.rpy:1376
translate spanish gameover04_402131cf:

    # p "You're kidding me right? You think you're gonna save your friends with your stupid TEETH?!"
    p "¿Estás bromeando verdad? ¿Crees que vas a salvar a tus amigos con tus estúpidos DIENTES?"

# game/scripts/scripthall.rpy:1380
translate spanish gameover04_1ace7644:

    # n "Patches jabs Olive in the mouth knocking out a tooth!" with vpunch
    n "¡Patches golpea a Olive en la boca y le hace saltar un diente!" with vpunch

# game/scripts/scripthall.rpy:1382
translate spanish gameover04_d83c851c:

    # o "OWWW!!"
    o "¡¡OWW!!"

# game/scripts/scripthall.rpy:1385
translate spanish gameover04_345bf1ae:

    # n "Olive holds back Patches' arms..."
    n "Olive retiene los brazos de Patches..."

# game/scripts/scripthall.rpy:1388
translate spanish gameover04_b4c18dfc:

    # n "But ends up pulling one right off his rotting body!" with vpunch
    n "¡Pero termina sacando uno de su cuerpo podrido!" with vpunch

# game/scripts/scripthall.rpy:1391
translate spanish gameover04_aa342fd4:

    # p "AGHHH!!"
    p "AGHHH!!"

# game/scripts/scripthall.rpy:1394
translate spanish gameover04_492d7f5a:

    # o "AHH S-SORRY!!"
    o "¡¡AHH L-LO SIENTO!!"

# game/scripts/scripthall.rpy:1396
translate spanish gameover04_c8439835:

    # o "I M-M-MEAN, Y-YOU'RE A BIG MEANIE AND YOU PURROBABLY DESERVE THIS!!"
    o "¡¡D-D-DIGO ERES MALVADO Y PURRBABLEMENTE TE MERECES ESTO!!"

# game/scripts/scripthall.rpy:1400
translate spanish gameover04_2d4fd177:

    # n "Olive smacks Patches in the face with his own arm!" with vpunch
    n "¡Olive golpea a Patches en la cara con su propio brazo!" with vpunch

# game/scripts/scripthall.rpy:1402
translate spanish gameover04_bf948155:

    # p "ENOUGH!"
    p "¡SUFICIENTE!"

# game/scripts/scripthall.rpy:1408
translate spanish gameover04_290fd3b2:

    # n "Using Coco's wand Patches binds Olive, Brownie and Angel together." with vpunch
    n "Usando la varita de Coco, Patches une a Olive, Brownie y Angel." with vpunch

# game/scripts/scripthall.rpy:1410
translate spanish gameover04_20f4e0e1:

    # p "I was GOING to let the zombies have you but I think I'd rather be the one to cause your suffering!"
    p "Iba a dejar que los zombies los atraparan, ¡pero creo que prefiero ser yo quien cause su sufrimiento!"

# game/scripts/scripthall.rpy:1413
translate spanish gameover04_846936ec:

    # n "Patches tightens the binds around Brownie..."
    n "Patches aprieta los lazos alrededor de Brownie..."

# game/scripts/scripthall.rpy:1415
translate spanish gameover04_c4b52c56:

    # b "AHHH, NO, STOP!!"
    b "¡¡AHHH, NO, DETENTE!!!"

# game/scripts/scripthall.rpy:1420
translate spanish gameover04_33a0477e:

    # n "Until she's sliced apart!" with vpunch
    n "¡Hasta cortarla en pedazos!" with vpunch

# game/scripts/scripthall.rpy:1423
translate spanish gameover04_fe766d4b:

    # o "AHHHHHHHHHH!!" with vpunch
    o "AHHHHHHHHHH!!" with vpunch

# game/scripts/scripthall.rpy:1425
translate spanish gameover04_74aa5170:

    # n "The wires tighten around Angel next."
    n "A continuación, los cables se tensan alrededor de Angel."

# game/scripts/scripthall.rpy:1427
translate spanish gameover04_3fbdd274:

    # a "MMMPH!"
    a "MMMPH!"

# game/scripts/scripthall.rpy:1431
translate spanish gameover04_f08dd334:

    # p "It's too late Angel." with vpunch
    p "Es demasiado tarde, Angel." with vpunch

# game/scripts/scripthall.rpy:1435
translate spanish gameover04_d0743ee4:

    # o "Nooo, nonono..." with vpunch
    o "Nooo, nonono..." with vpunch

# game/scripts/scripthall.rpy:1438
translate spanish gameover04_d8dc9cbb:

    # p "If you hadn't made me so angry maybe your friends wouldn't have died so horribly!"
    p "¡Si no me hubieras hecho enojar tanto quizás tus amigos no habrían muerto tan horriblemente!"

# game/scripts/scripthall.rpy:1440
translate spanish gameover04_5350b2d3:

    # n "The wires tighten around Olive next."
    n "A continuación, los cables se tensan alrededor de Olive."

translate spanish strings:

    # game/scripts/scripthall.rpy:608
    old "{color=#ffc1ed}Talk to Brownie and Angel.{/color}"
    new "{color=#ffc1ed}Hablar con Brownie y Angel.{/color}"

    # game/scripts/scripthall.rpy:608
    old "{color=#ffc1ed}Inspect portraits.{/color}"
    new "{color=#ffc1ed}Inspeccionar retratos.{/color}"

    # game/scripts/scripthall.rpy:608
    old "Leave."
    new "Salir."

    # game/scripts/scripthall.rpy:617
    old "{color=#ffc1ed}Stay.{/color}"
    new "{color=#ffc1ed}Permanecer.{/color}"

    # game/scripts/scripthall.rpy:617
    old "{color=#ff9da6}Enter bathroom.{/color}"
    new "{color=#ff9da6}Entrar al baño.{/color}"

    # game/scripts/scripthall.rpy:617
    old "{color=#ffcd65}Go downstairs.{/color}"
    new "{color=#ffcd65}Bajar las escaleras.{/color}"

    # game/scripts/scripthall.rpy:617
    old "{color=#a9d4ff}Enter bedroom.{/color}"
    new "{color=#a9d4ff}Entrar a la habitación.{/color}"

    # game/scripts/scripthall.rpy:657
    old "Knock first."
    new "Tocar primero."

    # game/scripts/scripthall.rpy:986
    old "Enter room."
    new "Entrar a la habitación."

    # game/scripts/scripthall.rpy:1275
    old "Pity Patches."
    new "Sentir lástima por Patches."

    # game/scripts/scripthall.rpy:1275
    old "Agree with Angel."
    new "De acuerdo con Angel."

    # game/scripts/scripthall.rpy:1318
    old "Hug him."
    new "Abrazarlo."

    # game/scripts/scripthall.rpy:1318
    old "{color=#ffffff66}Hug him.{/color}"
    new "{color=#ffffff66}Abrazarlo.{/color}"

    # game/scripts/scripthall.rpy:1318
    old "{color=#ffffff66}Bite him.{/color}"
    new "{color=#ffffff66}Morderlo.{/color}"

    # game/scripts/scripthall.rpy:1318
    old "Bite him."
    new "Morderlo."

