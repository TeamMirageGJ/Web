﻿# TODO: Translation updated at 2024-11-25 12:57

# game/scripts/scriptyard.rpy:12
translate spanish yardintro_44bd1873:

    # n "The zombies seem to have collapsed in lifeless heaps."
    n "Los zombis parecen haberse desplomado en montones sin vida."

# game/scripts/scriptyard.rpy:14
translate spanish yardintro_fd44f0e9:

    # s "They're all dead. Like really dead."
    s "Están todos muertos. Pero muertos de verdad.."

# game/scripts/scriptyard.rpy:21
translate spanish yardintro_fb9f796c:

    # n "Olive slams the gate shut behind them!" with hpunch
    n "¡Olive cierra la puerta de un portazo detrás de ellos!" with hpunch

# game/scripts/scriptyard.rpy:22
translate spanish yardintro_1f252ea8:

    # n "They're out of breath and flinch every time the zombies slam their rotting paws against the metal gate."
    n "Ella queda sin aliento y se estremece cada vez que los zombies golpean con sus patas podridas la puerta de metal."

# game/scripts/scriptyard.rpy:25
translate spanish yardintro_a07c247e:

    # z "YOoOoOoUu!! YOoUu WILL PAaY FUuR WHAaT YOoUu'VE DOoNE!!"
    z "¡¡TuUuUUu!! ¡¡PAGAaAaARÁS POR LO QUE HAS HEeEeCHO!!"

# game/scripts/scriptyard.rpy:28
translate spanish yardintro_3d6b3f6e:

    # o "AHH I-I'M SORRY I'M S-SORRY! I DON'T KNOW WHAT YOU'RE T-T-TALKING ABOUT!"
    o "AHH ¡LO-LO SIENTO! ¡LO-LO SIENTO! ¡NO SÉ DE QUÉ ME ESTAN H-H-HABLANDO!"

# game/scripts/scriptyard.rpy:31
translate spanish yardintro_d150e987:

    # n "The zombies roar in frustration!"
    n "¡Los zombies rugen de frustración!"

# game/scripts/scriptyard.rpy:33
translate spanish yardintro_6dba4bf4:

    # n "Now that Olive isn't scrambling through the dark woods they notice the zombies are clad in Hachiko High School uniforms."
    n "Ahora que Olive no está esquivando zombis en el bosque, ella nota que los zombis están vestidos con uniformes del instituto Hachiko."

# game/scripts/scriptyard.rpy:35
translate spanish yardintro_d3eb595a:

    # o "OH!"
    o "¡OH!"

# game/scripts/scriptyard.rpy:37
translate spanish yardintro_e1114bf0:

    # o "Oooh no..."
    o "Ooh no..."

# game/scripts/scriptyard.rpy:38
translate spanish yardintro_8cf28cf7:

    # o "I-I'm sorry I didn't r-recognize all of you! M-maybe you can c-come to my surprise birthday party and we can all help s-s-stitch you up!"
    o "¡L-Lo siento, no los r-reconocí a todos! ¡Q-quizás puedan venir a mi fiesta de cumpleaños sorpresa y todos podemos ayudar a c-c-coserlos!"

# game/scripts/scriptyard.rpy:42
translate spanish yardintro_056685c7:

    # n "The zombies roar in frustration once more."
    n "Los zombies rugen de frustración una vez más."

# game/scripts/scriptyard.rpy:45
translate spanish yardintro_67d42fd3:

    # o "OHH I-I I CAN TELL YOU'RE C-CONFUSED!"
    o "¡OHH, P-PUEDO VER QUE ESTÁN C-CONFUNDIDOS!"

# game/scripts/scriptyard.rpy:46
translate spanish yardintro_0058db14:

    # o "S-see it was supposed to b-be a surprise party but Brownie spoiled it for me as s-s-soon as I told her when my birthday was."
    o "Verán, se suponía que iba a ser una fiesta sorpresa, pero Brownie lo arruinó tan pronto como le dije la fecha de mi cumpleaños."

# game/scripts/scriptyard.rpy:48
translate spanish yardintro_d2c7408e:

    # o "BUT it can s-still be surprising since you're all he-"
    o "¡PERO aún puede ser una sorpresa, ya que están todos aqui!"

# game/scripts/scriptyard.rpy:51
translate spanish yardintro_ef080c4e:

    # z "YOoOoOoUu WILL AaAaLL PAaAaAaY!!"
    z "¡¡TuUuUUu PAgaRAs PoR lO qUE Nos HecHO!!"

# game/scripts/scriptyard.rpy:54
translate spanish yardintro_b3c025ad:

    # o "EEP!"
    o "¡EEP!"

# game/scripts/scriptyard.rpy:55
translate spanish yardintro_f6a66d08:

    # o "Y-you know what I'll just go find you all s-someone else who can help!"
    o "Saben qué, simplemente iré a buscar a alguien más que p-pueda ayudarlos a todos"

# game/scripts/scriptyard.rpy:58
translate spanish yardintro_e5670cf0:

    # n "Olive backs away slowly as the zombies continue their moaning."
    n "Olive retrocede lentamente mientras los zombies continúan gimiendo."

# game/scripts/scriptyard.rpy:63
translate spanish yardintro_8307bbbf:

    # o "I n-need to find Coco! I b-bet her magic can fix these poor pups up!"
    o "¡N-necesito encontrar a Coco! ¡Apuesto a que su magia puede curar a estos pobres cachorros!"

# game/scripts/scriptyard.rpy:94
translate spanish yardmenu_2daf5845:

    # g "... I'm pretty sure Patches is in the house trying to murder your friends..."
    g "... Estoy bastante segura de que Patches está en la casa tratando de asesinar a tus amigos..."

# game/scripts/scriptyard.rpy:100
translate spanish yardmenu_52a45f9d:

    # s "Come on Olive, we have no business in the woods."
    s "Vamos Olive, no tenemos nada que hacer en el bosque."

# game/scripts/scriptyard.rpy:124
translate spanish yardmenu_3eae8b54:

    # g "WAIT!!"
    g "¡¡ESPERA!!"

# game/scripts/scriptyard.rpy:126
translate spanish yardmenu_844baeca:

    # n "Ginger's ghost rises up from the cobblestone right in front of the door."
    n "El fantasma de Ginger surge del suelo justo en frente de la puerta."

# game/scripts/scriptyard.rpy:129
translate spanish yardmenu_00b5c33a:

    # o "AHHH!!"
    o "¡¡AHHH!!"

# game/scripts/scriptyard.rpy:133
translate spanish yardmenu_f27e6e4e:

    # s "OH MY DOG GINGER you could've given us heart attacks!"
    s "¡OH DIOS GINGER, podrías habernos provocado ataques cardiacos!"

# game/scripts/scriptyard.rpy:136
translate spanish yardmenu_d70a8406:

    # g "AHH! I'm sorry I'm sorry."
    g "¡AH! Lo siento, lo siento."

# game/scripts/scriptyard.rpy:137
translate spanish yardmenu_5e9e6ddd:

    # g "I want to help! F-for my own peace of mind..."
    g "¡Quiero ayudar! P-para mi propia tranquilidad..."

# game/scripts/scriptyard.rpy:140
translate spanish yardmenu_e2dbe9f6:

    # o "R-REALLY?! WOW!!"
    o "¡¿E-EN SERIO?! ¡¡GUAU!!"

# game/scripts/scriptyard.rpy:141
translate spanish yardmenu_5e6f3948:

    # o "D-does this mean w-we're friends?!"
    o "¡¿Eso significa que s-s-somos amigos?!"

# game/scripts/scriptyard.rpy:144
translate spanish yardmenu_61c4e80c:

    # g "Ahh, f-friends?"
    g "Ahh, ¿a-amigos?"

# game/scripts/scriptyard.rpy:148
translate spanish yardmenu_66738daa:

    # o "THIS IS GREAT!! I-I'm so excited!!"
    o "¡¡ESTO ES GENIAL!! ¡¡Estoy tan emocionada!!"

# game/scripts/scriptyard.rpy:150
translate spanish yardmenu_0cfcc708:

    # n "Olive dances around Ginger who stands flustered and confused."
    n "Olive baila alrededor de Ginger, la cual está nerviosa y confundida."

# game/scripts/scriptyard.rpy:153
translate spanish yardmenu_5706033f:

    # s "Heheh! G-glad to have you on board Ginger!"
    s "Jejeje! ¡Me alegro de tenerte a bordo de Ginger!"

# game/scripts/scriptyard.rpy:155
translate spanish yardmenu_31cc4a45:

    # s "Sorry about... Everything."
    s "Lo siento por... todo."

# game/scripts/scriptyard.rpy:158
translate spanish yardmenu_777c9d13:

    # g "It's alright... I just sort of realized... You guys are pretty nice."
    g "Está bien... Me acabo de dar cuenta... Ustedes son muy amables."

# game/scripts/scriptyard.rpy:159
translate spanish yardmenu_14e0aff4:

    # g "Not to talk myself up or anything but you'll need my abilities if Patches has the wand."
    g "No es para convencerme ni nada por el estilo, pero necesitarás mis habilidades si Patches tiene la varita."

# game/scripts/scriptyard.rpy:162
translate spanish yardmenu_5b23f6a4:

    # s "Let's go find him then!"
    s "¡Vamos a buscarlo entonces!"

# game/scripts/scriptyard.rpy:181
translate spanish yardhouse_012e8405:

    # n "The front entrance of the Grimalkin Estate is made of a stone archway topped with pointy stone cat ears!"
    n "¡La entrada principal de la casa Grimalkin consiste en un arco de piedra rematado con unas puntiagudas orejas de gato hechas del mismo material!"

# game/scripts/scriptyard.rpy:188
translate spanish yardhouse_65e54035:

    # o "I g-guess Coco and Angel's family name is Grimalkin! Cute and spooky, just like them!"
    o "¡Supongo que el apellido de Coco y Angel es Grimalkin! ¡Lindo y espeluznante, justo como ellos!"

# game/scripts/scriptyard.rpy:194
translate spanish yardhouse_578b69ca:

    # b "MAN Grimalkin is such a badass family name!"
    b "¡TÍO, Grimalkin es un apellido tan rudo!"

# game/scripts/scriptyard.rpy:198
translate spanish yardhouse_e4153217:

    # o "Yeah!! W-what's your last name Brownie?"
    o "¡¡Sí!! ¿C-cuál es tu apellido Brownie?"

# game/scripts/scriptyard.rpy:202
translate spanish yardhouse_39964dd7:

    # s "Grimalkin huh? That's an interesting last name."
    s "Grimalkin ¿eh? Es un apellido interesante."

# game/scripts/scriptyard.rpy:206
translate spanish yardhouse_b96902f6:

    # o "Yeah!! W-what's your last name Sparky?"
    o "¡¡Sí!! ¿C-cuál es tu apellido Sparky?"

# game/scripts/scriptyard.rpy:210
translate spanish yardhouse_da644e51:

    # a "... It's the name of a long line of cats who practice witchcraft..."
    a "... Es el nombre de un largo árbol genealógico de gatos que practican la brujería..."

# game/scripts/scriptyard.rpy:2145
translate spanish yardhouse_01c56080:

    # o "Grimalkin sounds cute and spooky, just like you and Coco!!"
    o "¡Grimalkin suena lindo y espeluznante, como tú y Coco!"

# game/scripts/scriptyard.rpy:218
translate spanish yardhouse_2fb40528:

    # a "... Thank you. I think you're cute too..."
    a "... Gracias. Yo también creo que eres linda..."

# game/scripts/scriptyard.rpy:221
translate spanish yardhouse_97b16976:

    # o "I wonder what everybody else's l-last names are!"
    o "¡Me pregunto cuáles serán los apellidos de todos los demás!"

# game/scripts/scriptyard.rpy:228
translate spanish yardhouse_26f13170:

    # o "Wow!! W-what's your last name Sparky?"
    o "¡¡Guau!! ¿C-cuál es tu apellido Sparky?"

# game/scripts/scriptyard.rpy:232
translate spanish yardhouse_41ebac13:

    # o "Wow!! W-what's your last name Brownie?"
    o "¡¡Guau!! ¿C-cuál es tu apellido Brownie?"

# game/scripts/scriptyard.rpy:236
translate spanish yardhouse_b970bd4a:

    # o "Yeah!! W-what are your last names?"
    o "¡¡Sí!! ¿Y c-cuáles son sus apellidos?"

# game/scripts/scriptyard.rpy:240
translate spanish yardhouse_0a9751ed:

    # o "Sparky! Brownie! What are your l-last names?"
    o "¡Sparky! ¡Brownie! ¿Cuáles son sus a-apellidos?"

# game/scripts/scriptyard.rpy:244
translate spanish yardhouse_8834f87e:

    # s "Fritz!"
    s "¡Fritz!"

# game/scripts/scriptyard.rpy:249
translate spanish yardhouse_d7a566ea:

    # o "Aww, Sparky Fritz is such a cute name."
    o "Aww, Sparky Fritz es un nombre tan lindo."

# game/scripts/scriptyard.rpy:259
translate spanish yardhouse_a78e129e:

    # b "Eheheh, Pembroke."
    b "Jejeje, Pembroke."

# game/scripts/scriptyard.rpy:263
translate spanish yardhouse_a78e129e_1:

    # b "Eheheh, Pembroke."
    b "Jejeje, Pembroke."

# game/scripts/scriptyard.rpy:266
translate spanish yardhouse_554b901f:

    # o "WOW!!! It s-sounds so fancy!"
    o "¡¡¡GUAU!!! ¡S-suena tan elegante!"

# game/scripts/scriptyard.rpy:269
translate spanish yardhouse_7925cff1:

    # b "Eugh, it's not super fitting for me but what're ya gonna do right?"
    b "Eugh, no me pega mucho, pero ¿qué se le va a hacer, no?"

# game/scripts/scriptyard.rpy:277
translate spanish yardhouse_98ef9e30:

    # a "... What about you Olive?"
    a "... ¿Y tú Olive?"

# game/scripts/scriptyard.rpy:280
translate spanish yardhouse_dd30d616:

    # o "My last name is H-higgins!"
    o "¡Mi apellido es H-higgins!"

# game/scripts/scriptyard.rpy:288
translate spanish yardhouse_e9387845:

    # b "HIGGINS? More like huggins!!"
    b "¿HIGGINS? ¡¡Que amigable!!"

# game/scripts/scriptyard.rpy:290
translate spanish yardhouse_9aa54f2a:

    # n "Brownie hugs Olive and starts tickling them!"
    n "¡Brownie abraza a Olive y comienza a hacerle cosquillas!"

# game/scripts/scriptyard.rpy:292
translate spanish yardhouse_342a7ba2:

    # o "EEP!!"
    o "¡¡EEP!!"

# game/scripts/scriptyard.rpy:303
translate spanish yardgrave_b1afd5e0:

    # o "O-one grave is enough!!"
    o "¡¡Una tumba es suficiente!!"

# game/scripts/scriptyard.rpy:307
translate spanish yardgrave_8711e575:

    # c "There should've never been a grave."
    c "Nunca debería haber habido una tumba."

# game/scripts/scriptyard.rpy:310
translate spanish yardgrave_6522e89e:

    # c "I should've cremated Angel's body as soon as I had the chance."
    c "Debí haber cremado el cuerpo de Angel tan pronto como tuve la oportunidad."

# game/scripts/scriptyard.rpy:322
translate spanish yardgrave_b1a1d307:

    # o "S-so Ginger, did you help Patches dig up this grave?"
    o "E-Entonces Ginger, ¿ayudaste a Patches a cavar esta tumba?"

# game/scripts/scriptyard.rpy:325
translate spanish yardgrave_415f710c:

    # g "Err, sort of."
    g "Err, más o menos."

# game/scripts/scriptyard.rpy:326
translate spanish yardgrave_cbf52d6c:

    # g "It was my magic that put Patches' soul into Angel's body."
    g "Fue mi magia la que puso el alma de Patches en el cuerpo de Angel."

# game/scripts/scriptyard.rpy:330
translate spanish yardgrave_9234399f:

    # g "He clawed out of the grave himself."
    g "Él mismo salió de la tumba."

# game/scripts/scriptyard.rpy:333
translate spanish yardgrave_293f23c4:

    # s "Yeesh."
    s "Seh."

# game/scripts/scriptyard.rpy:345
translate spanish yardgrave_028c0eb1:

    # o "Do you think Patches likes being an undead cat?"
    o "¿Crees que a Patches le gusta ser un gato zombie?"

# game/scripts/scriptyard.rpy:348
translate spanish yardgrave_aeb5cf85:

    # s "Does it matter? I'd say he deserves it if it didn't mean he could crash your birthday and terrorize us all."
    s "¿Qué más da? Diría que se lo merece no por eso ahora puede arruinar tu fiesta y aterrorizarnos al resto."

# game/scripts/scriptyard.rpy:351
translate spanish yardgrave_0998583c:

    # o "I-if he wanted to come he could just ask!"
    o "¡Si quisiera venir, podría simplemente preguntar!"

# game/scripts/scriptyard.rpy:358
translate spanish yardgrave_90aa92e7:

    # o "EEK! Angel's grave's all d-dug up!"
    o "¡EEK! ¡La tumba de Angel está desenterrada!"

# game/scripts/scriptyard.rpy:360
translate spanish yardgrave_5cf0acf4:

    # o "I-it must've become a zombie too! B-but how?! I need to find everyone quick!"
    o "¡D-debe haberse convertido en un zombie también! ¡¿P-pero cómo?! ¡Necesito encontrar a todos rápido!"

# game/scripts/scriptyard.rpy:376
translate spanish yardgrave_21877c06:

    # o "EEK! Your grave's all d-dug up!"
    o "¡EEK! ¡Tu tumba está desenterrada!"

# game/scripts/scriptyard.rpy:380
translate spanish yardgrave_90aa92e7_1:

    # o "EEK! Angel's grave's all d-dug up!"
    o "¡EEK! ¡La tumba de Angel está desenterrada!"

# game/scripts/scriptyard.rpy:384
translate spanish yardgrave_faec4f71:

    # s "Weird. I wonder if these zombies have souls or remember who they were."
    s "Extraño. Me pregunto si estos zombies tienen alma o minimo recuerdan quiénes eran."

# game/scripts/scriptyard.rpy:387
translate spanish yardgrave_6708ac83:

    # n "Olive gasps excitedly."
    n "Olive jadea emocionada."

# game/scripts/scriptyard.rpy:388
translate spanish yardgrave_79b7cd3b:

    # o "If Angel's body remembers who he was th-then we'll have TWO ANGELS!!"
    o "Si el cuerpo de Angel recuerda quién era entonces ¡¡tendremos DOS ANGELES!!"

# game/scripts/scriptyard.rpy:391
translate spanish yardgrave_a95c64ec:

    # s "Heh, I guess that's a nice way to look at it."
    s "Je, supongo que es una buena manera de verlo."

# game/scripts/scriptyard.rpy:393
translate spanish yardgrave_2ea35659:

    # s "They're within the gates though... We'd better be careful in case we run into them."
    s "Aunque está dentro de las puertas... Será mejor que tengamos cuidado por si nos topamos con el."

# game/scripts/scriptyard.rpy:400
translate spanish yardgrave_5860daf2:

    # b "OHH you know what that means right?"
    b "OHH sabes lo que eso significa ¿verdad?"

# game/scripts/scriptyard.rpy:402
translate spanish yardgrave_38c53092:

    # b "It's become a zombie and is hiding somewhere in the house!!"
    b "¡¡Se ha convertido en un zombie y se esconde en algún lugar de la casa!!"

# game/scripts/scriptyard.rpy:403
translate spanish yardgrave_fb65055d:

    # b "BOoOoOoOo!"
    b "¡BOoOoOoOo!"

# game/scripts/scriptyard.rpy:407
translate spanish yardgrave_e23128cf:

    # n "Brownie tickles Olive. They scream."
    n "Brownie le hace cosquillas a Olive. Ellas gritan."

# game/scripts/scriptyard.rpy:411
translate spanish yardgrave_8b0015b8:

    # s "Brownie quit teasing them!"
    s "¡Brownie deja de molestarla!"

# game/scripts/scriptyard.rpy:413
translate spanish yardgrave_045b4dda:

    # n "Olive hides behind Sparky. Brownie laughs."
    n "Olive se esconde detrás de Sparky. Brownie se ríe."

# game/scripts/scriptyard.rpy:421
translate spanish yardgrave_d7840cbb:

    # a "This is alarming... My theory on the zombies was that their souls reclaimed their bodies..."
    a "Esto es alarmante... Mi teoría sobre los zombies era que sus almas reclamaban sus cuerpos..."

# game/scripts/scriptyard.rpy:422
translate spanish yardgrave_cf8e8640:

    # a "But my soul is in this body... Right?"
    a "Pero mi alma está en este cuerpo... ¿Verdad?"

# game/scripts/scriptyard.rpy:424
translate spanish yardgrave_6772f8d6:

    # a "What has my old body?!"
    a "¡¿Qué o quien tiene mi viejo cuerpo?!"

# game/scripts/scriptyard.rpy:428
translate spanish yardgrave_3fcb3745:

    # o "It'll be okay A-Angel, maybe they're nice! Coco will figure it out!"
    o "Todo saldrá bien A-Angel, ¡t-tal vez sean amables! ¡Coco lo solucionará!"

# game/scripts/scriptyard.rpy:431
translate spanish yardgrave_12421e77:

    # a "I hope you're r-right."
    a "Espero que tengas r-razón."

# game/scripts/scriptyard.rpy:436
translate spanish yardgrave_e4495a67:

    # s "We should let Coco know about this. I'm sure she can fix it!"
    s "Deberíamos informarle a Coco sobre esto. ¡Estoy seguro de que ella puede arreglarlo!"

# game/scripts/scriptyard.rpy:445
translate spanish yardgrave_b3fad249:

    # b "Aww don't sweat it Angel. I mean who even needs that old body; Patches messed it all up right?"
    b "Oh, no te comas la cabeza, Angel. Quiero decir, ¿quién necesita ese viejo cuerpo? Patches lo dejó hecho un desastre, ¿no?"

# game/scripts/scriptyard.rpy:449
translate spanish yardgrave_bb8e4b4e:

    # a "..."
    a "..."

# game/scripts/scriptyard.rpy:451
translate spanish yardgrave_715a280a:

    # b "Eheheh, too soon? Okay I'll shut up."
    b "Jejeje, ¿demasiado pronto? Está bien, me callaré."

# game/scripts/scriptyard.rpy:459
translate spanish yardgrave_c5484df9:

    # b "Aww don't sweat it Angel."
    b "Aww, no te preocupes, Angel."

# game/scripts/scriptyard.rpy:460
translate spanish yardgrave_57f5c8ec:

    # b "I mean who even needs that old body; Patc-"
    b "Me refiero a quién necesita siquiera ese viejo cuerpo; Patch-"

# game/scripts/scriptyard.rpy:463
translate spanish yardgrave_32498b6d:

    # s "Perhaps it doesn't matter what body you have!" with vpunch
    s "¡Quizás no importe qué cuerpo tengas!" with vpunch

# game/scripts/scriptyard.rpy:467
translate spanish yardgrave_90afd619:

    # o "Yeah! We l-love you no matter what you are!"
    o "¡Sí! ¡Te amamos sin importar lo que seas!"

# game/scripts/scriptyard.rpy:470
translate spanish yardgrave_dca3759a:

    # n "Olive hugs Angel."
    n "Olive abraza a Angel."

# game/scripts/scriptyard.rpy:473
translate spanish yardgrave_6565d3e5:

    # a "Aww... You're all so nice..."
    a "Aww... sois todos tan amables..."

# game/scripts/scriptyard.rpy:476
translate spanish yardgrave_d534271a:

    # a "I'd still like my old body though."
    a "Aunque todavía me gustaría tener mi antiguo cuerpo."

# game/scripts/scriptyard.rpy:489
translate spanish yardwindows_b2bb3d8f:

    # n "Both windows are spattered in blood and guts."
    n "Ambas ventanas están salpicadas de sangre y tripas."

# game/scripts/scriptyard.rpy:496
translate spanish yardwindows_1327e232:

    # n "In the left window is a figure, quivering and shaking unnaturally with scary pointy ears."
    n "En la ventana de la izquierda hay una figura que tiembla y se sacude de forma antinatural con aterradoras orejas puntiagudas."

# game/scripts/scriptyard.rpy:498
translate spanish yardwindows_01063c81:

    # n "In the left window is an empty kitchen."
    n "En la ventana de la izquierda hay una cocina vacía."

# game/scripts/scriptyard.rpy:500
translate spanish yardwindows_903007ec:

    # n "In the right window is a standing figure with cute floppy ears!"
    n "¡En la ventana de la derecha hay una figura de pie con lindas orejas!"

# game/scripts/scriptyard.rpy:502
translate spanish yardwindows_9a3f74fa:

    # n "In the right window is an empty living room."
    n "En la ventana de la derecha hay una sala de estar vacía."

# game/scripts/scriptyard.rpy:506
translate spanish yardwindows_991ad736:

    # o "It must've been lonely hanging out on your own. Why d-didn't you keep each other company?"
    o "Debe haber sido muy solitario estar ahí por tu cuenta. ¿Por qué n-no se hacían compañía el uno al otro?"

# game/scripts/scriptyard.rpy:509
translate spanish yardwindows_8e1f60ac:

    # a "Uh..."
    a "Oh..."

# game/scripts/scriptyard.rpy:512
translate spanish yardwindows_3094ae3e:

    # s "Um."
    s "Mmm."

# game/scripts/scriptyard.rpy:514
translate spanish yardwindows_163185fe:

    # n "Angel and Sparky look uncomfortable."
    n "Angel y Sparky parecen incómodos."

# game/scripts/scriptyard.rpy:516
translate spanish yardwindows_19bb9e11:

    # o "Oh n-n-no!! I didn't mean to put you on the sp-pot! Sometimes alone time is a nice time!!"
    o "¡¡Oh, n-n-no!! ¡No quise p-ponerte en un compromiso! ¡¡A veces pasar tiempo a solas es muy ag-gradable!!"

# game/scripts/scriptyard.rpy:519
translate spanish yardwindows_3e76d38f:

    # s "Hehehe! No it's okay Olive!"
    s "¡Jejeje! ¡No, está bien Olive!"

# game/scripts/scriptyard.rpy:523
translate spanish yardwindows_5490197f:

    # s "The truth is that I hardly know you Angel! I don't know if you're the type to forgive someone for strangling you in a sleepwalking stupor."
    s "¡La verdad es que apenas te conozco, Angel! No sé si eres del tipo de persona que perdona a alguien por estrangularte en medio de un ataque de sonambulismo."

# game/scripts/scriptyard.rpy:526
translate spanish yardwindows_0898e56c:

    # a "Oh... Is that all?"
    a "Oh... ¿Eso es todo?"

# game/scripts/scriptyard.rpy:528
translate spanish yardwindows_43ae5c55:

    # a "I was worried you'd resent me for everything that happened at school and everything that's happening now."
    a "Me preocupaba que me tuvieras resentimiento por todo lo que pasó en la escuela y todo lo que está pasando ahora."

# game/scripts/scriptyard.rpy:530
translate spanish yardwindows_cfa1a0b3:

    # a "Even your affliction is probably my fault somehow..."
    a "Incluso tu aflicción es probablemente culpa mía, de alguna manera..."

# game/scripts/scriptyard.rpy:532
translate spanish yardwindows_37818415:

    # a "If I didn't go and get myself killed none of this would have happened..."
    a "Si hubiera aceptado mi muerte, nada de esto habría pasado..."

# game/scripts/scriptyard.rpy:535
translate spanish yardwindows_f9474027:

    # s "Huh?! No way!! You can't blame yourself for what happened to you!"
    s "¡¿Eh?! ¡¡De ninguna manera!! ¡No puedes culparte por lo que te pasó!"

# game/scripts/scriptyard.rpy:537
translate spanish yardwindows_ba60dc4b:

    # s "And I suppose if you weren't murdered we wouldn't have gotten the chance to become friends!"
    s "¡Y supongo que si no te hubieran asesinado no habríamos tenido la oportunidad de hacernos amigos!"

# game/scripts/scriptyard.rpy:540
translate spanish yardwindows_a91166f7:

    # o "YEAH!! Friendship is absolutely worth d-death!!"
    o "¡¡SÍ!! ¡¡La amistad vale absolutamente la m-muerte!!"

# game/scripts/scriptyard.rpy:543
translate spanish yardwindows_4f706c07:

    # n "Sparky paps Olive's mouth disapprovingly."
    n "Sparky acaricia la boca de Olive con desaprobación."

# game/scripts/scriptyard.rpy:545
translate spanish yardwindows_c00bec2d:

    # s "That's unhealthy Olive! No!"
    s "¡Eso no es nada sano, Olive! ¡No!"

# game/scripts/scriptyard.rpy:549
translate spanish yardwindows_a71f5b03:

    # a "Aww... I mean, if I had to choose between living a long and lonely life or dying a short yet fulfilling one, I would choose the latter... As morbid as that sounds..."
    a "Aww... Quiero decir, si tuviera que elegir entre vivir una vida larga y solitaria o morir una vida corta pero satisfactoria, elegiría lo último... Por más morboso que suene..."

# game/scripts/scriptyard.rpy:552
translate spanish yardwindows_aa2b158b:

    # a "Next time I'm itching for company I'll find you Sparky!"
    a "¡La próxima vez que me muera por tener compañía, te buscaré a ti, Sparky!"

# game/scripts/scriptyard.rpy:556
translate spanish yardwindows_a03b41d0:

    # s "Yeah!"
    s "¡Sí!"

# game/scripts/scriptyard.rpy:559
translate spanish yardwindows_3fcca869:

    # o "YAY!!"
    o "¡¡HURRA!!"

# game/scripts/scriptyard.rpy:561
translate spanish yardwindows_ee8f7272:

    # n "Olive pulls Sparky and Angel into a group hug!"
    n "¡Olive atrae a Sparky y Angel a un abrazo grupal!"

# game/scripts/scriptyard.rpy:572
translate spanish yardwindows_5caefddd:

    # o "I'm so happy we're all together!"
    o "¡Estoy tan feliz de que estemos todos juntos!"

# game/scripts/scriptyard.rpy:573
translate spanish yardwindows_5731f87a:

    # o "Now we just need C-Coco!!"
    o "¡¡Ahora solo nos falta C-Coco!!"

# game/scripts/scriptyard.rpy:576
translate spanish yardwindows_d3e25906:

    # b "Hey Coco's window is just up there right?"
    b "Oye, Coco está justo ahí arriba en la ventana, ¿no?"

# game/scripts/scriptyard.rpy:579
translate spanish yardwindows_f451a165:

    # o "REALLY?!"
    o "¡¿DE VERDAD?!"

# game/scripts/scriptyard.rpy:582
translate spanish yardwindows_fe093b9a:

    # a "Uh-"
    a "Oh-"

# game/scripts/scriptyard.rpy:585
translate spanish yardwindows_b5506ca3:

    # n "Olive hops around and waves at the window!"
    n "¡Olive salta y saluda a la ventana!"

# game/scripts/scriptyard.rpy:592
translate spanish yardwindows_104e5b0f:

    # o "COCO! COCO COCO!!"
    o "¡COCO! ¡¡COCO COCO!!"

# game/scripts/scriptyard.rpy:593
translate spanish yardwindows_3c49abf9:

    # o "COME DOWN AND PLAY!!"
    o "¡¡BAJÁ A JUGAR!!"

# game/scripts/scriptyard.rpy:595
translate spanish yardwindows_9fbdade9:

    # n "There's no answer."
    n "No hay respuesta."

# game/scripts/scriptyard.rpy:598
translate spanish yardwindows_62d9b89a:

    # s "We JUST heard Coco screaming, remember?"
    s "Acabamos de escuchar a Coco gritar, ¿recuerdas?"

# game/scripts/scriptyard.rpy:601
translate spanish yardwindows_dff6003e:

    # o "OH! S-s-s-sorry I got sidetracked."
    o "¡OH! L-l-l-lo siento, me desvié."

# game/scripts/scriptyard.rpy:619
translate spanish yardzombies_f395ec76:

    # n "The zombies are wandering around, bumping into each other."
    n "Los zombies deambulan y chocan entre sí."

# game/scripts/scriptyard.rpy:622
translate spanish yardzombies_80d94595:

    # c "Okay, I can see why Sparky took matters into his own paws."
    c "Bien, puedo ver por qué Sparky tomó el la justicia por su parte."

# game/scripts/scriptyard.rpy:624
translate spanish yardzombies_3c6e1139:

    # c "BUT STILL!"
    c "¡PERO AÚN!"

# game/scripts/scriptyard.rpy:636
translate spanish yardzombies_f395ec76_1:

    # n "The zombies are wandering around, bumping into each other."
    n "Los zombies deambulan y chocan entre sí."

# game/scripts/scriptyard.rpy:648
translate spanish yardzombies_f395ec76_2:

    # n "The zombies are wandering around, bumping into each other."
    n "Los zombies deambulan y chocan entre sí."

# game/scripts/scriptyard.rpy:650
translate spanish yardzombies_802ba55a:

    # o "H-hew-hello!"
    o "¡H-Hola!"

# game/scripts/scriptyard.rpy:653
translate spanish yardzombies_aee967ac:

    # z "HAaAaYy!"
    z "¡HAaAaYy!"

# game/scripts/scriptyard.rpy:658
translate spanish yardzombies_e6159ff9:

    # n "Somehow a zombie accidentally smacks its head on a wall." with vpunch
    n "De alguna manera, un zombi golpea accidentalmente su cabeza contra una pared." with vpunch

# game/scripts/scriptyard.rpy:660
translate spanish yardzombies_b12bb19b:

    # s "I can't believe Coco trusted the search to these guys."
    s "No puedo creer que Coco confiara la búsqueda a estos tipos."

# game/scripts/scriptyard.rpy:663
translate spanish yardzombies_9c3c2ac7:

    # o "They're doing their best!!"
    o "¡¡Están haciendo lo mejor que pueden!!"

# game/scripts/scriptyard.rpy:675
translate spanish yardgate_74e8af9b:

    # o "Sparky's a t-tough boy, I'm sure he'll be okay!"
    o "Sparky es un chico duro, ¡estoy seguro de que estará bien!"

# game/scripts/scriptyard.rpy:680
translate spanish yardgate_09f911b2:

    # c "What're we gonna do if Patches and Ginger get to Sparky first?"
    c "¿Qué haremos si Patches y Ginger encuentran primero a Sparky?"

# game/scripts/scriptyard.rpy:681
translate spanish yardgate_6a073a05:

    # c "We'll need a weapon for us both!"
    c "¡Necesitaremos dos armas una para ti y otra para mi!"

# game/scripts/scriptyard.rpy:684
translate spanish yardgate_067d89b7:

    # c "We still need a weapon for me Olive!"
    c "¡Todavía necesitamos un arma para mí, Olive!"

# game/scripts/scriptyard.rpy:687
translate spanish yardgate_cd4b79d1:

    # c "We still need a weapon for you Olive!"
    c "¡Todavía necesitamos un arma para ti, Olive!"

# game/scripts/scriptyard.rpy:691
translate spanish yardgate_16498953:

    # c "Looks like we're as prepared as we can be! Let's go!"
    c "¡Parece que estamos preparados lo mejor posible! ¡Vamos!"

# game/scripts/scriptyard.rpy:703
translate spanish yardgate_14eab932:

    # o "Now that all the z-zombies are our friends we can g-go for a walk in the forest!"
    o "Ahora que todos los z-zombies son nuestros amigos, ¡podemos ir a dar un paseo por el bosque!"

# game/scripts/scriptyard.rpy:706
translate spanish yardgate_5633755e:

    # s "It might not be a good idea. There's no telling where Ginger and Patches are."
    s "Puede que no sea una buena idea. No sabemos dónde están Ginger y Patches."

# game/scripts/scriptyard.rpy:708
translate spanish yardgate_e3189546:

    # s "Let's stay on the property for now!"
    s "¡Quedémonos en la finca por ahora!"

# game/scripts/scriptyard.rpy:717
translate spanish yardgate_a7c3aef3:

    # o "W-where are we walking? The forest?"
    o "¿A d-dónde estamos caminando? ¿Al bosque?"

# game/scripts/scriptyard.rpy:720
translate spanish yardgate_bc0804ac:

    # s "Sort of... I just have a feeling that Ginger isn't going to be in the house."
    s "Más o menos... Tengo el presentimiento de que Ginger no estará cerca de la casa."

# game/scripts/scriptyard.rpy:721
translate spanish yardgate_bff6d8aa:

    # s "Why would she? We have the wand AND the zombies on our side."
    s "¿Por qué lo estaria? Tenemos la varita Y los zombies de nuestro lado."

# game/scripts/scriptyard.rpy:723
translate spanish yardgate_5b605e78:

    # s "She and Patches are at a total disadvantage in there."
    s "Ella y Patches estárian en total desventaja."

# game/scripts/scriptyard.rpy:725
translate spanish yardgate_bd5735ad:

    # s "So I'm going to search for them in the forest."
    s "Entonces voy a buscarlos al bosque."

# game/scripts/scriptyard.rpy:728
translate spanish yardgate_7f9ba11e:

    # o "It sounds a little dangerous..."
    o "Suena un poco peligroso..."

# game/scripts/scriptyard.rpy:730
translate spanish yardgate_848ff732:

    # o "But I g-guess it'll be nice walking together in the woods without a b-bunch of zombies chasing us!"
    o "¡Pero supongo que será agradable caminar juntos por el bosque sin un grupo de zombis persiguiéndonos!"

# game/scripts/scriptyard.rpy:739
translate spanish yardgate_b43feb3e:

    # n "The zombies shamble into each other and the gate." with vpunch
    n "Los zombies chocan entre sí y contra la puerta." with vpunch

# game/scripts/scriptyard.rpy:741
translate spanish yardgate_8eb876c2:

    # n "There's absolutely no threat of them breaking through. They're even less capable than when they were alive."
    n "No hay absolutamente ninguna amenaza de que entren. Son incluso menos capaces que cuando estaban vivos."

# game/scripts/scriptyard.rpy:743
translate spanish yardgate_ffbb559a:

    # n "This makes Olive outrunning them seem even less impressive."
    n "Esto hace que el hecho de que Olive lograra dejarlos atrás parezca aún menos impresionante."

# game/scripts/scriptyard.rpy:745
translate spanish yardgate_8db5cbd8:

    # o "If anyone wants to leave the house th-they'll have to get past all these zombies..."
    o "Si alguien quiere salir de casa, tendrá que superar a todos estos zombis..."

# game/scripts/scriptyard.rpy:799
translate spanish yardgate_b43feb3e_1:

    # n "The zombies shamble into each other and the gate." with vpunch
    n "Los zombies chocan entre sí y contra la puerta." with vpunch

# game/scripts/scriptyard.rpy:802
translate spanish yardgate_8eb876c2_1:

    # n "There's absolutely no threat of them breaking through. They're even less capable than when they were alive."
    n "No hay absolutamente ninguna amenaza de que entren. Son incluso menos capaces que cuando estaban vivos."

# game/scripts/scriptyard.rpy:806
translate spanish yardgate_cf555f28:

    # s "Don't get too close to them Olive!"
    s "¡No te acerques demasiado a ellos, Olive!"

# game/scripts/scriptyard.rpy:808
translate spanish yardgate_3a1786e0:

    # s "Don't get too close to them you guys!"
    s "¡No os acerquéis demasiado a ellos!"

# game/scripts/scriptyard.rpy:816
translate spanish yardgate_a50dbb31:

    # b "Eugh! They're hard to look at let alone smell."
    b "¡Eugh! Son difíciles de ver, y ni hablemos de lo que es olerlos."

# game/scripts/scriptyard.rpy:821
translate spanish yardgate_5b52fcb9:

    # a "Careful... They're not like us anymore..."
    a "Cuidado... Ya no son como nosotros..."

# game/scripts/scriptyard.rpy:840
translate spanish gameover09_f44b4a68:

    # s "In all honesty it's probably too dangerous for you..."
    s "Probablemente sea demasiado peligroso para ti..."

# game/scripts/scriptyard.rpy:843
translate spanish gameover09_9489811a:

    # o "HUH?!?"
    o "¿¡¿EH?!?"

# game/scripts/scriptyard.rpy:846
translate spanish gameover09_668e5aaa:

    # s "But... I'm kind of afraid to go alone."
    s "Pero... tengo un poco de miedo de ir solo."

# game/scripts/scriptyard.rpy:848
translate spanish gameover09_3532c1d1:

    # s "It'd be really nice to have you with me! Just make sure you stay close okay?"
    s "¡Sería muy lindo tenerte conmigo! Sólo asegúrate de permanecer cerca, ¿vale?"

# game/scripts/scriptyard.rpy:850
translate spanish gameover09_9e6c835e:

    # s "Please don't make me regret taking you along. I don't know what I'd do if you got hurt because of me."
    s "Por favor, no hagas que me arrepienta de haberte traído conmigo. No sé qué haría si salieras herida por mi culpa."

# game/scripts/scriptyard.rpy:853
translate spanish gameover09_fc07df8d:

    # o "AWWW SPARKY!!"
    o "¡¡AWWW SPARKY!!"

# game/scripts/scriptyard.rpy:855
translate spanish gameover09_fe4778bd:

    # o "No p-purroblem!! I'll be your guard dog!"
    o "¡¡No hay problema!! ¡Seré tu perro guardián!"

# game/scripts/scriptyard.rpy:858
translate spanish gameover09_9ebd5b7a:

    # s "Hehehe, thanks Olive!"
    s "Jejeje, gracias Olive!"

# game/scripts/scriptyard.rpy:878
translate spanish gameover09_1e8b7317:

    # s "Oh, you're not coming!"
    s "¡Oh, no vendrás!"

# game/scripts/scriptyard.rpy:881
translate spanish gameover09_9489811a_1:

    # o "HUH?!?"
    o "¿¡¿EH?!?"

# game/scripts/scriptyard.rpy:884
translate spanish gameover09_f930bfc7:

    # s "No, it's WAY too dangerous for you!"
    s "¡No, es MUY peligroso para ti!"

# game/scripts/scriptyard.rpy:885
translate spanish gameover09_bdf5e496:

    # s "Just stay here like a good dog and don't tell anyone where I went."
    s "Quédate aquí como un buen perro y no le digas a nadie adónde fui."

# game/scripts/scriptyard.rpy:888
translate spanish gameover09_6ebe9d47:

    # o "Th-that sounds like a b-b-bad idea!!"
    o "¡¡Eso suena como una m-m-mala idea!!"

# game/scripts/scriptyard.rpy:891
translate spanish gameover09_9c35f921:

    # s "Olive please, I need to do this alone."
    s "Olive, por favor, necesito hacer esto solo."

# game/scripts/scriptyard.rpy:892
translate spanish gameover09_e1d2ebce:

    # s "It's my fault Ginger possessed me. I wasn't strong enough to fight her off..."
    s "Es mi culpa que Ginger me poseyera. No fui lo suficientemente fuerte para luchar contra ella..."

# game/scripts/scriptyard.rpy:893
translate spanish gameover09_a2b62e2e:

    # s "I need to get..."
    s "Necesito conseguir..."

# game/scripts/scriptyard.rpy:896
translate spanish gameover09_9fc3fd6d:

    # s "Revenge..."
    s "Venganza..."

# game/scripts/scriptyard.rpy:899
translate spanish gameover09_ffdf57e0:

    # o "R-REVENGE?!"
    o "¡¿V-VENGANZA?!"

# game/scripts/scriptyard.rpy:902
translate spanish gameover09_e138d52a:

    # s "Ahahah, maybe that's a bad word for it."
    s "Ahahah, tal vez esa no sea la mejor forma de decirlo."

# game/scripts/scriptyard.rpy:904
translate spanish gameover09_a5f1b358:

    # s "Look I'll be okay. I have a trump card of sorts."
    s "Mira, estaré bien. Tengo una especie de as bajo la manga."

# game/scripts/scriptyard.rpy:907
translate spanish gameover09_dcb44747:

    # n "Sparky gives Olive a big hug and a kiss on the head."
    n "Sparky le da a Olive un gran abrazo y un beso en la cabeza."

# game/scripts/scriptyard.rpy:910
translate spanish gameover09_232434d3:

    # s "I'll see you later!"
    s "¡Te veré más tarde!"

# game/scripts/scriptyard.rpy:915
translate spanish gameover09_07abc845:

    # o "..."
    o "..."

# game/scripts/scriptyard.rpy:928
translate spanish enterwoodsmenu_401d4d71:

    # o "Th-there's something I wanna do b-before we go though!"
    o "¡Hay algo que quiero hacer antes de irnos!"

# game/scripts/scriptyard.rpy:931
translate spanish enterwoodsmenu_95a839e4:

    # s "Well alright."
    s "Bueno, está bien."

# game/scripts/scriptyard.rpy:936
translate spanish fureverloved_6fcacea2:

    # n "The top of Angel's headstone reads ''Furever Loved''."
    n "En la parte superior de la lápida de Angel se lee ''Amado por Simpre''."

# game/scripts/scriptyard.rpy:953
translate spanish woods_837fa77d:

    # s "So Ginger, what exactly do you plan to do when you see Patches?"
    s "Entonces, Ginger, ¿qué planeas hacer exactamente cuando veas a Patches?"

# game/scripts/scriptyard.rpy:957
translate spanish woods_80acb9bb:

    # g "Ugh... I'm scared just thinking about it..."
    g "Uf... tengo miedo sólo de pensarlo..."

# game/scripts/scriptyard.rpy:958
translate spanish woods_146f41d3:

    # g "It just... Hurts so much when someone you love is disappointed in you."
    g "Es que... duele muchísimo cuando alguien que amas se siente decepcionado de ti."

# game/scripts/scriptyard.rpy:960
translate spanish woods_417ebb0a:

    # g "I can't imagine he'll be too happy if I ask him to spare you and your friends."
    g "No creo que le haga mucha gracia que le pida que les perdone la vida a ti y a tus amigos."

# game/scripts/scriptyard.rpy:962
translate spanish woods_5a12573f:

    # g "So that just means I'll have to use my abilities to... Convince him..."
    g "Así que eso solo significa que tendré que usar mis habilidades para... convencerlo..."

# game/scripts/scriptyard.rpy:968
translate spanish woods_6be4112b:

    # s "Just remember, Patches has been using you to torment us. I really doubt he actually cares about you."
    s "Solo recuerda, Patches te ha estado usando para atormentarnos. Realmente dudo que se preocupe por ti."

# game/scripts/scriptyard.rpy:971
translate spanish woods_7dc9fcd5:

    # s "No offense."
    s "Sin ofender."

# game/scripts/scriptyard.rpy:973
translate spanish woods_4b340443:

    # g "..."
    g "..."

# game/scripts/scriptyard.rpy:975
translate spanish woods_77a0e81f:

    # o "I just th-think it'd be nice if we were all friends!"
    o "¡Creo que sería bueno si todos fuéramos amigos!"

# game/scripts/scriptyard.rpy:984
translate spanish woods_3cc89e32:

    # o "E-even if things end up r-really really bad,"
    o "I-incluso si las cosas terminan m-muy, muy mal,"

# game/scripts/scriptyard.rpy:985
translate spanish woods_03224282:

    # o "You're actually a really good boy!!!"
    o "¡¡¡Eres realmente un buen perro!!!"

# game/scripts/scriptyard.rpy:987
translate spanish woods_1a146bab:

    # o "I say th-that a lot but it's true and everyone thinks so!"
    o "¡D-digo eso muy seguido, pero es la verdad y todo el mundo piensa lo mismo!"

# game/scripts/scriptyard.rpy:991
translate spanish woods_e1554201:

    # s "..."
    s "..."

# game/scripts/scriptyard.rpy:1003
translate spanish woods_09ec9f68:

    # o "Soooo..."
    o "Muuuy..."

# game/scripts/scriptyard.rpy:1006
translate spanish woods_297d93f3:

    # c "What?"
    c "¿Qué?"

# game/scripts/scriptyard.rpy:1009
translate spanish woods_9f3acb1d:

    # o "H-how do you feel about Patches?"
    o "¿Cómo te sientes acerca de Patches?"

# game/scripts/scriptyard.rpy:1012
translate spanish woods_f7c8a86b:

    # c "WHAT?!"
    c "¡¿QUÉ?!"

# game/scripts/scriptyard.rpy:1014
translate spanish woods_19cb7497:

    # c "Olive you're kidding me right? He killed my little brother, stole his dead body and is using it to terrorize us all."
    c "Olive, estás bromeando, ¿verdad? Mató a mi hermano pequeño, robó su cadáver y lo está usando para aterrorizarnos a todos."

# game/scripts/scriptyard.rpy:1015
translate spanish woods_13c8c8e6:

    # c "Not only that he's just creepy in general. What kind of a dog tries to be friends with a cat?!"
    c "No sólo es espeluznante en general. ¿Qué clase de perro intenta ser amigo de un gato?"

# game/scripts/scriptyard.rpy:1018
translate spanish woods_59b7ca5c:

    # o "Huh?! He tried to be friends with you?!"
    o "¡¿Eh?! ¡¿Intentó ser amigo tuyo?!"

# game/scripts/scriptyard.rpy:1021
translate spanish woods_5efbd1f3:

    # c "No not me! Angel!!"
    c "¡No, mio no! ¡¡de Angel!!"

# game/scripts/scriptyard.rpy:1023
translate spanish woods_4cc88141:

    # c "They were ''just friends'' or so Angel says."
    c "Eran ''sólo amigos'', o eso dice Angel."

# game/scripts/scriptyard.rpy:1024
translate spanish woods_dbe1bbd8:

    # c "But it sounds like Patches started getting more and more clingy."
    c "Pero parece que Patches empezó a volverse cada vez más pegajoso."

# game/scripts/scriptyard.rpy:1026
translate spanish woods_c3962588:

    # c "I kept an eye on Angel whenever I could but... I was just so busy with my studies."
    c "Vigilaba a Angel siempre que podía pero... estaba muy ocupada con mis estudios."

# game/scripts/scriptyard.rpy:1029
translate spanish woods_8d0a7660:

    # c "I should've paid more attention."
    c "Debería haber prestado más atención."

# game/scripts/scriptyard.rpy:1032
translate spanish woods_c09a12e0:

    # o "AHH! I-it's not like this is your fault Coco!!"
    o "¡AH! ¡¡N-no es tu culpa Coco!!"

# game/scripts/scriptyard.rpy:1035
translate spanish woods_04740c0f:

    # c "... It kind of is though."
    c "... Aunque en cierto modo lo es."

# game/scripts/scriptyard.rpy:1038
translate spanish woods_c2175868:

    # o "NOoOoOo!!"
    o "¡¡NOoOoO!!"

# game/scripts/scriptyard.rpy:1040
translate spanish woods_f87c109c:

    # o "You didn't TRY t-to get Angel killed! And you sure as h-heck didn't TRY to get us in this mess!"
    o "¡Tú no INTENTASTE que m-mataran a Angel! ¡Y te aseguro que n-ni de broma INTENTASTE meternos en este lío!"

# game/scripts/scriptyard.rpy:1043
translate spanish woods_d19f855d:

    # c "..."
    c "..."

# game/scripts/scriptyard.rpy:1047
translate spanish woods_b9b63306:

    # c "Thanks Olive."
    c "Gracias Olive."

# game/scripts/scriptyard.rpy:1051
translate spanish woods_a4ffffdb:

    # o "It's pretty spooky out here! But w-way less s-spooky when you're n-not running from a hoard of z-z-zombies!!"
    o "¡Es bastante espeluznante aquí afuera! ¡¡Pero es mucho menos espeluznante cuando no estás huyendo de una horda de z-z-zombis!!"

# game/scripts/scriptyard.rpy:1054
translate spanish woods_9a69f682:

    # s "Heh yeah I bet!"
    s "¡Je, sí, Supongo!"

# game/scripts/scriptyard.rpy:1055
translate spanish woods_1235155e:

    # s "I walked here with Brownie so it wasn't too bad."
    s "Caminé hasta aquí con Brownie, así que no estuvo tan mal."

# game/scripts/scriptyard.rpy:1057
translate spanish woods_4872206f:

    # s "To be honest we should've stopped by your place and picked you up,"
    s "Para ser honesto, deberíamos haber pasado por tu casa y recogerte."

# game/scripts/scriptyard.rpy:1058
translate spanish woods_41e809fe:

    # s "But Brownie was adamant the party would be more surprising if you just walked here alone."
    s "Pero Brownie insistió en que la fiesta sería más ''sorpresa'' si caminases hasta aquí sola."

# game/scripts/scriptyard.rpy:1061
translate spanish woods_a35a2bcd:

    # o "Heheheh she's so silly!! Sh-she told me about the party daaays ago!!"
    o "Jejejeje es tan tonta!! ¡¡E-ella me habló de la fiesta hace días!!"

# game/scripts/scriptyard.rpy:1064
translate spanish woods_fb3f2ab9:

    # s "Heheh yeah. I'm lucky to have friends so silly they'd let me break their limbs with no retaliation."
    s "Jejeje, sí. Tengo suerte de tener amigos tan tontos que dejarían que les rompa las extremidades sin represalias."

# game/scripts/scriptyard.rpy:1067
translate spanish woods_3f2cd093:

    # o "Do you think Patches and Ginger are l-like us? F-furiends?"
    o "¿Crees que Patches y Ginger son como nosotros? ¿A-amigos?"

# game/scripts/scriptyard.rpy:1070
translate spanish woods_fc2bc1b3:

    # s "Ugh, it's hard to believe that either could be sympathetic enough to feel anything for another living creature."
    s "Uf, es difícil creer que alguno de ellos pueda ser lo suficientemente comprensivo como para sentir algo por otra criatura viviente."

# game/scripts/scriptyard.rpy:1073
translate spanish woods_d2dcb1e7:

    # s "If they did though, I'm not sure how I'd feel about that..."
    s "Sin embargo, si lo hicieran, no estoy seguro de cómo me sentiría al respecto..."

# game/scripts/scriptyard.rpy:1081
translate spanish woods_4217de6b:

    # n "Brances and dried up leaves crunch under their paws."
    n "Las ramas y las hojas secas crujen bajo sus patas."

# game/scripts/scriptyard.rpy:1082
translate spanish woods_8004c21d:

    # n "Olive can't help but feel dread."
    n "Olive no puede evitar sentir miedo."

# game/scripts/scriptyard.rpy:1087
translate spanish woods_11dd6323:

    # n "Branches and dried up leaves crunch under their paws."
    n "Las ramas y las hojas secas crujen bajo sus patas."

# game/scripts/scriptyard.rpy:1102
translate spanish woods2_ba7b8bd1:

    # g "Olive, what do you think of Patches?"
    g "Olive, ¿qué opinas de Patches?"

# game/scripts/scriptyard.rpy:1104
translate spanish woods2_f1ece730:

    # g "It's obvious Sparky here doesn't think too highly of him."
    g "Es obvio que Sparky no tiene una buena opinión de él."

# game/scripts/scriptyard.rpy:1107
translate spanish woods2_e2fd178f:

    # s "HE'S A LITERAL SERIAL KILLER."
    s "ES UN ASESINO EN SERIE LITERALMENTE."

# game/scripts/scriptyard.rpy:1112
translate spanish woods2_c0d7a063:

    # o "I-I-I think h-he's good!"
    o "¡C-C-Creo que es buen perro!"

# game/scripts/scriptyard.rpy:1115
translate spanish woods2_4b340443:

    # g "..."
    g "..."

# game/scripts/scriptyard.rpy:1117
translate spanish woods2_ddca83a4:

    # g "Really? After everything he's done?"
    g "¿De verdad? ¿Después de todo lo que ha hecho?"

# game/scripts/scriptyard.rpy:1118
translate spanish woods2_ff705d63:

    # g "Why do you think he's good?"
    g "¿Por qué crees que es bueno?"

# game/scripts/scriptyard.rpy:1121
translate spanish woods2_16cad523:

    # o "Oh w-well, he's... A dog!"
    o "Oh, b-bueno, él es... ¡Un perro!"

# game/scripts/scriptyard.rpy:1124
translate spanish woods2_e034f2d1:

    # o "And I love dogs!"
    o "¡Y amo a los perros!"

# game/scripts/scriptyard.rpy:1127
translate spanish woods2_310b0b45:

    # g "You'd love anything huh?"
    g "Tu amas cualquier cosa, ¿no?"

# game/scripts/scriptyard.rpy:1130
translate spanish woods2_c97b5db1:

    # g "It makes your love worthless, you realize that right?"
    g "Hace que tu amor sea inútil, ¿te das cuenta, verdad?"

# game/scripts/scriptyard.rpy:1133
translate spanish woods2_b47b00d9:

    # o "But love is g-g-good so the more the merrier!"
    o "Pero el amor es b-bueno, ¡cuanto más, mejor!"

# game/scripts/scriptyard.rpy:1136
translate spanish woods2_56bef5a3:

    # g "I suppose."
    g "Supongo."

# game/scripts/scriptyard.rpy:1141
translate spanish woods2_7cca85c3:

    # o "I th-think he's a little bit bad..."
    o "C-creo que es un poquito malo..."

# game/scripts/scriptyard.rpy:1145
translate spanish woods2_4b340443_1:

    # g "..."
    g "..."

# game/scripts/scriptyard.rpy:1146
translate spanish woods2_eef53596:

    # g "He's a living being with feelings."
    g "Él es un ser vivo con sentimientos."

# game/scripts/scriptyard.rpy:1147
translate spanish woods2_95f08fdc:

    # g "I know he's done bad things but... So have I..."
    g "Sé que ha hecho cosas malas pero... yo también..."

# game/scripts/scriptyard.rpy:1149
translate spanish woods2_d0af91b3:

    # g "If you believe I can be redeemed then Patches can be redeemed too..."
    g "Si crees que yo puedo redimirme, entonces quiza Patches también puede redimirse..."

# game/scripts/scriptyard.rpy:1151
translate spanish woods2_93455f2e:

    # g "Right?"
    g "¿Bien?"

# game/scripts/scriptyard.rpy:1155
translate spanish woods2_70827221:

    # o "O-of course!!"
    o "¡¡P-Por supuesto!!"

# game/scripts/scriptyard.rpy:1161
translate spanish woods2_02687e87:

    # n "Olive and Sparky run as fast as they can through the woods."
    n "Olive y Sparky corren lo más rápido que pueden por el bosque."

# game/scripts/scriptyard.rpy:1162
translate spanish woods2_acd1b9f5:

    # n "Sparky keeps his pace while Olive is struggling to keep up!"
    n "¡Sparky mantiene su ritmo mientras Olive lucha por seguirle el ritmo!"

# game/scripts/scriptyard.rpy:1164
translate spanish woods2_0b8216ed:

    # o "S-Sparky! J-just so you know, I'm n-not mad at you! F-for any of this!! It's not your f-fault!"
    o "¡S-Sparky! ¡P-para que lo sepas, no estoy enojado contigo! ¡¡P-por algo de esto!! ¡No es tu culpa!"

# game/scripts/scriptyard.rpy:1167
translate spanish woods2_e1554201:

    # s "..."
    s "..."

# game/scripts/scriptyard.rpy:1176
translate spanish woods2_a64cbd7b:

    # o "I never knew the forest was so big!!"
    o "¡¡Nunca supe que el bosque era tan grande!!"

# game/scripts/scriptyard.rpy:1177
translate spanish woods2_76509a6c:

    # o "You and Angel must be pretty lonely living out here on your own, huh?"
    o "Tú y Angel debéis estar bastante solos viviendo aquí, ¿eh?"

# game/scripts/scriptyard.rpy:1180
translate spanish woods2_fbe68f69:

    # c "Ehh not really. You'll find other cats slinking around sometimes."
    c "Eh, en realidad no. A veces encontrarás otros gatos merodeando por ahí."

# game/scripts/scriptyard.rpy:1182
translate spanish woods2_4587fa1b:

    # c "And sometimes sneaky dalmatians."
    c "Y a veces dálmatas astutos."

# game/scripts/scriptyard.rpy:1185
translate spanish woods2_17c088c0:

    # o "M-maybe Patches was lonely too..."
    o "T-tal vez Patches también se sentía solo..."

# game/scripts/scriptyard.rpy:1189
translate spanish woods2_47f483bc:

    # c "DON'T defend him Olive."
    c "NO lo defiendas Olive."

# game/scripts/scriptyard.rpy:1190
translate spanish woods2_2af35afa:

    # c "Patches was never going to change just because he had Angel as a friend."
    c "Patches nunca iba a cambiar simplemente por el hecho de tener a Angel como amigo."

# game/scripts/scriptyard.rpy:1193
translate spanish woods2_3bd7d04d:

    # c "There's just no hope for a dog like him."
    c "Simplemente no hay esperanza para un perro como él."

# game/scripts/scriptyard.rpy:1198
translate spanish woods2_03c7535a:

    # n "Sparky is quiet."
    n "Sparky está callado."

# game/scripts/scriptyard.rpy:1200
translate spanish woods2_e2086f0b:

    # o "So... W-what will w-we do when we find them?"
    o "Entonces... ¿Q-qué haremos cuando los encontremos?"

# game/scripts/scriptyard.rpy:1202
translate spanish woods2_842b7dac:

    # o "H-how about we m-make fun of them until they chase us and w-we can lead them back to the party!"
    o "¿Q-qué tal si nos b-burlamos de ellos hasta que nos persigan y p-podamos llevarlos de vuelta a la fiesta?"

# game/scripts/scriptyard.rpy:1204
translate spanish woods2_a7b64ca7:

    # o "A-and then they'll s-see how nice everything is when we're all together!"
    o "¡Y luego verán qué bonito es todo cuando estemos todos juntos!"

# game/scripts/scriptyard.rpy:1206
translate spanish woods2_bc29e6d8:

    # o "T-they can help us d-decorate Brownie and Angel's bandages some m-more,"
    o "Pueden ayudarnos a decorar un poco m-más las vendas de Brownie y Angel."

# game/scripts/scriptyard.rpy:1208
translate spanish woods2_d9f1d7b0:

    # o "And h-help us eat cake and m-maybe even help stitch up the zombies!!!"
    o "¡Y que nos ay-yuden a terminar el pastel y q-quizás hasta nos ayuden a coser a los zombis!!!"

# game/scripts/scriptyard.rpy:1211
translate spanish woods2_c514ddc4:

    # s "Olive..."
    s "Olive..."

# game/scripts/scriptyard.rpy:1213
translate spanish woods2_19ef683b:

    # n "Sparky laughs awkwardly."
    n "Sparky se ríe nerviosamente."

# game/scripts/scriptyard.rpy:1216
translate spanish woods2_70fe366d:

    # s "I'm glad you're here with me. I know you think I'm a lot stronger and braver than everyone else,"
    s "Me alegro que estés aquí conmigo. Sé que piensas que soy mucho más fuerte y valiente que todos los demás."

# game/scripts/scriptyard.rpy:1218
translate spanish woods2_ba5e8189:

    # s "But I'd be really sad out here alone."
    s "Pero estaría muy triste aquí solo."

# game/scripts/scriptyard.rpy:1221
translate spanish woods2_5dd1f8c3:

    # o "O-oh, yeah it is p-pretty scary out here!"
    o "O-oh, sí, ¡da bastante miedo aquí afuera!"

# game/scripts/scriptyard.rpy:1222
translate spanish woods2_aacf9332:

    # o "I'm glad you're with me too Sparky."
    o "Me alegro que estés conmigo también Sparky."

# game/scripts/scriptyard.rpy:1229
translate spanish woods2_7af4a5c3:

    # n "Olive wonders if everyone had died at school and their souls were banished to these dark woods."
    n "Olive se pregunta si todos los muertos del instituto y sus almas habrán sido desterradas en estos bosques oscuros."

# game/scripts/scriptyard.rpy:1230
translate spanish woods2_9d387d16:

    # n "They shake their head and think about bacon instead."
    n "Sacude la cabeza y piensa sobre tocino."

# game/scripts/scriptyard.rpy:1234
translate spanish woods2_55cbeaed:

    # n "For a small pup the woods seem to stretch on infinitely."
    n "Para una cachorra pequeña, el bosque parece extenderse infinitamente."

# game/scripts/scriptyard.rpy:1251
translate spanish woods3_0ebaaf73:

    # s "We've walked pretty far into the forest. Maybe it's about time we-"
    s "Nos hemos adentrado bastante en el bosque. Tal vez ya sea hora de que-"

# game/scripts/scriptyard.rpy:1254
translate spanish woods3_453b1c1e:

    # g "Wait a second..."
    g "Espera un segundo..."

# game/scripts/scriptyard.rpy:1255
translate spanish woods3_a5c557c3:

    # g "This whole time you've been talking so badly of Patches."
    g "Todo este tiempo has estado hablando tan mal de Patches."

# game/scripts/scriptyard.rpy:1256
translate spanish woods3_244aa1d9:

    # g "Telling me he's just using me, that he deserves punishment."
    g "Diciéndome que sólo me está usando, que merece castigo."

# game/scripts/scriptyard.rpy:1260
translate spanish woods3_39a6ce4e:

    # g "But I am guilty of crimes as well."
    g "Pero también soy culpable de algunos crímenes."

# game/scripts/scriptyard.rpy:1261
translate spanish woods3_5b30d011:

    # g "The only reason you forgive me is because I can help you stop Patches."
    g "La única razón por la que me perdonas es porque puedo ayudarte a detener a Patches."

# game/scripts/scriptyard.rpy:1262
translate spanish woods3_93455f2e:

    # g "Right?"
    g "¿Verdad?"

# game/scripts/scriptyard.rpy:1265
translate spanish woods3_e42069e8:

    # o "NOoOoOo! You're our friend now!! That's why we don't want to hurt you!"
    o "¡NOoOoOo! ¡¡Ahora eres nuestra amiga!! ¡Por eso no queremos hacerte daño!"

# game/scripts/scriptyard.rpy:1268
translate spanish woods3_feb4b1b0:

    # s "And stopping Patches is the right thing to do!"
    s "¡Y detener Patches es lo correcto!"

# game/scripts/scriptyard.rpy:1269
translate spanish woods3_2f9cb5b6:

    # s "If we let him run rampant he'll kill us all and probably continue hurting others!"
    s "¡Si lo dejamos andar a sus anchas, nos matará a todos y probablemente seguirá haciendo daño a los demás!"

# game/scripts/scriptyard.rpy:1271
translate spanish woods3_324e64c7:

    # s "He might even hurt you one day!"
    s "¡Podría incluso hacerte daño a ti algún día!"

# game/scripts/scriptyard.rpy:1274
translate spanish woods3_112c4ad6:

    # g "Why do you two care about me. You don't even know me..."
    g "¿Por qué ustedes dos se preocupan por mí? Ni siquiera me conocen..."

# game/scripts/scriptyard.rpy:1276
translate spanish woods3_3b5d9431:

    # g "Patches knows me though..."
    g "Aunque Patches me conoce..."

# game/scripts/scriptyard.rpy:1280
translate spanish woods3_c27adb61:

    # g "OH MY DOG!!"
    g "¡¡OH POR TODOS LOS PERROS!!"

# game/scripts/scriptyard.rpy:1281
translate spanish woods3_94cbcbf4:

    # g "I can't believe I almost turned my back on him!!"
    g "¡¡No puedo creer que casi le doy la espalda!!"

# game/scripts/scriptyard.rpy:1283
translate spanish woods3_4832165c:

    # g "He was right, you're all a bunch of manipulative bullies!!"
    g "Tenía razón, ¡¡sois todos un montón de perros manipuladores!!"

# game/scripts/scriptyard.rpy:1286
translate spanish woods3_cb24ff51:

    # o "HUH?!"
    o "¡¿EH?!"

# game/scripts/scriptyard.rpy:1290
translate spanish woods3_c5349b53:

    # n "With a burst of red light, Olive and Sparky are thrown into the cellar!" with vpunch
    n "¡Con un estallido de luz roja, Olive y Sparky son arrojados al sótano!" with vpunch

# game/scripts/scriptyard.rpy:1296
translate spanish woods3_50ffcc5f:

    # c "!!!" with vpunch
    c "!!!" with vpunch

# game/scripts/scriptyard.rpy:1298
translate spanish woods3_c07aa02f:

    # n "Deep in the woods is a cellar entrance where Sparky is found, strapped down and dissected."
    n "En las profundidades del bosque hay una entrada a un sótano donde encuentran a Sparky, atado y diseccionado."

# game/scripts/scriptyard.rpy:1300
translate spanish woods3_9aaa8c70:

    # o "S-SPARKY!!"
    o "¡¡S-SPARKY!!"

# game/scripts/scriptyard.rpy:1302
translate spanish woods3_e1554201:

    # s "..."
    s "..."

# game/scripts/scriptyard.rpy:1304
translate spanish woods3_02568389:

    # c "HOLY SHIT!! H-HE'S STILL ALIVE!"
    c "¡¡PERO QUÉ MIERDA!! ¡¡A-AÚN ESTÁ VIVO!!"

# game/scripts/scriptyard.rpy:1305
translate spanish woods3_cde5d174:

    # c "I th-think I'm gonna be sick."
    c "Creo que voy a vomitar."

# game/scripts/scriptyard.rpy:1307
translate spanish woods3_dfb8a934:

    # s "R.."
    s "C.."

# game/scripts/scriptyard.rpy:1308
translate spanish woods3_8900ebab:

    # s "... Ru... n..."
    s "... Co..rr..an..."

# game/scripts/scriptyard.rpy:1316
translate spanish woods3_62fb55dc:

    # p "... Hello kitten. Hello puppy..." with vpunch
    p "...Hola gatito. Hola cachorro..." with vpunch

# game/scripts/scriptyard.rpy:1319
translate spanish woods3_8fb5cb19:

    # c "WHOA!! What the hell happened to you?!"
    c "¡¡GUAU!! ¡¿Qué carajos te pasó?!"

# game/scripts/scriptyard.rpy:1322
translate spanish woods3_1c0da791:

    # p "This piece of shit banished Ginger to Inferno..."
    p "Este pedazo de basura desterró a Ginger al infierno..."

# game/scripts/scriptyard.rpy:1323
translate spanish woods3_86d839ec:

    # p "And he really did a number on me too."
    p "Y a mí también me dejó bastante tocado, la verdad."

# game/scripts/scriptyard.rpy:1325
translate spanish woods3_ae3d0fa1:

    # p "Too bad though, I got ahold of the wand and have been making him pay ever since..."
    p "Es una lástima... Pero me hice con la varita y le he estado haciendo pagar desde entonces..."

# game/scripts/scriptyard.rpy:1328
translate spanish woods3_1bba5edc:

    # o "Why would you do this... Now you're both so hurt..."
    o "¿Por qué harías algo así...? Ahora los dos están tan heridos..."

# game/scripts/scriptyard.rpy:1331
translate spanish woods3_7ac9691b:

    # p "This body isn't long for this world."
    p "Este cuerpo no vivira mucho mas en este mundo."

# game/scripts/scriptyard.rpy:1333
translate spanish woods3_dd5dba1b:

    # p "But I'll find my way back... I always do."
    p "Pero encontraré el camino de regreso... siempre lo hago."

# game/scripts/scriptyard.rpy:1339
translate spanish woods3_d682e35f:

    # n "Patches sets Sparky on fire with the wand!!" with vpunch
    n "¡Patches prende fuego a Sparky con la varita!" with vpunch

# game/scripts/scriptyard.rpy:1340
translate spanish woods3_64905ed3:

    # n "The magic embers spread in an instant!"
    n "¡Las brasas mágicas se extendien en un instante!"

# game/scripts/scriptyard.rpy:1342
translate spanish woods3_705bc3f0:

    # c "NO!!"
    c "¡¡NO!!"

# game/scripts/scriptyard.rpy:1345
translate spanish woods3_df388711:

    # n "Olive and Coco scramble to find a way out of the woods!"
    n "¡Olive y Coco luchan por encontrar una manera de salir del bosque!"

# game/scripts/scriptyard.rpy:1346
translate spanish woods3_40b66d6e:

    # n "But they're completely surrounded!"
    n "¡Pero están completamente rodeadas!"

# game/scripts/scriptyard.rpy:1351
translate spanish woods3_54f29cf6:

    # n "Every trace of them is burnt away until there's nothing left." with vpunch
    n "Cada rastro de ellas y de Patches es quemado hasta que no queda nada." with vpunch

# game/scripts/scriptyard.rpy:1358
translate spanish woods3_ba70c848:

    # s "Olive! I thought you weren't coming for a second!"
    s "¡Olive! ¡Por un segundo pensé que no vendrías!"

# game/scripts/scriptyard.rpy:1360
translate spanish woods3_485100cd:

    # s "Let's go! If Patches has the wand who knows what havoc he's wreaking."
    s "¡Vamos! Si Patches tiene la varita, quién sabe qué estragos está causando."

# game/scripts/scriptyard.rpy:1368
translate spanish woods3_257d62f2:

    # o "W-WHOA!!! A s-super secret cellar! It's got a big lock on it!"
    o "¡¡¡G-GUAU!!! ¡Una bodega súper secreta! ¡Tiene un gran candado!"

# game/scripts/scriptyard.rpy:1371
translate spanish woods3_27381752:

    # n "Muffled sounds can be heard from within."
    n "Se pueden oír sonidos apagados que provienen del interior."

# game/scripts/scriptyard.rpy:1374
translate spanish woods3_35cc3895:

    # n "Olive and Sparky press their ears against the door. Someone is sobbing loudly."
    n "Olive y Sparky presionan sus orejas contra la puerta. Alguien está sollozando ruidosamente."

# game/scripts/scriptyard.rpy:1376
translate spanish woods3_d70b6306:

    # o "I-it sounds like Ginger. She's all alone and crying!! W-we need to get in and help her!"
    o "Suena como Ginger. ¡¡Está sola y llorando!! ¡Necesitamos entrar y ayudarla!"

# game/scripts/scriptyard.rpy:1380
translate spanish woods3_b6797d56:

    # n "Sparky tries to open the cellar door but it won't budge."
    n "Sparky intenta abrir la puerta del sótano pero no se mueve."

# game/scripts/scriptyard.rpy:1383
translate spanish woods3_279693da:

    # o "M-maybe Coco or Angel know where the key is. Let's run back in and tell th-them!"
    o "Quizás Coco o Angel sepan dónde está la llave. ¡Volvamos corriendo y se lo decimos!"

# game/scripts/scriptyard.rpy:1386
translate spanish woods3_2e8cc2d3:

    # s "Wait... I have a better idea."
    s "Espera... tengo una idea mejor."

# game/scripts/scriptyard.rpy:1388
translate spanish woods3_3ecdca1e:

    # n "Sparky reaches into his jacket..."
    n "Sparky mete la mano en su chaqueta..."

# game/scripts/scriptyard.rpy:1391
translate spanish woods3_a81c78be:

    # n "And pulls out Coco's wand!"
    n "¡Y saca la varita de Coco!"

# game/scripts/scriptyard.rpy:1393
translate spanish woods3_99136a3e:

    # o "H-HUH?!? How did you g-g-get that?!"
    o "¿¡¿E-EH?!? ¡¿Cómo c-c-conseguiste eso?!"

# game/scripts/scriptyard.rpy:1397
translate spanish woods3_7ddba697:

    # n "He blasts the lock right off!" with vpunch
    n "¡Él hace estallar la cerradura!" with vpunch

# game/scripts/scriptyard.rpy:1398
translate spanish woods3_66d230e2:

    # n "The sobbing from within the cellar goes uninterrupted."
    n "Los sollozos desde el interior del sótano son interrumpidos."

# game/scripts/scriptyard.rpy:1400
translate spanish woods3_b816af4a:

    # s "Sorry Olive..."
    s "Lo siento Olive..."

# game/scripts/scriptyard.rpy:1401
translate spanish woods3_ba8a9c60:

    # s "I stole the wand from Coco while she was distracted but it was for a good reason!"
    s "Le robé la varita a Coco mientras estaba distraída, ¡pero fue por una buena razón!"

# game/scripts/scriptyard.rpy:1403
translate spanish woods3_c66ca3ca:

    # s "I'm going to kill Ginger!"
    s "¡Voy a matar a Ginger!"

# game/scripts/scriptyard.rpy:1406
translate spanish woods3_6a0172c0:

    # o "W-WHAT?!"
    o "¡¿Q-QUÉ?!"

# game/scripts/scriptyard.rpy:1409
translate spanish woods3_3ab06e12:

    # s "Oh, sorry!!"
    s "Ah lo siento!!"

# game/scripts/scriptyard.rpy:1412
translate spanish woods3_3cd787fd:

    # s "I mean BANISH her!"
    s "¡Me refiero a desterrarla!"

# game/scripts/scriptyard.rpy:1415
translate spanish woods3_7193c310:

    # o "OH. I-I guess that's b-b-better?"
    o "OH. ¿S-supongo que eso es m-m-mejor?"

# game/scripts/scriptyard.rpy:1417
translate spanish woods3_45b614f1:

    # o "But shouldn't we let the zombies and C-Coco take care of this? Coco will be super mad that we took her w-wand."
    o "¿Pero no deberíamos dejar que los zombies y C-Coco se encarguen de esto? Coco estará súper enojada porque le quitamos su varita."

# game/scripts/scriptyard.rpy:1418
translate spanish woods3_101e0b16:

    # o "And we might get h-hurt if we face Ginger alone."
    o "Y podríamos salir h-heridos si nos enfrentamos a Ginger solos."

# game/scripts/scriptyard.rpy:1421
translate spanish woods3_63a5508c:

    # s "I need to be the one to face her. No one else can get hurt."
    s "Necesito ser yo quien la enfrente. Nadie más puede salir lastimado."

# game/scripts/scriptyard.rpy:1424
translate spanish woods3_fe0008bb:

    # n "Sparky sighs and pats Olive on the head."
    n "Sparky suspira y le da una palmadita a Olive en la cabeza."

# game/scripts/scriptyard.rpy:1427
translate spanish woods3_3deee453:

    # s "You're too cute to stop me. Just wait up here okay?"
    s "Eres demasiado linda para detenerme. Espera aquí arriba, ¿vale?"

# game/scripts/scriptyard.rpy:1430
translate spanish woods3_c309cd26:

    # n "Sparky lifts the heavy cellar door up. Moonlight streams onto the steps headed down into the darkness."
    n "Sparky levanta la pesada puerta del sótano. La luz de la luna se cuela sobre los escalones que descienden hacia la oscuridad."

# game/scripts/scriptyard.rpy:1434
translate spanish woods3_39e149d7:

    # n "He enters, not waiting for Olive."
    n "El entra, sin esperar a Olive."

# game/scripts/scriptyard.rpy:1435
translate spanish woods3_afdc3258:

    # n "They wait around a little..."
    n "Ella espera un poco..."

# game/scripts/scriptyard.rpy:1437
translate spanish woods3_03a66fcc:

    # n "But in a fit of anxiety they end up scampering down the steps behind him."
    n "Pero en un ataque de ansiedad ella termina corriendo escaleras abajo detrás de él."

# game/scripts/scriptyard.rpy:1446
translate spanish gameover07_3ac665b2:

    # o "R-right!!"
    o "¡¡C-Correcto!!"

# game/scripts/scriptyard.rpy:1463
translate spanish gameover07_0135cb89:

    # o "I d-don't know... I just wanted to have a nice walk in the woods with my pals..."
    o "No lo sé... Sólo quería dar un agradable paseo por el bosque con mis amigos..."

# game/scripts/scriptyard.rpy:1466
translate spanish gameover07_82c10d77:

    # s "Olive, are you procrastinating?"
    s "Olive, ¿estás procrastinando?"

# game/scripts/scriptyard.rpy:1469
translate spanish gameover07_e2100747:

    # o "S-sorry..."
    o "L-lo siento..."

# game/scripts/scriptyard.rpy:1472
translate spanish gameover07_faf7281b:

    # g "Aww, it's alright Olive!"
    g "¡Aww, está bien, Olive!"

# game/scripts/scriptyard.rpy:1473
translate spanish gameover07_c1cfc69d:

    # g "Knowing Patches he probably won't hurt your friends until we show up!"
    g "¡Conociendo a Patches, probablemente no lastimará a tus amigos hasta que aparezcamos!"

# game/scripts/scriptyard.rpy:1475
translate spanish gameover07_a4c885a6:

    # g "Nothing like having an audience!"
    g "¡Nada como tener a una audiencia!"

# game/scripts/scriptyard.rpy:1478
translate spanish gameover07_dc299333:

    # s "That's dark."
    s "Eso está oscuro."

# game/scripts/scriptyard.rpy:1482
translate spanish gameover07_0fd030e4:

    # g "A little walk couldn't hurt, right Sparky?"
    g "Un pequeño paseo no vendría mal, ¿verdad Sparky?"

# game/scripts/scriptyard.rpy:1485
translate spanish gameover07_646c333f:

    # s "I guess so. Just a little one though!"
    s "Supongo que sí. ¡Aunque sólo uno pequeño!"

translate spanish strings:

    # game/scripts/scriptyard.rpy:76
    old "{color=#a1bd65}Inspect house.{/color}"
    new "{color=#a1bd65}Inspeccionar la casa.{/color}"

    # game/scripts/scriptyard.rpy:76
    old "{color=#a1bd65}Inspect grave.{/color}"
    new "{color=#a1bd65}Inspeccionar la tumba.{/color}"

    # game/scripts/scriptyard.rpy:76
    old "{color=#a1bd65}Inspect windows.{/color}"
    new "{color=#a1bd65}Inspeccionar ventanas.{/color}"

    # game/scripts/scriptyard.rpy:76
    old "{color=#a1bd65}Inspect zombies.{/color}"
    new "{color=#a1bd65}Inspeccionar a los zombis.{/color}"

    # game/scripts/scriptyard.rpy:76
    old "{color=#a1bd65}Inspect gate.{/color}"
    new "{color=#a1bd65}Inspeccionar la puerta.{/color}"

    # game/scripts/scriptyard.rpy:76
    old "{color=#b290ca}Enter woods.{/color}"
    new "{color=#b290ca}Entrar en el bosque.{/color}"

    # game/scripts/scriptyard.rpy:76
    old "{color=#ffcd65}Enter house.{/color}"
    new "{color=#ffcd65}Entrar a la casa.{/color}"

    # game/scripts/scriptyard.rpy:831
    old "Sparky stays with Olive."
    new "Sparky va con Olive."

    # game/scripts/scriptyard.rpy:831
    old "{color=#ffffff66}Sparky stays with Olive.{/color}"
    new "{color=#ffffff66}Sparky va con Olive.{/color}"

    # game/scripts/scriptyard.rpy:831
    old "{color=#ffffff66}Sparky goes alone.{/color}"
    new "{color=#ffffff66}Sparky va solo.{/color}"

    # game/scripts/scriptyard.rpy:831
    old "Sparky goes alone."
    new "Sparky va solo."

    # game/scripts/scriptyard.rpy:922
    old "Enter woods."
    new "Entrar en el bosque."

    # game/scripts/scriptyard.rpy:922
    old "Stay."
    new "Permanecer."

    # game/scripts/scriptyard.rpy:981
    old "Talk."
    new "Hablar."

    # game/scripts/scriptyard.rpy:981
    old "Run home!"
    new "¡Correr a casa!"

    # game/scripts/scriptyard.rpy:999
    old "Keep quiet."
    new "Callar."

    # game/scripts/scriptyard.rpy:1109
    old "Patches is good."
    new "Patches es bueno."

    # game/scripts/scriptyard.rpy:1109
    old "Patches is bad."
    new "Patches es malo."

    # game/scripts/scriptyard.rpy:1442
    old "Go back."
    new "Volver."

    # game/scripts/scriptyard.rpy:1442
    old "{color=#ffffff66}Procrastinate.{/color}"
    new "{color=#ffffff66}Procrastinar.{/color}"

    # game/scripts/scriptyard.rpy:1442
    old "Procrastinate."
    new "Procrastinar.."

