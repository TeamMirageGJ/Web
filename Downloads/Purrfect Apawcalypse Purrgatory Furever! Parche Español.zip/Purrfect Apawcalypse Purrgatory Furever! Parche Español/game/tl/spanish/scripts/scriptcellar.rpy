﻿# TODO: Translation updated at 2024-11-25 12:57

# game/scripts/scriptcellar.rpy:14
translate spanish cellarintro_2d2f4528:

    # n "Olive and Sparky hit the cement floor hard!" with vpunch
    n "¡Olive y Sparky caen fuertemente al suelo de cemento!" with vpunch

# game/scripts/scriptcellar.rpy:17
translate spanish cellarintro_b032adeb:

    # n "The portal is still lit with orange flames."
    n "El portal todavía está iluminado con llamas."

# game/scripts/scriptcellar.rpy:19
translate spanish cellarintro_14de3ef5:

    # s "WAIT GINGER!!"
    s "¡¡ESPERA GINGER!!"

# game/scripts/scriptcellar.rpy:22
translate spanish cellarintro_b279ae38:

    # n "The cellar doors slam shut behind her." with vpunch
    n "Las puertas del sótano se cierran de golpe detrás de ella." with vpunch

# game/scripts/scriptcellar.rpy:24
translate spanish cellarintro_f8e60555:

    # s "GINGER!! I'M SORRY!!"
    s "¡¡GINGER!! ¡¡LO LAMENTO!!"

# game/scripts/scriptcellar.rpy:26
translate spanish cellarintro_a5652ed9:

    # s "I didn't mean to hurt your feelings!! I really didn't!"
    s "¡¡No quise herir tus sentimientos!! ¡Realmente no lo hice!"

# game/scripts/scriptcellar.rpy:27
translate spanish cellarintro_62682d04:

    # s "I'm just bad at words! Not that that's an excuse!"
    s "¡Solo soy malo con las palabras! ¡No es que eso sea una excusa!"

# game/scripts/scriptcellar.rpy:30
translate spanish cellarintro_2731de00:

    # s "Sometimes you can't help how you feel about someone, even if they're a bad person."
    s "A veces no puedes evitar lo que sientes por alguien, incluso si es una mala persona."

# game/scripts/scriptcellar.rpy:31
translate spanish cellarintro_94a27a90:

    # s "I should've just, I don't know..."
    s "Debería haberlo hecho, no lo sé..."

# game/scripts/scriptcellar.rpy:34
translate spanish cellarintro_6b3d0828:

    # s "Tried to understand you."
    s "Traté de entenderte."

# game/scripts/scriptcellar.rpy:36
translate spanish cellarintro_4b340443:

    # g "..."
    g "..."

# game/scripts/scriptcellar.rpy:39
translate spanish cellarintro_37aed49d:

    # g "You can't manipulate me anymore."
    g "Ya no puedes manipularme."

# game/scripts/scriptcellar.rpy:44
translate spanish cellarintro_6306e02e:

    # n "Sparky backs away from Ginger but finds himself against the portal!"
    n "¡Sparky se aleja de Ginger pero se encuentra en el portal!"

# game/scripts/scriptcellar.rpy:46
translate spanish cellarintro_389bf16e:

    # o "P-PLEASE DON'T BANISH US!!"
    o "¡¡P-POR FAVOR NO NOS DESTERREN!!"

# game/scripts/scriptcellar.rpy:49
translate spanish cellarintro_1c968a2d:

    # g "Banish?"
    g "¿Desterrar?"

# game/scripts/scriptcellar.rpy:51
translate spanish cellarintro_46801e62:

    # g "Oh I'm not going to banish you. That's not what Patches would want."
    g "Oh, no te voy a desterrar. Eso no es lo que Patches querría."

# game/scripts/scriptcellar.rpy:52
translate spanish cellarintro_59eab991:

    # g "Here's what I'll do..."
    g "Esto es lo que haré..."

# game/scripts/scriptcellar.rpy:60
translate spanish cellarintro_466b5e6c:

    # g "The perfect gift for the perfect boy!"
    g "¡El regalo perfecto para el chico perfecto!"

# game/scripts/scriptcellar.rpy:69
translate spanish cellarintro_4754d102:

    # n "Olive fumbles in the dark for a bit."
    n "Olive hurga un rato en la oscuridad."

# game/scripts/scriptcellar.rpy:70
translate spanish cellarintro_3e32e81f:

    # n "They bump into someone!"
    n "¡Ella se topa con alguien!"

# game/scripts/scriptcellar.rpy:76
translate spanish cellarintro_f5fc5dd6:

    # n "Sparky finds a pull cord attached to a light!"
    n "¡Sparky encuentra un cordón sujeto a una luz!"

# game/scripts/scriptcellar.rpy:78
translate spanish cellarintro_7b3c7109:

    # s "Jeez Olive I told you to wait outside. It's been only been like 10 seconds."
    s "Dios Olive, te dije que esperaras afuera. Sólo han pasado como 10 segundos."

# game/scripts/scriptcellar.rpy:81
translate spanish cellarintro_56504164:

    # o "I-it felt a lot longer to me, sorry!!"
    o "¡¡Me pareció mucho más largo, lo siento!!"

# game/scripts/scriptcellar.rpy:84
translate spanish cellarintro_d0ec18c3:

    # n "In the dim light they find Ginger sobbing."
    n "En la penumbra encuentran a Ginger sollozando."

# game/scripts/scriptcellar.rpy:101
translate spanish cellarmenu_f3825679:

    # n "Olive considers leaving just as soon as they arrived."
    n "Olive considera irse tan pronto como llegaron."

# game/scripts/scriptcellar.rpy:104
translate spanish cellarmenu_9291ad36:

    # s "Olive I can't do this with you running all over the place, just stand there!"
    s "Olive, no puedo hacer esto contigo corriendo por todos lados, ¡quédate ahí!"

# game/scripts/scriptcellar.rpy:111
translate spanish cellarmenu_d61fe1e1:

    # o "B-bye Ginger..."
    o "A-adiós Ginger..."

# game/scripts/scriptcellar.rpy:124
translate spanish cellarlantern_3d3361e3:

    # n "There's a shrivelled old jack o' lantern sitting on a barrel."
    n "Hay una vieja calabaza arrugada sobre un barril."

# game/scripts/scriptcellar.rpy:130
translate spanish cellarlantern_3d3361e3_1:

    # n "There's a shrivelled old jack o' lantern sitting on a barrel."
    n "Hay una vieja calabaza arrugada sobre un barril."

# game/scripts/scriptcellar.rpy:134
translate spanish cellarlantern_1266e0b0:

    # o "I know w-we're here to commit a horrible d-deed but..."
    o "Sé que estamos aquí para cometer un acto horrible, pero..."

# game/scripts/scriptcellar.rpy:136
translate spanish cellarlantern_80b402f6:

    # n "Olive scratches away at the bottom of the crumbling jack o' lantern."
    n "Olive rasca la parte inferior de la calabaza."

# game/scripts/scriptcellar.rpy:138
translate spanish cellarlantern_b15b6667:

    # n "They stick it on their head!"
    n "¡Ella se la pone en la cabeza!"

# game/scripts/scriptcellar.rpy:139
translate spanish cellarlantern_62c477af:

    # o "B-BOOO!!"
    o "¡¡B-BOOO!!"

# game/scripts/scriptcellar.rpy:142
translate spanish cellarlantern_55319178:

    # s "AHAHAH!"
    s "¡AJAJAJAJA!"

# game/scripts/scriptcellar.rpy:144
translate spanish cellarlantern_ab593cf6:

    # s "Damn it Olive, I can't take anything seriously when you're like this."
    s "Maldita sea Olive, no puedo tomarme nada en serio cuando estás así."

# game/scripts/scriptcellar.rpy:149
translate spanish cellarlantern_37f20a03:

    # o "H-hey Ginger what do you think of this?"
    o "E-ey, Ginger, ¿qué opinas de esto?"

# game/scripts/scriptcellar.rpy:152
translate spanish cellarlantern_4b340443:

    # g "..."
    g "..."

# game/scripts/scriptcellar.rpy:154
translate spanish cellarlantern_aeb4aaea:

    # o "It's pretty s-spooky huh?"
    o "Es bastante e-espeluznante, ¿eh?"

# game/scripts/scriptcellar.rpy:157
translate spanish cellarlantern_4b340443_1:

    # g "..."
    g "..."

# game/scripts/scriptcellar.rpy:159
translate spanish cellarlantern_80b402f6_1:

    # n "Olive scratches away at the bottom of the crumbling jack o' lantern."
    n "Olive rasca la parte inferior de la calabaza."

# game/scripts/scriptcellar.rpy:161
translate spanish cellarlantern_b15b6667_1:

    # n "They stick it on their head!"
    n "¡Se lo pone en la cabeza!"

# game/scripts/scriptcellar.rpy:163
translate spanish cellarlantern_41c0f3c6:

    # o "BOOO!!"
    o "¡¡BUUU!!"

# game/scripts/scriptcellar.rpy:166
translate spanish cellarlantern_d06ab3d8:

    # n "Ginger giggles and promptly covers her mouth."
    n "Ginger se ríe y rápidamente se cubre la boca."

# game/scripts/scriptcellar.rpy:170
translate spanish cellarlantern_2c17f6bd:

    # n "Olive sticks the crumbling jack o' lantern on their head again."
    n "Olive se vuelve a poner la calabaza desmoronada en la cabeza."

# game/scripts/scriptcellar.rpy:172
translate spanish cellarlantern_41c0f3c6_1:

    # o "BOOO!!"
    o "¡¡BUUU!!"

# game/scripts/scriptcellar.rpy:174
translate spanish cellarlantern_7a71a669:

    # g "I already saw you do that with Sparky."
    g "Ya te vi hacer eso con Sparky."

# game/scripts/scriptcellar.rpy:177
translate spanish cellarlantern_53515779:

    # g "It was pretty funny though..."
    g "Aunque fue bastante divertido..."

# game/scripts/scriptcellar.rpy:189
translate spanish cellarginger_ae6c44d6:

    # n "Ginger seems deep in thought."
    n "Ginger parece sumida en sus pensamientos."

# game/scripts/scriptcellar.rpy:197
translate spanish cellarginger_050bea78:

    # o "A-are you okay Ginger?"
    o "¿E-estás bien Ginger?"

# game/scripts/scriptcellar.rpy:199
translate spanish cellarginger_4b340443:

    # g "..."
    g "..."

# game/scripts/scriptcellar.rpy:201
translate spanish cellarginger_048900b0:

    # o "I w-wish I could just make everyone happy..."
    o "D-desearía poder hacer felices a todos..."

# game/scripts/scriptcellar.rpy:203
translate spanish cellarginger_4b340443_1:

    # g "..."
    g "..."

# game/scripts/scriptcellar.rpy:205
translate spanish cellarginger_0bd95d68:

    # o "I sh-should go find Sparky. Coco told me to make sure he doesn't get into any trouble."
    o "Debería ir a buscar a Sparky. Coco me dijo que me asegurara de que no se metiera en problemas."

# game/scripts/scriptcellar.rpy:207
translate spanish cellarginger_5ffde072:

    # o "OH I think you'd like Coco! She's magical too!"
    o "¡OH, creo que te gustaría conocer a Coco! ¡Ella también es mágica!"

# game/scripts/scriptcellar.rpy:209
translate spanish cellarginger_4b340443_2:

    # g "..."
    g "..."

# game/scripts/scriptcellar.rpy:211
translate spanish cellarginger_b0d2958d:

    # o "And B-Brownie is really goofy. She'd probably cheer you up a-at least for a second."
    o "Y B-Brownie es realmente tonta. Probablemente te animaría al menos por un segundo."

# game/scripts/scriptcellar.rpy:212
translate spanish cellarginger_8bfafeaa:

    # o "And Angel is really sweet and c-caring! He used to be a ghost too!"
    o "¡Y Angel es realmente dulce y cariñoso! ¡Él también era un fantasma!"

# game/scripts/scriptcellar.rpy:214
translate spanish cellarginger_be1f8b07:

    # g "... Angel?"
    g "... ¿Angel?"

# game/scripts/scriptcellar.rpy:216
translate spanish cellarginger_75ba33fb:

    # g "I don't think we'd get along... He's the one who hurt Patches and stole his body!"
    g "No creo que nos llevemos bien... ¡Él es quien lastimó a Patches y robó su cuerpo!"

# game/scripts/scriptcellar.rpy:218
translate spanish cellarginger_bd975a82:

    # g "Although I suppose Patches did the same to him..."
    g "Aunque supongo que Patches le hizo lo mismo..."

# game/scripts/scriptcellar.rpy:220
translate spanish cellarginger_0cb84fcf:

    # g "What do I do Olive... I don't know who to trust."
    g "¿Qué hago Olive? No sé en quién confiar."

# game/scripts/scriptcellar.rpy:222
translate spanish cellarginger_2763dbd6:

    # o "Well y-you could come back to the house with me!"
    o "¡Bueno, podrías volver a la casa conmigo!"

# game/scripts/scriptcellar.rpy:225
translate spanish cellarginger_3def0d23:

    # o "N-not to fight Patches or Angel or anyone!"
    o "N-no ¡no para pelear con Patches ni con Angel ni con nadie!"

# game/scripts/scriptcellar.rpy:227
translate spanish cellarginger_f676a34d:

    # o "Maybe it'd be nice to just sit in the living room and have some cake!"
    o "¡Tal vez sería bueno simplemente sentarse en la sala y comer un poco de pastel!"

# game/scripts/scriptcellar.rpy:228
translate spanish cellarginger_972ef67b:

    # o "I-if you want..."
    o "S-si quieres..."

# game/scripts/scriptcellar.rpy:232
translate spanish cellarginger_4b340443_3:

    # g "..."
    g "..."

# game/scripts/scriptcellar.rpy:242
translate spanish cellarginger_1e27d866:

    # s "Hey! Ginger, right?"
    s "¡Ey! Ginger, ¿verdad?"

# game/scripts/scriptcellar.rpy:245
translate spanish cellarginger_2ad54a7c:

    # g "Sniffle."
    g "Sollozo."

# game/scripts/scriptcellar.rpy:248
translate spanish cellarginger_eea90d54:

    # s "Y-you recognize me don't you? You took my body!!"
    s "Me reconoces, ¿no? ¡¡Tu tomaste mi cuerpo!!"

# game/scripts/scriptcellar.rpy:250
translate spanish cellarginger_51106e8e:

    # n "Ginger is ignoring Sparky."
    n "Ginger está ignorando a Sparky."

# game/scripts/scriptcellar.rpy:252
translate spanish cellarginger_82bcc007:

    # s "AUGH!!!"
    s "¡¡¡AUGH!!!"

# game/scripts/scriptcellar.rpy:253
translate spanish cellarginger_8b803e39:

    # s "Look I'm trying here. I'm trying very hard to find a reason not to kill you."
    s "Mira, lo estoy intentando. Estoy intentando con todas mis fuerzas encontrar una razón para no matarte."

# game/scripts/scriptcellar.rpy:255
translate spanish cellarginger_9f8d9a00:

    # s "Apologize! Show remorse! T-tell me Patches forced you to do all of this!"
    s "¡Discúlpate! ¡Muestra arrepentimiento! ¡D-dime que Patches te obligó a hacer todo esto!"

# game/scripts/scriptcellar.rpy:258
translate spanish cellarginger_76421a36:

    # n "Ginger goes quiet."
    n "Ginger se queda en silencio."

# game/scripts/scriptcellar.rpy:260
translate spanish cellarginger_846c5376:

    # g "How can you kill me...?"
    g "¿Cómo puedes matarme...?"

# game/scripts/scriptcellar.rpy:263
translate spanish cellarginger_ac53ef1a:

    # g "If I'm already dead...?"
    g "¿Si ya estoy muerta...?"

# game/scripts/scriptcellar.rpy:266
translate spanish cellarginger_047b1d0c:

    # s "... You're kidding me right?"
    s "...Estás bromeando ¿verdad?"

# game/scripts/scriptcellar.rpy:269
translate spanish cellarginger_13e619e9:

    # n "Ginger sniffles. Sparky sighs."
    n "Ginger solloza. Sparky suspira."

# game/scripts/scriptcellar.rpy:271
translate spanish cellarginger_8fcb666d:

    # n "He pulls out a marker and begins drawing an ominous circle on the ground."
    n "Saca un marcador y comienza a dibujar un círculo siniestro en el suelo."

# game/scripts/scriptcellar.rpy:272
translate spanish cellarginger_ebb3a5ca:

    # n "Ginger doesn't bat an eye."
    n "Ginger no se inmuta."

# game/scripts/scriptcellar.rpy:276
translate spanish cellarginger_95f1d058:

    # n "The circle is complete! With one swing of the wand it bursts into bright orange flames." with vpunch
    n "¡El círculo está completo! Con un solo movimiento de varita, estalla en llamas brillantes." with vpunch

# game/scripts/scriptcellar.rpy:284
translate spanish cellarginger_570d3022:

    # n "Olive punches Sparky square in the jaw!" with vpunch
    n "¡Olive golpea a Sparky directamente en la mandíbula!" with vpunch

# game/scripts/scriptcellar.rpy:286
translate spanish cellarginger_916a832b:

    # s "AGH! OLIVE!"
    s "¡AGH! ¡OLIVE!"

# game/scripts/scriptcellar.rpy:289
translate spanish cellarginger_9c8ea8f0:

    # n "They continue batting at him!" with vpunch
    n "Ella continúa golpeandolo!" with vpunch

# game/scripts/scriptcellar.rpy:291
translate spanish cellarginger_c83027ba:

    # o "B-B-BAD!! B-BAD D-D-DOG!!"
    o "¡¡M-M-MALO!! ¡¡M-MAL P-P-PERRO!!"

# game/scripts/scriptcellar.rpy:294
translate spanish cellarginger_48ff671d:

    # n "Their soft paws hurt nothing but Sparky's guilty conscience." with vpunch
    n "Sus suaves patas no causan daño alguno, salvo a la conciencia culpable de Sparky." with vpunch

# game/scripts/scriptcellar.rpy:296
translate spanish cellarginger_ba7a99f6:

    # s "I-I... SHE'S the bad dog!!"
    s "E-E... ¡¡ELLA es la perra mala!!"

# game/scripts/scriptcellar.rpy:299
translate spanish cellarginger_31b3f0d5:

    # o "NO!! YOU'RE BOTH BAD DOGS!"
    o "¡¡NO!! ¡AMBOS SON PERROS MALOS!"

# game/scripts/scriptcellar.rpy:304
translate spanish cellarginger_47ce9479:

    # n "Olive grabs the wand from Sparky!"
    n "¡Olive le arrebata la varita a Sparky!"

# game/scripts/scriptcellar.rpy:305
translate spanish cellarginger_4b340443_4:

    # g "..."
    g "..."

# game/scripts/scriptcellar.rpy:309
translate spanish cellarginger_df12103b:

    # n "Ginger sniffles. Sparky is silent."
    n "Ginger solloza. Sparky no dice nada."

# game/scripts/scriptcellar.rpy:310
translate spanish cellarginger_1d8c8b40:

    # n "Olive scampers towards Ginger."
    n "Olive corre hacia Ginger."

# game/scripts/scriptcellar.rpy:312
translate spanish cellarginger_22fe0c09:

    # o "W-why are you c-crying? D-do you want to talk about it?"
    o "¿P-por qué estás l-llorando? ¿Quieres hablar de eso?"

# game/scripts/scriptcellar.rpy:314
translate spanish cellarginger_3d8ee954:

    # g "I... Failed..."
    g "Yo... fallé..."

# game/scripts/scriptcellar.rpy:315
translate spanish cellarginger_14a4cc4c:

    # g "I'm a failure."
    g "Soy un fracaso."

# game/scripts/scriptcellar.rpy:317
translate spanish cellarginger_1d968686:

    # n "Ginger continues sobbing."
    n "Ginger continúa sollozando."

# game/scripts/scriptcellar.rpy:318
translate spanish cellarginger_3a0f8d07:

    # n "Olive tries to pat her on the back,"
    n "Olive intenta darle una palmadita en la espalda,"

# game/scripts/scriptcellar.rpy:320
translate spanish cellarginger_4e767b75:

    # n "But their paw phases through her body! They just pretend to pet her instead."
    n "¡Pero sus patas atraviesan su cuerpo! En su lugar, simplemente finge acariciarla."

# game/scripts/scriptcellar.rpy:323
translate spanish cellarginger_70fca640:

    # g "P-Patches, he w-won't talk to me."
    g "P-Patches, él no me habla."

# game/scripts/scriptcellar.rpy:324
translate spanish cellarginger_52c4c16f:

    # g "I-I don't know what to do."
    g "N-no sé qué hacer."

# game/scripts/scriptcellar.rpy:325
translate spanish cellarginger_32111e37:

    # g "Before I met him I had nothing to live for. I had no one."
    g "Antes de conocerlo no tenía nada por lo qué vivir. No tenía a nadie."

# game/scripts/scriptcellar.rpy:327
translate spanish cellarginger_3e2af3e7:

    # g "All I had were these strange abilities. Abilities that labelled me as a freak."
    g "Todo lo que tenía eran estas extrañas habilidades. Habilidades que me etiquetaron como una perra extraño..."

# game/scripts/scriptcellar.rpy:329
translate spanish cellarginger_31c13666:

    # g "Until I found him, as alone and strange as I was."
    g "Hasta que lo encontré, tan solo y extraño como yo."

# game/scripts/scriptcellar.rpy:331
translate spanish cellarginger_64fee5a4:

    # g "Alive, we were alone, but in death we found each other. Kindred spirits."
    g "Vivos estábamos solos, pero en la muerte nos encontramos. Espíritus afines."

# game/scripts/scriptcellar.rpy:332
translate spanish cellarginger_5dc53267:

    # g "If not for him I would have just stayed in the Inferno forever, but he gave me a reason to use my abilities to come back here."
    g "Si no fuera por él, me habría quedado en el Infierno para siempre, pero él me dio una razón para usar mis habilidades y volver aquí."

# game/scripts/scriptcellar.rpy:334
translate spanish cellarginger_c1ce9369:

    # g "But now I have no one..."
    g "Pero ahora no tengo a nadie..."

# game/scripts/scriptcellar.rpy:335
translate spanish cellarginger_02ad939c:

    # g "I am sorry Olive, Sparky."
    g "Lo siento Olive, Sparky."

# game/scripts/scriptcellar.rpy:337
translate spanish cellarginger_7d436138:

    # g "I really am pathetic and worthless. Just send me to the Inferno where I belong."
    g "Realmente soy patética e inútil. Sólo envíame al Infierno al que pertenezco."

# game/scripts/scriptcellar.rpy:339
translate spanish cellarginger_a328582b:

    # s "... Ginger..."
    s "... Ginger..."

# game/scripts/scriptcellar.rpy:342
translate spanish cellarginger_16a780ca:

    # g "That's what you wanted to hear, right?"
    g "Eso es lo que querías oír, ¿verdad?"

# game/scripts/scriptcellar.rpy:346
translate spanish cellarginger_6365344c:

    # g "JUST BANISH ME!!" with vpunch
    g "¡¡¡SOLO DESTERRENME!!!" with vpunch

# game/scripts/scriptcellar.rpy:353
translate spanish cellarginger_ad5f350d:

    # o "AGH!!" with vpunch
    o "AGH!!" with vpunch

# game/scripts/scriptcellar.rpy:354
translate spanish cellarginger_cc013a51:

    # s "OLIVE?! W-WHAT'S GOING ON?!"
    s "¡¿OLIVE?! ¡¿Q-QUÉ ESTÁ PASANDO?!"

# game/scripts/scriptcellar.rpy:355
translate spanish cellarginger_85ad8b08:

    # pu "HEHEHEH!"
    pu "¡JEJEJE!"

# game/scripts/scriptcellar.rpy:356
translate spanish cellarginger_7618d42d:

    # g "Patches?!"
    g "¿Patches?"

# game/scripts/scriptcellar.rpy:368
translate spanish cellarginger_f2cb2ad8:

    # n "Sparky scrambles for the pull cord. He turns the light back on!"
    n "Sparky lucha por agarrar el cordón. ¡El vuelve a encender la luz!"

# game/scripts/scriptcellar.rpy:370
translate spanish cellarginger_64b95452:

    # o "O-OW!!"
    o "¡¡A-AY!!"

# game/scripts/scriptcellar.rpy:373
translate spanish cellarginger_10ed2f99:

    # s "OLIVE!! OH DOG HE CUT YOU!"
    s "¡¡OLIVE!! ¡OH MIERDA, EL TE CORTÓ!"

# game/scripts/scriptcellar.rpy:376
translate spanish cellarginger_3be03e68:

    # o "Th-th-the w-wand!! It's gone!!"
    o "¡¡La-varita!! ¡¡Se ha ido!!"

# game/scripts/scriptcellar.rpy:379
translate spanish cellarginger_c5f714b9:

    # s "Who cares!! Are you alright?!"
    s "¡¡A quién le importa!! ¡¿Estás bien?!"

# game/scripts/scriptcellar.rpy:382
translate spanish cellarginger_86c82133:

    # o "O-oh y-yeah I'm fine!!"
    o "O-oh sí-sí, ¡¡estoy bien!!"

# game/scripts/scriptcellar.rpy:385
translate spanish cellarginger_daaed46a:

    # g "Patches! It was Patches! I'd recognize that cute laugh from anywhere!!"
    g "¡Patches! ¡Fue patches! ¡¡Reconocería esa linda risa desde cualquier lugar!!"

# game/scripts/scriptcellar.rpy:386
translate spanish cellarginger_dee0b68e:

    # g "H-he must've come back here to save me! M-maybe he hasn't given up on me after all! Maybe I'm worth something!!"
    g "¡Debe haber regresado aquí para salvarme! ¡Quizás no se ha rendido conmigo después de todo! ¡Quizás valgo algo!"

# game/scripts/scriptcellar.rpy:390
translate spanish cellarginger_c0909193:

    # s "Y-YOU-"
    s "T-TU-"

# game/scripts/scriptcellar.rpy:391
translate spanish cellarginger_0a433629:

    # s "You were just bait weren't you?!"
    s "Eras sólo un cebo, ¿no?"

# game/scripts/scriptcellar.rpy:392
translate spanish cellarginger_6feffe1c:

    # s "Don't you even care that he's using you?! You're ready to die just because a windbag like Patches might think less of you?"
    s "¿Ni siquiera te importa que te esté usando? ¿Estás dispuesta a morir solo porque un charlatán como Patches podría pensar menos de ti?"

# game/scripts/scriptcellar.rpy:394
translate spanish cellarginger_33b99b34:

    # s "Do you realize how many times I'd give up if I thought like that?"
    s "¿Te das cuenta de cuántas veces me rendiría si pensara así?"

# game/scripts/scriptcellar.rpy:396
translate spanish cellarginger_436807db:

    # s "This is all my fault. We could all die here because of me..."
    s "Todo esto es culpa mía. Todos podríamos morir aquí por mi culpa..."

# game/scripts/scriptcellar.rpy:398
translate spanish cellarginger_1e9286a3:

    # s "B-but I'm not just gonna sob in a corner until someone tells me it's not my fault."
    s "P-pero no voy a llorar en un rincón hasta que alguien me diga que no es mi culpa."

# game/scripts/scriptcellar.rpy:401
translate spanish cellarginger_4b340443_5:

    # g "..."
    g "..."

# game/scripts/scriptcellar.rpy:403
translate spanish cellarginger_8bed3d19:

    # s "Ugh. I need to fix this."
    s "Ugh. Necesito arreglar esto."

# game/scripts/scriptcellar.rpy:407
translate spanish cellarginger_b5737951:

    # n "Sparky runs out of the cellar!"
    n "¡Sparky sale corriendo del sótano!"

# game/scripts/scriptcellar.rpy:415
translate spanish cellarginger_72c0bbcc:

    # s "Are we going to do this the hard way?"
    s "¿Vamos a hacer esto de la manera difícil?"

# game/scripts/scriptcellar.rpy:418
translate spanish cellarginger_52703df3:

    # g "No... I'll go..."
    g "No... si voy a ir..."

# game/scripts/scriptcellar.rpy:420
translate spanish cellarginger_31fdba90:

    # n "Ginger stands up and floats slowly towards the circle."
    n "Ginger se levanta y flota lentamente hacia el círculo."

# game/scripts/scriptcellar.rpy:422
translate spanish cellarginger_87ff3d1e:

    # g "At least this way Patches will never have to deal with me again."
    g "Al menos así Patches nunca más tendrá que tratar conmigo."

# game/scripts/scriptcellar.rpy:424
translate spanish cellarginger_e4dff66a:

    # s "Not exactly."
    s "No exactamente."

# game/scripts/scriptcellar.rpy:427
translate spanish cellarginger_1085e524:

    # s "I'm going to send him to Inferno as well."
    s "Voy a enviarlo a Infierno también."

# game/scripts/scriptcellar.rpy:429
translate spanish cellarginger_68834d10:

    # g "W-WHAT?!"
    g "¡¿Q-QUÉ?!"

# game/scripts/scriptcellar.rpy:433
translate spanish cellarginger_279f5a21:

    # n "Before Ginger can contest further she's swallowed up by the portal's flames." with vpunch
    n "Antes de que Ginger pueda seguir luchando, es tragada por las llamas del portal." with vpunch

# game/scripts/scriptcellar.rpy:439
translate spanish cellarginger_2f01c5dc:

    # o "NOoOoOoOo!!" with vpunch
    o "NOoOoOoOo!!" with vpunch

# game/scripts/scriptcellar.rpy:441
translate spanish cellarginger_2d448149:

    # o "You m-made her so s-sad!!"
    o "¡¡La h-hiciste tan triste!!"

# game/scripts/scriptcellar.rpy:442
translate spanish cellarginger_fbea32b3:

    # o "And just before she left."
    o "Y justo antes de que ella se fuera."

# game/scripts/scriptcellar.rpy:445
translate spanish cellarginger_e1554201:

    # s "..."
    s "..."

# game/scripts/scriptcellar.rpy:447
translate spanish cellarginger_5168e682:

    # s "Come on Olive we need to find Patches."
    s "Vamos Olive, necesitamos encontrar a Patches."

# game/scripts/scriptcellar.rpy:449
translate spanish cellarginger_8f4dc3c3:

    # s "Then this can all be over..."
    s "Entonces todo esto podra terminar..."

# game/scripts/scriptcellar.rpy:454
translate spanish cellarginger_4d68f2c4:

    # n "Sparky leaves the cellar."
    n "Sparky sale del sótano."

# game/scripts/scriptcellar.rpy:462
translate spanish cellardeath_6f8a23c7:

    # n "Olive attempts to leave the cellar but it seems the doors have been closed on them."
    n "Olive intenta salir del sótano pero parece que le han cerrado las puertas."

# game/scripts/scriptcellar.rpy:464
translate spanish cellardeath_342a7ba2:

    # o "EEP!!"
    o "¡¡dEEP!!"

# game/scripts/scriptcellar.rpy:467
translate spanish cellardeath_e36444d3:

    # n "They push the door as hard as they can! It won't budge. It almost seems to be magically sealed!"
    n "¡Empuja la puerta tan fuerte como puede! No cederá. ¡Casi parece estar sellado mágicamente!"

# game/scripts/scriptcellar.rpy:469
translate spanish cellardeath_61c626ce:

    # o "S-S-SPARKY?! Help, I'm l-locked in!!"
    o "¡¿S-S-SPARKY?! ¡¡Ayuda, estoy encerrada!!"

# game/scripts/scriptcellar.rpy:471
translate spanish cellardeath_2dc6d36b:

    # n "They press their ear against the heavy door. They can hear yelling on the other side."
    n "Presiona su oreja contra la pesada puerta. Puede oír gritos al otro lado."

# game/scripts/scriptcellar.rpy:474
translate spanish cellardeath_c23b3b9f:

    # n "Something crashes against the door!" with vpunch
    n "¡Algo choca contra la puerta!" with vpunch

# game/scripts/scriptcellar.rpy:475
translate spanish cellardeath_a7a6b6e5:

    # n "It still won't budge."
    n "Todavía no se mueve."

# game/scripts/scriptcellar.rpy:477
translate spanish cellardeath_fd5d30db:

    # o "SPARKY SPARKY SPARKY!! A-are you okay?"
    o "¡¡SPARKY, SPARKY, SPARKY!! ¿E-estás bien?"

# game/scripts/scriptcellar.rpy:480
translate spanish cellardeath_53fa3f32:

    # n "Blood begins seeping under the door."
    n "La sangre comienza a filtrarse por debajo de la puerta."

# game/scripts/scriptcellar.rpy:482
translate spanish cellardeath_00b5c33a:

    # o "AHHH!!"
    o "¡¡AHHH!!"

# game/scripts/scriptcellar.rpy:484
translate spanish cellardeath_c083cd22:

    # p "... Ol...v...?"
    p "...¿Ol...v...?"

# game/scripts/scriptcellar.rpy:485
translate spanish cellardeath_d29c9872:

    # n "Patches' voice can be heard through the door!"
    n "¡La voz de Patches se puede escuchar a través de la puerta!"

# game/scripts/scriptcellar.rpy:486
translate spanish cellardeath_47625c44:

    # p "W...ll, t...o d...gs w...th on... st...ne is...'t t...o bad ...t all..."
    p "B...u-bueno, d...o-dos pe-rros de u...n s...olo gol-pe n...o e...stá t...an ma...l d...el t...odo..."

# game/scripts/scriptcellar.rpy:487
translate spanish cellardeath_68484cb5:

    # p "I th...nk I kn...w a sp...ll th...t w...ll tak... c...re of y...u..."
    p "C...creo q...que c...conozco u...n h...hechizo q...que s...se e...encargará d...de t...ti..."

# game/scripts/scriptcellar.rpy:489
translate spanish cellardeath_cc031a89:

    # o "What?? P-Patches I can't hear-"
    o "¿¿Qué?? P-Patches no puedo escucharte-"

# game/scripts/scriptcellar.rpy:494
translate spanish cellardeath_1b66795f:

    # n "Waves of blood are gushing from under and around the door!!"
    n "¡¡Olas de sangre brotan de debajo y alrededor de la puerta!!"

# game/scripts/scriptcellar.rpy:496
translate spanish cellardeath_00b5c33a_1:

    # o "AHHH!!"
    o "¡¡AHHH!!"

# game/scripts/scriptcellar.rpy:499
translate spanish cellardeath_fdf547f6:

    # n "They attempt to push and claw at the door but it won't budge!"
    n "Olive intenta empujar y arañar la puerta, ¡pero no cede!"

# game/scripts/scriptcellar.rpy:503
translate spanish cellardeath_e43296e2:

    # n "The waves cause Olive to slip." with vpunch
    n "Las olas hacen que Olive resbale." with vpunch

# game/scripts/scriptcellar.rpy:504
translate spanish cellardeath_8238dfbc:

    # n "They can't get close to the door without the jet of blood pushing them back!"
    n "¡No puede acercarse a la puerta sin que el chorro de sangre la empuje hacia atrás!"

# game/scripts/scriptcellar.rpy:507
translate spanish cellardeath_7909ca27:

    # n "Olive backs up against the end of the cellar."
    n "Olive retrocede hasta el final del sótano."

# game/scripts/scriptcellar.rpy:509
translate spanish cellardeath_d4cbaa6c:

    # o "P-PLEASE PATCHES!!"
    o "P-POR FAVOR PATCHES!!"

# game/scripts/scriptcellar.rpy:513
translate spanish cellardeath_2307aba7:

    # n "Olive is waist deep in blood." with vpunch
    n "Olive está hasta la cintura en sangre." with vpunch

# game/scripts/scriptcellar.rpy:515
translate spanish cellardeath_797b6eeb:

    # o "S-sparky!!"
    o "¡¡S-sparky!!"

# game/scripts/scriptcellar.rpy:519
translate spanish cellardeath_0b1e5dd7:

    # n "Olive is neck deep in blood." with vpunch
    n "Olive está hasta el cuello en sangre." with vpunch

# game/scripts/scriptcellar.rpy:521
translate spanish cellardeath_a243a2d8:

    # o "... Ginger..."
    o "... Ginger..."

# game/scripts/scriptcellar.rpy:525
translate spanish cellardeath_44ec3f24:

    # n "Olive is submerged." with vpunch
    n "Olive está sumergida." with vpunch

# game/scripts/scriptcellar.rpy:526
translate spanish cellardeath_0e05c257:

    # n "Their little lungs fill with blood."
    n "Sus pequeños pulmones se llenan de sangre."

translate spanish strings:

    # game/scripts/scriptcellar.rpy:90
    old "{color=#b290ca}Talk to Ginger.{/color}"
    new "{color=#b290ca}Hablar con Ginger.{/color}"

    # game/scripts/scriptcellar.rpy:90
    old "{color=#b290ca}Inspect jack o' lantern.{/color}"
    new "{color=#b290ca}Inspeccionar la calabaza.{/color}"

    # game/scripts/scriptcellar.rpy:90
    old "{color=#a1bd65}Leave.{/color}"
    new "{color=#a1bd65}Salir.{/color}"

    # game/scripts/scriptcellar.rpy:277
    old "Stop Sparky."
    new "Detener a Sparky."

    # game/scripts/scriptcellar.rpy:277
    old "Stand by."
    new "Apoyarlo."

