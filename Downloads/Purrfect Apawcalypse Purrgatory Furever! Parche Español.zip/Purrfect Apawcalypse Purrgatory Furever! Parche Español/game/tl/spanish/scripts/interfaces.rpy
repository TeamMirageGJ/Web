﻿# TODO: Translation updated at 2024-11-25 12:57

# game/scripts/interfaces.rpy:182
translate spanish pathunlockedsub_4ebcda40:

    # x "{w=1}{nw}"
    x "{w=1}{nw}"

# game/scripts/interfaces.rpy:188
translate spanish pathunlockedadd_4ebcda40:

    # x "{w=1}{nw}"
    x "{w=1}{nw}"

# game/scripts/interfaces.rpy:194
translate spanish pathlockedsub_4ebcda40:

    # x "{w=1}{nw}"
    x "{w=1}{nw}"

# game/scripts/interfaces.rpy:200
translate spanish pathlockedadd_4ebcda40:

    # x "{w=1}{nw}"
    x "{w=1}{nw}"

# game/scripts/interfaces.rpy:212
translate spanish chapter1_fcffba5b:

    # x "{w=3}{nw}"
    x "{w=3}{nw}"

# game/scripts/interfaces.rpy:216
translate spanish chapter1_40d3d3cd:

    # x "{w=0.5}{nw}"
    x "{w=0.5}{nw}"

# game/scripts/interfaces.rpy:223
translate spanish chapter2_fcffba5b:

    # x "{w=3}{nw}"
    x "{w=3}{nw}"

# game/scripts/interfaces.rpy:227
translate spanish chapter2_40d3d3cd:

    # x "{w=0.5}{nw}"
    x "{w=0.5}{nw}"

# game/scripts/interfaces.rpy:234
translate spanish chapter3_fcffba5b:

    # x "{w=3}{nw}"
    x "{w=3}{nw}"

# game/scripts/interfaces.rpy:238
translate spanish chapter3_40d3d3cd:

    # x "{w=0.5}{nw}"
    x "{w=0.5}{nw}"

# game/scripts/interfaces.rpy:245
translate spanish chapter4_fcffba5b:

    # x "{w=3}{nw}"
    x "{w=3}{nw}"

# game/scripts/interfaces.rpy:249
translate spanish chapter4_40d3d3cd:

    # x "{w=0.5}{nw}"
    x "{w=0.5}{nw}"

# game/scripts/interfaces.rpy:256
translate spanish chapter5_fcffba5b:

    # x "{w=3}{nw}"
    x "{w=3}{nw}"

# game/scripts/interfaces.rpy:260
translate spanish chapter5_40d3d3cd:

    # x "{w=0.5}{nw}"
    x "{w=0.5}{nw}"

