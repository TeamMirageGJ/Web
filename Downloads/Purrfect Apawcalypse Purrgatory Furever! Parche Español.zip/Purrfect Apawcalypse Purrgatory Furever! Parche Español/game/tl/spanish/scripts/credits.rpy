﻿# TODO: Translation updated at 2024-11-25 12:57

# game/scripts/credits.rpy:196
translate spanish end_credits_2a262b3b:

    # dean "{bt}{size=+24}THANK YOU SO MUCH FOR\nPLAYING THE GAME!!!{/size}{/bt}" with vpunch
    dean "{bt}{size=+24}¡¡¡MUCHAS GRACIAS POR JUGAR!!!{/size}{/bt}" with vpunch

# game/scripts/credits.rpy:199
translate spanish end_credits_a803c3c5:

    # de "My name's {a=https://linktr.ee/90percentdenny}{color=#ffcd65}Denny{/color}{/a}! I made all the art, music, writing and the easy programming for this game!"
    de "¡Me llamo {a=https://linktr.ee/90percentdenny}{color=#ffcd65}Denny{/color}{/a}! ¡Yo creé todo el arte, la música, el texto y la programación sencilla de este juego!"

# game/scripts/credits.rpy:202
translate spanish end_credits_6621c534:

    # an "I'm {a=https://twitter.com/AndySchndr}{color=#ffcd65}Andy{/color}{/a}! I help with the harder programming and super tech support for the series!"
    an "¡Y yo soy {a=https://twitter.com/AndySchndr}{color=#ffcd65}Andy{/color}{/a}! ¡Yo ayudo con la programación más compleja y brindo soporte técnico para la serie!"

# game/scripts/credits.rpy:205
translate spanish end_credits_dc333854:

    # de "If you're interested in playing the sequels head to {a=https://bit.ly/90percentsteam}{color=#ffcd65}Steam{/color}{/a}, {a=https://90percentstudios.itch.io/}{color=#ffcd65}Itch{/color}{/a}, or the {a=https://play.google.com/store/apps/dev?id=8643650060408587996}{color=#ffcd65}Google Play Store{/color}{/a}!"
    de "Si te interesa jugar las secuelas, dirígete a {a=https://bit.ly/90percentsteam}{color=#ffcd65}Steam{/color}{/a}, {a=https://90percentstudios.itch.io/}{color=#ffcd65}Itch{/color}{/a} o {a=https://play.google.com/store/apps/dev?id=8643650060408587996}{color=#ffcd65}Google Play Store{/color}{/a}."

# game/scripts/credits.rpy:208
translate spanish end_credits_10483cae:

    # an "And if you like puzzle games check out our game {a=https://www.crazygames.com/game/panel-royale}{color=#ffcd65}Panel Royale!{/color}{/a}"
    an "Y si te gustan los juegos de rompecabezas, ¡mira nuestro juego {a=https://www.crazygames.com/game/panel-royale}{color=#ffcd65}Panel Royale!{/color}{/a}"

# game/scripts/credits.rpy:211
translate spanish end_credits_989bca51:

    # de "Thanks so much for looking at the credits!"
    de "¡Muchas gracias por mirar los créditos!"

# game/scripts/credits.rpy:213
translate spanish end_credits_6d644861:

    # dean "{bt}{size=+24}HAVE A PURRFECT DAY!!!{/size}{/bt}" with vpunch
    dean "{bt}{size=+24}¡¡¡TEN UN DIA PURRFECTO!!!{/size}{/bt}" with vpunch

translate spanish strings:

    # game/scripts/credits.rpy:26
    old "Denny"
    new "Denny"

    # game/scripts/credits.rpy:27
    old "Andy"
    new "Andy"

    # game/scripts/credits.rpy:28
    old "Denny and Andy"
    new "Denny y Andy"

