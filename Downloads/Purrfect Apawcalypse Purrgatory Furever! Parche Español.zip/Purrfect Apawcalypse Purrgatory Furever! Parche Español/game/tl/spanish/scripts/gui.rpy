﻿# TODO: Translation updated at 2024-11-25 12:57

translate spanish strings:

    # game/scripts/gui.rpy:4
    old "This game will make more sense if\n\nyou've played the first game:\n\n\n\n{i}Purrfect Apawcalypse: Love at Furst Bite{/i}."
    new "Este juego tendrá más sentido si\n\nya jugaste la primera entrega:\n\n\n\n{i}Purrfect Apawcalypse: Love at Furst Bite{/i}."

    # game/scripts/gui.rpy:9
    old "Save, load and skip using the buttons\n\nat the bottom of the screen."
    new "Guarda, carga y salta usando los botones\n\nen la parte inferior de la pantalla."

    # game/scripts/gui.rpy:11
    old "This game contains depictions of cartoon violence.\n\nPlay at your own discretion."
    new "Este juego contiene representaciones de violencia animada.\n\nJuega a tu propia discreción."

