﻿# TODO: Translation updated at 2024-11-25 12:57

# game/scripts/scriptkitchen.rpy:14
translate spanish kitchenintro_7f242468:

    # n "Coco wedges a chair between the floor and the doorknob to keep it shut." with vpunch
    n "Coco coloca una silla entre el suelo y el pomo de la puerta para mantenerla cerrada." with vpunch

# game/scripts/scriptkitchen.rpy:16
translate spanish kitchenintro_1af323f7:

    # n "The zombies pounding on the door is nothing compared to Sparky. It should hold."
    n "Los zombies que golpean la puerta no son nada comparado con Sparky. Debería aguantar."

# game/scripts/scriptkitchen.rpy:18
translate spanish kitchenintro_5da393a2:

    # c "Let's find a weapon quick!"
    c "¡Busquemos un arma rápido!"

# game/scripts/scriptkitchen.rpy:47
translate spanish kitchenmenu_09701a07:

    # n "The zombies are pounding on the door, held closed only by a chair."
    n "Los zombies están golpeando la puerta, la cual sólo se mantiene cerrada gracias a una silla."

# game/scripts/scriptkitchen.rpy:49
translate spanish kitchenmenu_e5365335:

    # c "Come on Olive, we'll definitely need a weapon if we're going back out there!"
    c "¡Vamos, Olive, sin duda necesitaremos un arma para volver a salir!"

# game/scripts/scriptkitchen.rpy:70
translate spanish kitchenfridge_9ae4bdf8:

    # n "The fridge is full of milk and blood."
    n "La nevera está llena de leche y sangre."

# game/scripts/scriptkitchen.rpy:76
translate spanish kitchenfridge_1acb79e3:

    # o "I don't see Patches anywhere!"
    o "¡No veo a Patches por ningún lado!"

# game/scripts/scriptkitchen.rpy:81
translate spanish kitchenfridge_566589f1:

    # n "Ginger giggles."
    n "Ginger se ríe."

# game/scripts/scriptkitchen.rpy:83
translate spanish kitchenfridge_1630006b:

    # s "Heheheh Olive quit joking around!"
    s "Jejejeje ¡Olive deja de bromear!"

# game/scripts/scriptkitchen.rpy:86
translate spanish kitchenfridge_a1c12367:

    # o "I-I wasn't joking! I'm really trying to look for him!"
    o "¡No estaba bromeando! ¡Realmente estoy tratando de buscarlo!"

# game/scripts/scriptkitchen.rpy:95
translate spanish kitchenfridge_9ae4bdf8_1:

    # n "The fridge is full of milk and blood."
    n "La nevera está llena de leche y sangre."

# game/scripts/scriptkitchen.rpy:100
translate spanish kitchenfridge_05b377ef:

    # c "There's just milk and blood in here."
    c "Aquí sólo hay leche y sangre."

# game/scripts/scriptkitchen.rpy:102
translate spanish kitchenfridge_7ffb7340:

    # c "Wait is Patches lactose intolerant?"
    c "Espera, ¿Patches es intolerante a la lactosa?"

# game/scripts/scriptkitchen.rpy:105
translate spanish kitchenfridge_013be224:

    # o "I'm n-not sure b-but he's in Angel's body now, right?"
    o "No lo sé con s-seguridad... p-pero ahora está en el cuerpo de Angel, ¿verdad?"

# game/scripts/scriptkitchen.rpy:108
translate spanish kitchenfridge_947641bf:

    # c "OOF right. Milk is out of the question!!"
    c "¡Uf, cierto! ¡¡La leche queda totalmente descartada!!"

# game/scripts/scriptkitchen.rpy:116
translate spanish kitchenfridge_0de32d9a:

    # o "One day Sparky will have all the meat he wants!"
    o "¡Algún día Sparky tendrá toda la carne que quiera!"

# game/scripts/scriptkitchen.rpy:123
translate spanish kitchenfridge_9ae4bdf8_2:

    # n "The fridge is full of milk and blood."
    n "La nevera está llena de leche y sangre."

# game/scripts/scriptkitchen.rpy:131
translate spanish kitchenfridge_be4e38ae:

    # s "Huh?! No meat?"
    s "¡¿Eh?! ¿Sin carne?"

# game/scripts/scriptkitchen.rpy:133
translate spanish kitchenfridge_2d9d48a8:

    # s "I wanted to try some now that I'm not completely traumatized by the smell of flesh and blood."
    s "Quería probar algo ahora que no estoy completamente traumatizado por el olor a carne y sangre."

# game/scripts/scriptkitchen.rpy:138
translate spanish kitchenfridge_a4bd6fe7:

    # o "Th-there's still cake in the living room!"
    o "¡Todavía hay pastel en la sala!"

# game/scripts/scriptkitchen.rpy:142
translate spanish kitchenfridge_73e41b72:

    # s "Oh right! I guess cooked meat shaped like a cake is way better than raw meat shaped like a... Piece of raw meat."
    s "¡Ah, claro! Supongo que la carne cocida con forma de pastel es mucho mejor que la carne cruda con forma de... de carne cruda."

# game/scripts/scriptkitchen.rpy:147
translate spanish kitchenfridge_99dc2ef3:

    # n "Olive wipes their paw through the blood left in the fridge!"
    n "¡Olive se limpia la pata con la sangre que quedó en el refrigerador!"

# game/scripts/scriptkitchen.rpy:149
translate spanish kitchenfridge_a4fa297d:

    # o "The blood is s-still yummy!"
    o "¡La sangre sigue siendo deliciosa!"

# game/scripts/scriptkitchen.rpy:151
translate spanish kitchenfridge_44a7aad3:

    # n "They lick their paw."
    n "Se lame la pata."

# game/scripts/scriptkitchen.rpy:154
translate spanish kitchenfridge_93b7e6f5:

    # s "On second thought maybe I'm still a little traumatized."
    s "Pensándolo bien, tal vez todavía esté un poco traumatizado."

# game/scripts/scriptkitchen.rpy:162
translate spanish kitchenfridge_07abc845:

    # o "..."
    o "..."

# game/scripts/scriptkitchen.rpy:171
translate spanish kitchenfridge_2fe5b17d:

    # c "LET'S GO OLIVE!!"
    c "¡¡VAMOS, OLIVE!!"

# game/scripts/scriptkitchen.rpy:180
translate spanish kitchenfridge_f88b5781:

    # o "OH NOoOoOoOo!!"
    o "OH NOoOoOoOo!!"

# game/scripts/scriptkitchen.rpy:183
translate spanish kitchenfridge_1a1e8a91:

    # c "WHAT?! WHAT'S GOING ON?!"
    c "¡¿QUÉ?! ¡¿QUÉ ESTÁ SUCEDIENDO?!"

# game/scripts/scriptkitchen.rpy:186
translate spanish kitchenfridge_67ef641d:

    # o "I gave all the meat to the zombies, but what if Sparky wants to try some once he's all fixed up?"
    o "Les di toda la carne a los zombis, pero... ¿y si Sparky quiere probar un poco cuando ya esté recuperado?"

# game/scripts/scriptkitchen.rpy:190
translate spanish kitchenfridge_2c9a4926:

    # c "Then he can eat my fist because if we don't go upstairs RIGHT NOW he's going to pay for your doddling."
    c "¡Entonces se comerá mi puño! Porque si no subimos AHORA MISMO, él pagará las consecuencias de tus distracciones."

# game/scripts/scriptkitchen.rpy:193
translate spanish kitchenfridge_7e7de904:

    # o "O-okay!!"
    o "¡¡O-okay!!"

# game/scripts/scriptkitchen.rpy:205
translate spanish kitchenfridge_49d66020:

    # c "Meat. It's just meat!"
    c "Carne. ¡Es solo carne!"

# game/scripts/scriptkitchen.rpy:206
translate spanish kitchenfridge_339add90:

    # c "How the hell is this gonna help?!"
    c "¡¿Cómo diablos va a ayudar esto?!"

# game/scripts/scriptkitchen.rpy:209
translate spanish kitchenfridge_ef27967f:

    # o "I m-might have an idea!"
    o "¡Tal vez tenga una idea!"

# game/scripts/scriptkitchen.rpy:212
translate spanish kitchenfridge_68d0253b:

    # c "Really?! What is it?!"
    c "¡¿En serio?! ¡¿Cuál es?!"

# game/scripts/scriptkitchen.rpy:215
translate spanish kitchenfridge_d931fa01:

    # o "Y-you'll think it's stupid..."
    o "P-pensarás que es estúpido..."

# game/scripts/scriptkitchen.rpy:218
translate spanish kitchenfridge_5cbd1ed3:

    # c "WHAT?! This isn't the time to hold back on ideas, just tell me!!"
    c "¡¿QUÉ?! Este no es el momento de guardar ideas, ¡¡solo dilo!!"

# game/scripts/scriptkitchen.rpy:230
translate spanish kitchenfridge_7c1409e1:

    # n "The fridge is filled with raw meat, dripping with blood."
    n "La nevera está llena de carne cruda, la cual está chorreando sangre."

# game/scripts/scriptkitchen.rpy:248
translate spanish kitchenfridge_f7ee4fb7:

    # o "I-it's dripping with something."
    o "Está goteando algo."

# game/scripts/scriptkitchen.rpy:252
translate spanish kitchenfridge_bbd9b6f2:

    # s "Wh-what is it?!"
    s "¡¿Q-qué es eso?!"

# game/scripts/scriptkitchen.rpy:256
translate spanish kitchenfridge_c16aa1f7:

    # b "W-what the heck is it?!"
    b "¡¿Q-qué diablos es eso?!"

# game/scripts/scriptkitchen.rpy:261
translate spanish kitchenfridge_79d9fa7b:

    # n "Olive tentatively opens the fridge."
    n "Olive abre tentativamente la nevera."

# game/scripts/scriptkitchen.rpy:265
translate spanish kitchenfridge_38f9865d:

    # n "They're hit with the overwhelming stench of flesh and blood!"
    n "¡Un abrumador hedor a carne y sangre le golpea de frente!"

# game/scripts/scriptkitchen.rpy:267
translate spanish kitchenfridge_6310354c:

    # o "AHHH!"
    o "¡AHHH!"

# game/scripts/scriptkitchen.rpy:271
translate spanish kitchenfridge_7915ccd5:

    # b "Milk and meat. That's the diet of a killer alright."
    b "Leche y carne. Esa es la dieta de un asesino."

# game/scripts/scriptkitchen.rpy:277
translate spanish kitchenfridge_b3a7ceb9:

    # n "Sparky, able to smell the blood from across the room, looks like he's gonna be sick."
    n "Sparky, capaz de oler la sangre desde el otro lado de la habitación, parece que va a vomitar."

# game/scripts/scriptkitchen.rpy:281
translate spanish kitchenfridge_264e31f8:

    # s "Eugh I think I'm gonna be sick."
    s "Eugh, creo que voy a vomitar."

# game/scripts/scriptkitchen.rpy:284
translate spanish kitchenfridge_a2538484:

    # o "I-it smells..."
    o "Huele..."

# game/scripts/scriptkitchen.rpy:286
translate spanish kitchenfridge_8af134e9:

    # o "Delicious!!"
    o "¡¡Delicioso!!"

# game/scripts/scriptkitchen.rpy:288
translate spanish kitchenfridge_c43422f5:

    # o "A-Angel and Coco won't mind if I have a bite or two, r-right?"
    o "A A-Angel y a Coco no les importará si como un bocado o dos, ¿verdad?"

# game/scripts/scriptkitchen.rpy:292
translate spanish kitchenfridge_7ec6747c:

    # s "Hahaha wouldn't you rather save room for cake and tea?"
    s "Jajaja ¿no preferirías dejar espacio para el pastel y el té?"

# game/scripts/scriptkitchen.rpy:296
translate spanish kitchenfridge_3c4df170:

    # n "Brownie gives Olive an alarmed yet somehow nonchalant shrug."
    n "Brownie se encoge de hombros con una mezcla de alarma e indiferencia frente a Olive."

# game/scripts/scriptkitchen.rpy:299
translate spanish kitchenfridge_72449a52:

    # n "Olive picks up a chunk of meat and eats it raw."
    n "Olive toma un trozo de carne y se lo come crudo."

# game/scripts/scriptkitchen.rpy:301
translate spanish kitchenfridge_bc2c756f:

    # o "MMM! It'sh sho good!!"
    o "¡¡E-eshtá muy bueno!!"

# game/scripts/scriptkitchen.rpy:303
translate spanish kitchenfridge_4deef275:

    # n "They reach into the heaps of meat, eating ravenously."
    n "Olive mete la mano en los montones de carne y come vorazmente."

# game/scripts/scriptkitchen.rpy:307
translate spanish kitchenfridge_2a82878a:

    # n "Brownie looks at their grisly feast, entranced and tempted."
    n "Brownie mira su espantoso festín, hipnotizada y tentada."

# game/scripts/scriptkitchen.rpy:311
translate spanish kitchenfridge_3c4f8af9:

    # n "Brownie looks at their grisly feast completely entranced. Sparky backs away to keep himself out of the splash zone."
    n "Brownie mira su espantoso festín completamente hipnotizada. Sparky retrocede para no terminar salpicado."

# game/scripts/scriptkitchen.rpy:314
translate spanish kitchenfridge_3e579b82:

    # o "You guysh are really m-m-mishing out!"
    o "¡Ushtedes realmente se lo eshtán p-p-perdiendo!"

# game/scripts/scriptkitchen.rpy:316
translate spanish kitchenfridge_26e6f087:

    # o "You're really m-m-mishing out!"
    o "¡Realmente te lo estás p-p-perdiendo!"

# game/scripts/scriptkitchen.rpy:320
translate spanish kitchenfridge_27cee9a3:

    # n "Sparky looks away and wonders if he should see a therapist."
    n "Sparky mira hacia otro lado y se pregunta si debería ver a un psicólogo."

# game/scripts/scriptkitchen.rpy:324
translate spanish kitchenfridge_b66569f2:

    # n "Sparky backs away to keep himself out of the splash zone."
    n "Sparky retrocede para no terminar salpicado."

# game/scripts/scriptkitchen.rpy:326
translate spanish kitchenfridge_981fa103:

    # s "I-I just can't look at blood the same way after the whole Hachiko High incident."
    s "Simplemente no puedo ver la sangre de la misma manera después de todo el incidente del instituto Hachiko."

# game/scripts/scriptkitchen.rpy:329
translate spanish kitchenfridge_d95eabe3:

    # o "Aww Shparky that'sh sho sad!!"
    o "¡¡Aww Shparky eso es muy triste!!"

# game/scripts/scriptkitchen.rpy:330
translate spanish kitchenfridge_26e6f087_1:

    # o "You're really m-m-mishing out!"
    o "¡Realmente te lo estás p-p-perdiendo!"

# game/scripts/scriptkitchen.rpy:336
translate spanish kitchenfridge_d5668073:

    # n "Olive's paw grazes something hard and cold." with vpunch
    n "La pata de Olive roza algo duro y frío." with vpunch

# game/scripts/scriptkitchen.rpy:338
translate spanish kitchenfridge_b3c025ad:

    # o "EEP!"
    o "¡EEP!"

# game/scripts/scriptkitchen.rpy:341
translate spanish kitchenfridge_df32d9eb:

    # s "What is it?!"
    s "¡¿Qué es?!"

# game/scripts/scriptkitchen.rpy:347
translate spanish kitchenfridge_84dc3a47:

    # n "Olive holds up a key found in the meat."
    n "Olive sostiene una llave encontrada en la carne."

# game/scripts/scriptkitchen.rpy:351
translate spanish kitchenfridge_ff03c2ed:

    # b "Whoa! Good work you freak!"
    b "¡Vaya! ¡Buen trabajo, monstruo!"

# game/scripts/scriptkitchen.rpy:358
translate spanish kitchenfridge_96f3f08a:

    # s "I guess the meat wasn't a bad idea after all! Great work!"
    s "¡Supongo que la carne no fue mala idea después de todo! ¡Gran trabajo!"

# game/scripts/scriptkitchen.rpy:365
translate spanish kitchenfridge_7fdaf702:

    # o "Oh what's th-this?"
    o "Oh, ¿qué es e-esto?"

# game/scripts/scriptkitchen.rpy:370
translate spanish kitchenfridge_01dd0738:

    # n "Olive finds a key!"
    n "¡Olive encuentra una llave!"

# game/scripts/scriptkitchen.rpy:380
translate spanish kitchenfridge_bf68f427:

    # n "They lick the key clean and put it in their pocket!"
    n "¡Lame la llave y la guarda en su bolsillo!"

# game/scripts/scriptkitchen.rpy:387
translate spanish kitchenfridge_e1dd6831:

    # o "Th-there might be something spooky inside."
    o "Puede que haya algo espeluznante dentro."

# game/scripts/scriptkitchen.rpy:390
translate spanish kitchenfridge_2936d456:

    # s "Good call. It smells horrible just from out here!"
    s "Buena decisión. ¡Huele horrible sólo desde aquí!"

# game/scripts/scriptkitchen.rpy:405
translate spanish kitchenfridge_f7ee4fb7_1:

    # o "I-it's dripping with something."
    o "Está goteando algo."

# game/scripts/scriptkitchen.rpy:409
translate spanish kitchenfridge_bbd9b6f2_1:

    # s "Wh-what is it?!"
    s "¡¿Qué es eso?!"

# game/scripts/scriptkitchen.rpy:413
translate spanish kitchenfridge_c16aa1f7_1:

    # b "W-what the heck is it?!"
    b "¡¿Q-qué diablos es eso?!"

# game/scripts/scriptkitchen.rpy:417
translate spanish kitchenfridge_947af42d:

    # a "... Oh don't worry... It's just my meat!"
    a "... Oh, no te preocupes... ¡Es solo mi carne!"

# game/scripts/scriptkitchen.rpy:421
translate spanish kitchenfridge_fbdd88fc:

    # n "Angel opens the fridge revealing heaps of raw bloody meat."
    n "Angel abre el refrigerador y revela montones de carne cruda y ensangrentada."

# game/scripts/scriptkitchen.rpy:424
translate spanish kitchenfridge_d7f37fce:

    # o "OH!! It's just Angel's meat!"
    o "¡¡OH!! ¡Es sólo la carne de Angel!"

# game/scripts/scriptkitchen.rpy:428
translate spanish kitchenfridge_9711ecf6:

    # b "Can you guys please phrase it differently?"
    b "¿Podrían expresarlo de otra manera?"

# game/scripts/scriptkitchen.rpy:433
translate spanish kitchenfridge_b9de2672:

    # s "UGH th-that smell, I hate it!"
    s "¡UGH, ese olor, lo odio!"

# game/scripts/scriptkitchen.rpy:436
translate spanish kitchenfridge_c1207f40:

    # o "R-really?! B-but it's so much better than kibble!!"
    o "¡¿En serio?! ¡¡P-pero es mucho mejor que las croquetas!!"

# game/scripts/scriptkitchen.rpy:439
translate spanish kitchenfridge_78392378:

    # a "It really is... This is where cats and dogs have common ground... Please, try some!"
    a "Realmente lo es... Aquí es donde los perros y los gatos tienen puntos en común... ¡Por favor, prueba algunos!"

# game/scripts/scriptkitchen.rpy:446
translate spanish kitchenfridge_a17de124:

    # a "Please, try some!"
    a "¡Por favor, prueba algunos!"

# game/scripts/scriptkitchen.rpy:449
translate spanish kitchenfridge_7e7de904_1:

    # o "O-okay!!"
    o "¡¡O-okay!!"

# game/scripts/scriptkitchen.rpy:452
translate spanish kitchenfridge_5f603ab5:

    # n "Olive begins digging into the meat, tearing flesh from bone and slurping up the blood."
    n "Olive empieza a devorar la carne, arrancándola del hueso y bebiendo la sangre."

# game/scripts/scriptkitchen.rpy:455
translate spanish kitchenfridge_c8f55de8:

    # n "Brownie looks at the meat, entranced, but refuses to eat it."
    n "Brownie mira la carne, pero se niega a comerla."

# game/scripts/scriptkitchen.rpy:467
translate spanish kitchenfridge_924e84e1:

    # b "Oh here we go again!"
    b "¡Aquí vamos de nuevo!"

# game/scripts/scriptkitchen.rpy:470
translate spanish kitchenfridge_8f4baacb:

    # s "WHAT?! I-I'm sorry is my trauma annoying you Brownie?"
    s "¡¿QUÉ?! Lo-lo siento, ¿mi trauma te molesta, Brownie?"

# game/scripts/scriptkitchen.rpy:473
translate spanish kitchenfridge_8c592029:

    # b "Ugh NO!"
    b "¡Ugh, NO!"

# game/scripts/scriptkitchen.rpy:474
translate spanish kitchenfridge_03219f82:

    # b "I'm just being a bitch please forgive me."
    b "Sólo estoy siendo una perra, por favor perdóname."

# game/scripts/scriptkitchen.rpy:478
translate spanish kitchenfridge_d7a565c0:

    # n "Angel giggles a little..."
    n "Angel se ríe un poco..."

# game/scripts/scriptkitchen.rpy:480
translate spanish kitchenfridge_fbe17fad:

    # n "But quickly shuts himself up when he realizes no one else is laughing."
    n "Pero rápidamente se calla cuando se da cuenta de que nadie más se ríe."

# game/scripts/scriptkitchen.rpy:482
translate spanish kitchenfridge_835eef95:

    # s "I don't think your apology is genuine."
    s "No creo que tu disculpa sea genuina."

# game/scripts/scriptkitchen.rpy:485
translate spanish kitchenfridge_ca570947:

    # b "UUUUGH FINE!"
    b "¡¡UUUUUUUUUGH, ESTÁ BIEN!"

# game/scripts/scriptkitchen.rpy:487
translate spanish kitchenfridge_a5452128:

    # n "Brownie does a silly little dance while she sings."
    n "Brownie hace un pequeño baile mientras canta."

# game/scripts/scriptkitchen.rpy:490
translate spanish kitchenfridge_3f3ab4c8:

    # b "Sorry sorry sorry, I want to cheer you up but I don't know hoooooow!"
    b "Lo siento, lo siento, quiero animarte pero no sé cóoooooomo."

# game/scripts/scriptkitchen.rpy:496
translate spanish kitchenfridge_cadc650d:

    # n "Everyone including Sparky manages to laugh this time."
    n "Todos, incluido Sparky, logran reír esta vez."

# game/scripts/scriptkitchen.rpy:502
translate spanish kitchenfridge_a352f1f7:

    # a "That's too bad... I'm sorry our crimes caused you to miss out on this bounty..."
    a "Es una lástima... Lamento que nuestros crímenes hicieran que te perdieras este festín..."

# game/scripts/scriptkitchen.rpy:506
translate spanish kitchenfridge_48efc50d:

    # o "Whoa look!!"
    o "¡¡Vaya mira!!"

# game/scripts/scriptkitchen.rpy:511
translate spanish kitchenfridge_84dc3a47_1:

    # n "Olive holds up a key found in the meat."
    n "Olive sostiene una llave encontrada en la carne."

# game/scripts/scriptkitchen.rpy:514
translate spanish kitchenfridge_92fcb47c:

    # a "... It's one of Coco's keys! She's always hiding those around the house..."
    a "... ¡Es una de las llaves de Coco! Siempre las anda escondiendo por toda la casa..."

# game/scripts/scriptkitchen.rpy:516
translate spanish kitchenfridge_db70f34b:

    # a "Let's hold onto it for now!"
    a "¡Guardémosla por ahora!"

# game/scripts/scriptkitchen.rpy:525
translate spanish kitchenfridge_69dfbf86:

    # a "... It's one of Coco's keys!"
    a "... ¡Es una de las llaves de Coco!"

# game/scripts/scriptkitchen.rpy:529
translate spanish kitchenfridge_96f3f08a_1:

    # s "I guess the meat wasn't a bad idea after all! Great work!"
    s "¡Supongo que la carne no fue mala idea después de todo! ¡Gran trabajo!"

# game/scripts/scriptkitchen.rpy:535
translate spanish kitchenfridge_24477a21:

    # a "That's three keys... Let's hurry up and get to Coco's room!"
    a "Son tres llaves... ¡Démonos prisa y lleguemos a la habitación de Coco!"

# game/scripts/scriptkitchen.rpy:549
translate spanish kitchenknife_23743d9e:

    # o "All the knives are missing!"
    o "¡Faltan todos los cuchillos!"

# game/scripts/scriptkitchen.rpy:555
translate spanish kitchenknife_75919a3b:

    # c "We'll think of something else."
    c "Ya se nos ocurrirá algo más."

# game/scripts/scriptkitchen.rpy:558
translate spanish kitchenknife_fba1e248:

    # o "Yeah!! J-just like last time!"
    o "¡¡Sí!! ¡J-justo como la última vez!"

# game/scripts/scriptkitchen.rpy:561
translate spanish kitchenknife_eebc953c:

    # c "This time let's use something a little more straightforward than a tray of raw meat."
    c "Esta vez usemos algo un poco más sencillo que una bandeja de carne cruda."

# game/scripts/scriptkitchen.rpy:565
translate spanish kitchenknife_449a0c92:

    # s "That CAN'T be good."
    s "Eso NO PUEDE ser bueno."

# game/scripts/scriptkitchen.rpy:573
translate spanish kitchenknife_b1c40f72:

    # o "Knives should be f-for making snacks and that's all."
    o "Los cuchillos deberían ser para hacer bocadillos y eso es todo."

# game/scripts/scriptkitchen.rpy:579
translate spanish kitchenknife_7b43472d:

    # c "Olive do you want our friends to die or something?"
    c "Olive, ¿quieres que nuestros amigos mueran o algo así?"

# game/scripts/scriptkitchen.rpy:581
translate spanish kitchenknife_c193f5fe:

    # c "LET'S GO!!"
    c "¡¡VAMOS!!"

# game/scripts/scriptkitchen.rpy:588
translate spanish kitchenknife_d1bcec7a:

    # o "All the knives are safe and sound in their knife block!"
    o "¡Todos los cuchillos están sanos y salvos en su taco!"

# game/scripts/scriptkitchen.rpy:593
translate spanish kitchenknife_b3335b9a:

    # o "The knives aren't home r-right now."
    o "Los cuchillos no están en casa ahora mismo."

# game/scripts/scriptkitchen.rpy:600
translate spanish kitchenknife_e2f6a587:

    # c "Where did all the knives go?!"
    c "¿A dónde fueron todos los cuchillos?"

# game/scripts/scriptkitchen.rpy:601
translate spanish kitchenknife_7283c888:

    # c "This would've been so perfect! Just a few stabs and-"
    c "¡Hubiera sido tan perfecto! Sólo unas puñaladas y-"

# game/scripts/scriptkitchen.rpy:604
translate spanish kitchenknife_f070e903:

    # n "Olive grumbles."
    n "Olive refunfuña."

# game/scripts/scriptkitchen.rpy:606
translate spanish kitchenknife_a4bf34d2:

    # c "AAAND Sparky would be incapacitated! Because we'll use the knife, to uhh, cut his tendons!"
    c "¡YYYY Sparky quedaría incapacitado! ¡Porque usaremos el cuchillo para, emm, cortarle los tendones!"

# game/scripts/scriptkitchen.rpy:609
translate spanish kitchenknife_70c55050:

    # o "But I l-love Sparky's tendons!!"
    o "¡¡Pero a-amo los tendones de Sparky!!"

# game/scripts/scriptkitchen.rpy:612
translate spanish kitchenknife_9b9ab1ee:

    # c "Ugh..."
    c "Ugh..."

# game/scripts/scriptkitchen.rpy:614
translate spanish kitchenknife_d19f855d:

    # c "..."
    c "..."

# game/scripts/scriptkitchen.rpy:616
translate spanish kitchenknife_87426d10:

    # c "I'm sorry... For getting you all involved."
    c "Lo siento... por involucrarlos a todos en esto."

# game/scripts/scriptkitchen.rpy:623
translate spanish kitchenknife_fc6e36bd:

    # o "Aww Coco it's not your fault!"
    o "¡Aww Coco, no es tu culpa!"

# game/scripts/scriptkitchen.rpy:625
translate spanish kitchenknife_ac0ec63c:

    # o "I j-just hope we don't have to hurt anyone..."
    o "Sólo espero que no tengamos que lastimar a nadie más..."

# game/scripts/scriptkitchen.rpy:628
translate spanish kitchenknife_3ee99f0a:

    # c "Me too honestly..."
    c "Yo también sinceramente..."

# game/scripts/scriptkitchen.rpy:632
translate spanish kitchenknife_48ca7001:

    # n "Olive looks sad."
    n "Olive parece triste."

# game/scripts/scriptkitchen.rpy:639
translate spanish kitchenpotsandpans_88711ced:

    # n "A cast iron pot and pan hang on the wall. They look very heavy."
    n "Una olla y una sartén de hierro cuelgan de la pared. Se ven muy pesados."

# game/scripts/scriptkitchen.rpy:645
translate spanish kitchenpotsandpans_ba837c76:

    # g "Sometimes I imagine Patches and I cooking dinner together."
    g "A veces me imagino a Patches y a mí cocinando la cena juntos."

# game/scripts/scriptkitchen.rpy:648
translate spanish kitchenpotsandpans_c21de523:

    # o "WOW!! That's so romantic!! Do you like cooking?"
    o "¡¡GUAU!! ¡¡Eso es tan romántico!! ¿Te gusta cocinar?"

# game/scripts/scriptkitchen.rpy:651
translate spanish kitchenpotsandpans_07dbf09e:

    # g "Yes!"
    g "¡Sí!"

# game/scripts/scriptkitchen.rpy:654
translate spanish kitchenpotsandpans_1d15e7f5:

    # s "I guess you haven't eaten anything for a while huh?"
    s "Supongo que hace tiempo que no comes nada, ¿eh?"

# game/scripts/scriptkitchen.rpy:657
translate spanish kitchenpotsandpans_f002bdfe:

    # g "Ahh, well I don't really cook to eat. I just like making things and sharing them with people..."
    g "Ahh, bueno, realmente no cocino para comer. Simplemente me gusta hacer cosas y compartirlas con la gente..."

# game/scripts/scriptkitchen.rpy:660
translate spanish kitchenpotsandpans_79768adb:

    # o "DAAAAW!!"
    o "¡¡DAAAAW!!"

# game/scripts/scriptkitchen.rpy:662
translate spanish kitchenpotsandpans_34974ec1:

    # n "Olive tries to hug Ginger but just kind of phases through her body."
    n "Olive intenta abrazar a Ginger, pero simplemente traspasa su cuerpo."

# game/scripts/scriptkitchen.rpy:666
translate spanish kitchenpotsandpans_d635df7c:

    # n "She appreciates the attempt."
    n "Ella agradece el intento."

# game/scripts/scriptkitchen.rpy:672
translate spanish kitchenpotsandpans_88711ced_1:

    # n "A cast iron pot and pan hang on the wall. They look very heavy."
    n "Una olla y una sartén de hierro cuelgan de la pared. Se ven muy pesados."

# game/scripts/scriptkitchen.rpy:676
translate spanish kitchenpotsandpans_81e44af9:

    # c "These are perfect!"
    c "¡Estos son perfectos!"

# game/scripts/scriptkitchen.rpy:679
translate spanish kitchenpotsandpans_51c8d85d:

    # n "Coco hands a pot to Olive!"
    n "¡Coco le entrega una olla a Olive!"

# game/scripts/scriptkitchen.rpy:682
translate spanish kitchenpotsandpans_98059415:

    # n "She takes a pan for herself and does a few practice swings."
    n "Toma una sartén y practica algunos movimientos."

# game/scripts/scriptkitchen.rpy:685
translate spanish kitchenpotsandpans_0b7db9e4:

    # n "Olive follows suit. They can hardly lift it over their head."
    n "Olive hace lo mismo. Apenas puede levantarla por encima de su cabeza."

# game/scripts/scriptkitchen.rpy:687
translate spanish kitchenpotsandpans_99a40db5:

    # c "WHAT?! You're a dog!! How are you so weak?!"
    c "¡¿QUÉ?! ¡Eres un perro!! ¡¿Cómo eres tan débil?!"

# game/scripts/scriptkitchen.rpy:690
translate spanish kitchenpotsandpans_c50ada38:

    # o "I-I just kind of nap all day when I'm not at school."
    o "S-simplemente tomo una siesta larga cuando no estoy en la escuela."

# game/scripts/scriptkitchen.rpy:693
translate spanish kitchenpotsandpans_2572c833:

    # c "I guess that's relateable."
    c "Supongo que te entiendo."

# game/scripts/scriptkitchen.rpy:694
translate spanish kitchenpotsandpans_4864be68:

    # c "We'll have to find you something else."
    c "Tendremos que encontrarte algo más."

# game/scripts/scriptkitchen.rpy:698
translate spanish kitchenpotsandpans_c42e6102:

    # n "Coco picks up the cast iron pan!"
    n "¡Coco toma la sartén de hierro!"

# game/scripts/scriptkitchen.rpy:700
translate spanish kitchenpotsandpans_a19078b5:

    # c "All set! Let's go!"
    c "¡Listo! ¡Vamos!"

# game/scripts/scriptkitchen.rpy:707
translate spanish kitchenpotsandpans_2200ebc4:

    # s "These would've done well against the zombies."
    s "Estos hubieran funcionado bien contra los zombies."

# game/scripts/scriptkitchen.rpy:713
translate spanish kitchenpotsandpans_0a337aae:

    # z "HHhHhHhHh..."
    z "HHhHhHhHh..."

# game/scripts/scriptkitchen.rpy:716
translate spanish kitchenpotsandpans_7d8234d4:

    # s "Th-thank Dog we didn't have to use them!"
    s "¡Gracias a dios que no tuvimos que usarlos!"

# game/scripts/scriptkitchen.rpy:726
translate spanish kitchenpotsandpans_142c49ae:

    # n "A cast iron pot and pan hang on the wall. Coco admires them silently."
    n "Una olla y una sartén de hierro cuelgan de la pared. Coco los admira en silencio."

# game/scripts/scriptkitchen.rpy:733
translate spanish kitchenpotsandpans_3ddcda4e:

    # c "OLIVE! WE NEED TO GO!!"
    c "¡OLIVE! ¡¡TENEMOS QUE IRNOS!!"

# game/scripts/scriptkitchen.rpy:736
translate spanish kitchenpotsandpans_bb39b37f:

    # o "S-sorry, I was j-just admiring them!"
    o "¡Lo siento, solo estaba admirándolas!"

# game/scripts/scriptkitchen.rpy:740
translate spanish kitchenpotsandpans_527c8404:

    # c "Oh yeah, I guess they are pretty great."
    c "Oh, sí, supongo que son bastante geniales."

# game/scripts/scriptkitchen.rpy:741
translate spanish kitchenpotsandpans_708ef21a:

    # c "They're cast iron, and by cast iron I mean I cast an iron spell on them!"
   c "Son de hierro fundido, ¡y con fundido me refiero a que les fundí un hechizo encima!"

# game/scripts/scriptkitchen.rpy:742
translate spanish kitchenpotsandpans_df661a15:

    # c "It helps it retain its shape under extreme heat and pressure and it's even a little poisonous!"
    c "¡Eso ayuda a que conserven su forma bajo presión y calor extremos, y hasta las hace un poco venenosas!"

# game/scripts/scriptkitchen.rpy:743
translate spanish kitchenpotsandpans_c7fc9926:

    # c "That coupled with brewing poisons just adds to the deadliness!"
    c "¡Eso, sumado a que preparo venenos en ellas, las hace el doble de letales!"

# game/scripts/scriptkitchen.rpy:746
translate spanish kitchenpotsandpans_0bb737ab:

    # c "WAIT WAIT STOP DISTRACTING ME!! We need to go!"
    c "¡¡ESPERA, ESPERA, DEJA DE DISTRAERME!! ¡Tenemos que irnos!"

# game/scripts/scriptkitchen.rpy:753
translate spanish kitchenpotsandpans_d4e0f2e5:

    # o "I wonder what Coco and Angel l-like to cook!"
    o "¡Me pregunto qué les gusta cocinar a Coco y Angel!"

# game/scripts/scriptkitchen.rpy:756
translate spanish kitchenpotsandpans_2933a19f:

    # o "I wonder why Coco and Angel have pots and pans when raw meat is so much yummier!"
    o "¡Me pregunto por qué Coco y Angel tienen ollas y sartenes cuando la carne cruda es mucho más deliciosa!"

# game/scripts/scriptkitchen.rpy:760
translate spanish kitchenpotsandpans_d8d2401a:

    # s "Raw meat can make some dogs pretty sick. Better not risk it."
    s "La carne cruda puede enfermar bastante a algunos perros. Mejor no arriesgarse."

# game/scripts/scriptkitchen.rpy:766
translate spanish kitchenpotsandpans_88711ced_2:

    # n "A cast iron pot and pan hang on the wall. They look very heavy."
    n "Una olla y una sartén de hierro cuelgan de la pared. Se ven muy pesados."

# game/scripts/scriptkitchen.rpy:771
translate spanish kitchenpotsandpans_e94aeebd:

    # o "Angel! D-do you cook?!"
    o "¡Angel! ¡¿Tú cocinas?!"

# game/scripts/scriptkitchen.rpy:774
translate spanish kitchenpotsandpans_c5e74848:

    # a "Not really... Those are just for brewing potions and ingredients for magical spells..."
    a "En realidad no... Esos son sólo para preparar pociones e ingredientes para hechizos mágicos..."

# game/scripts/scriptkitchen.rpy:781
translate spanish kitchenpotsandpans_044f0ee4:

    # a "So they're often coated in poisonous residues..."
    a "Así que a menudo están cubiertos de residuos venenosos..."

# game/scripts/scriptkitchen.rpy:783
translate spanish kitchenpotsandpans_6aa961f9:

    # n "Olive, just about to lift one off its hook shrinks back."
    n "Olive, justo cuando iba a descolgar una del gancho, retrocede del susto."

# game/scripts/scriptkitchen.rpy:794
translate spanish kitchenpotsandpans_888c643e:

    # c "These are purr-"
    c "Estos son purf-"

# game/scripts/scriptkitchen.rpy:796
translate spanish kitchenpotsandpans_62c763ba:

    # c "I mean perfect!"
    c "¡Quiero decir perfectos!"

# game/scripts/scriptkitchen.rpy:799
translate spanish kitchenpotsandpans_f36587ec:

    # o "Yeah! We can knock Sparky out and no one has to die!!"
    o "¡Sí! ¡Podemos noquear a Sparky y nadie tendrá que morir!"

# game/scripts/scriptkitchen.rpy:802
translate spanish kitchenpotsandpans_37a379cb:

    # c "Then it's settled. Take these to Brownie and Angel!"
    c "Entonces está decidido. ¡Llévaselos a Brownie y Angel!"

# game/scripts/scriptkitchen.rpy:805
translate spanish kitchenpotsandpans_7fe0c888:

    # o "Oka-"
    o "Oka-"

# game/scripts/scriptkitchen.rpy:808
translate spanish kitchenpotsandpans_f75fa713:

    # o "Wait. What about y-y-you?!"
    o "Espera. ¡¿Qué hay de t-ti?!"

# game/scripts/scriptkitchen.rpy:811
translate spanish kitchenpotsandpans_a470f2d4:

    # c "You saw all those zombies! We need a distraction to draw them out of the house and into the yard!"
    c "¡Viste todos esos zombies! ¡Necesitamos una distracción para sacarlos de la casa y llevarlos al patio!"

# game/scripts/scriptkitchen.rpy:814
translate spanish kitchenpotsandpans_2169ba55:

    # c "I'll go through the window here and..."
    c "Pasaré por la ventana de aquí y..."

# game/scripts/scriptkitchen.rpy:818
translate spanish kitchenpotsandpans_5d46d7aa:

    # c "OH I'll use that meat you're so crazy about as a distraction!"
    c "¡OH, usaré esa carne que te vuelve tan loco como distracción!"

# game/scripts/scriptkitchen.rpy:820
translate spanish kitchenpotsandpans_29e1a5ff:

    # c "OH I'll use Angel's meat as a distraction!"
    c "¡OH, usaré la carne de Angel como distracción!"

# game/scripts/scriptkitchen.rpy:822
translate spanish kitchenpotsandpans_e65a8c49:

    # c "Then when they come out I'll climb up a tree!"
    c "Luego, cuando salgan, ¡me subiré a un árbol!"

# game/scripts/scriptkitchen.rpy:825
translate spanish kitchenpotsandpans_d7318f81:

    # c "You and the others will just have to help me down after, which shouldn't be a problem."
    c "Tú y los demás tendrán que ayudarme a bajar después, lo cual no debería ser un problema."

# game/scripts/scriptkitchen.rpy:827
translate spanish kitchenpotsandpans_10dc4348:

    # c "By then you'll have knocked Sparky and Patches out and gotten my wand back!"
    c "¡Para entonces habrás noqueado a Sparky y Patches y habrás recuperado mi varita!"

# game/scripts/scriptkitchen.rpy:830
translate spanish kitchenpotsandpans_07abc845:

    # o "..."
    o "..."

# game/scripts/scriptkitchen.rpy:842
translate spanish kitchenpotsandpans_e7ed6018:

    # o "That sounds purrfect!!"
    o "¡¡Eso suena purfecto!!"

# game/scripts/scriptkitchen.rpy:844
translate spanish kitchenpotsandpans_9a57bd8d:

    # o "You're so smart Coco!"
    o "¡Eres tan inteligente Coco!"

# game/scripts/scriptkitchen.rpy:847
translate spanish kitchenpotsandpans_83f5c201:

    # c "I know I know."
    c "Lo sé, lo sé."

# game/scripts/scriptkitchen.rpy:850
translate spanish kitchenpotsandpans_3b250576:

    # c "Alright no time to spare!"
    c "¡Muy bien, no hay tiempo que perder!"

# game/scripts/scriptkitchen.rpy:853
translate spanish kitchenpotsandpans_3f02157a:

    # n "Coco grabs a tray and fills it with meat."
    n "Coco agarra una bandeja y la llena de carne."

# game/scripts/scriptkitchen.rpy:855
translate spanish kitchenpotsandpans_3ccf3130:

    # n "She pops open the window. The coast is clear."
    n "Ella abre la ventana. El patio está despejado."

# game/scripts/scriptkitchen.rpy:857
translate spanish kitchenpotsandpans_b7e0e521:

    # o "Bye Coco, when you come back we sh-"
    o "Adiós Coco, cuando vuelvas-"

# game/scripts/scriptkitchen.rpy:860
translate spanish kitchenpotsandpans_c6493fd3:

    # c "DON'T say that stuff, you'll jynx everything!"
    c "¡No digas cosas, lo arruinarás todo!"

# game/scripts/scriptkitchen.rpy:863
translate spanish kitchenpotsandpans_719f3d3a:

    # o "Oh r-r-right!!"
    o "¡¡Oh c-c-cierto!!"

# game/scripts/scriptkitchen.rpy:866
translate spanish kitchenpotsandpans_a8c4cd04:

    # c "Bye!"
    c "¡Adiós!"

# game/scripts/scriptkitchen.rpy:872
translate spanish kitchenpotsandpans_4199b128:

    # o "D-do you really have that much f-faith in us?"
    o "¿De verdad tienes tanta f-fe en nosotros?"

# game/scripts/scriptkitchen.rpy:881
translate spanish kitchenpotsandpans_45b71e9e:

    # c "OLIVE. I AM TRYING TO BE OPTIMISTIC."
    c "OLIVE. ESTOY INTENTANDO SER OPTIMISTA."

# game/scripts/scriptkitchen.rpy:884
translate spanish kitchenpotsandpans_c384e4f0:

    # o "Heh heh."
    o "Je je."

# game/scripts/scriptkitchen.rpy:887
translate spanish kitchenpotsandpans_3b250576_1:

    # c "Alright no time to spare!"
    c "¡Muy bien, no hay tiempo que perder!"

# game/scripts/scriptkitchen.rpy:894
translate spanish kitchenpotsandpans_e41e4108:

    # o "P-please isn't there something else we can do?"
    o "P-por favor, ¿no hay algo más que podamos hacer?"

# game/scripts/scriptkitchen.rpy:897
translate spanish kitchenpotsandpans_5335b629:

    # c "Aww it's nice that you're worried about me."
    c "Aww, es bueno que te preocupes por mí."

# game/scripts/scriptkitchen.rpy:899
translate spanish kitchenpotsandpans_b5938f57:

    # c "But this is MY FAULT."
    c "Pero esto es MI CULPA."

# game/scripts/scriptkitchen.rpy:900
translate spanish kitchenpotsandpans_04d291f3:

    # c "I'm going to be the one to fix it. You're going to help, right?"
    c "Voy a ser yo quien lo arregle. Vas a ayudar, ¿verdad?"

# game/scripts/scriptkitchen.rpy:903
translate spanish kitchenpotsandpans_dea129ab:

    # o "Of c-course!!"
    o "¡¡Por s-supuesto!!"

# game/scripts/scriptkitchen.rpy:906
translate spanish kitchenpotsandpans_1ed38174:

    # c "Then see ya!"
    c "¡Entonces nos vemos!"

# game/scripts/scriptkitchen.rpy:913
translate spanish kitchenpotsandpans_10d38a54:

    # n "Coco hops out of the window with all the meat."
    n "Coco salta por la ventana con toda la carne."

# game/scripts/scriptkitchen.rpy:915
translate spanish kitchenpotsandpans_07abc845_1:

    # o "..."
    o "..."

# game/scripts/scriptkitchen.rpy:919
translate spanish kitchenpotsandpans_be11b766:

    # n "Olive takes the heavy pot and pan."
    n "Olive toma la pesada olla y la sartén."

# game/scripts/scriptkitchen.rpy:921
translate spanish kitchenpotsandpans_7c3959fb:

    # n "Olive takes the heavy pot and pan, careful not to touch the metal in case they really are coated in poisonous residue."
    n "Olive toma la pesada olla y la sartén, con cuidado de no tocar el metal por si realmente están cubiertos de residuos venenosos."

# game/scripts/scriptkitchen.rpy:922
translate spanish kitchenpotsandpans_0ee32ecd:

    # n "They can hardly carry them!"
    n "¡Difícilmente puede cargarlos!"

# game/scripts/scriptkitchen.rpy:931
translate spanish kitchensparky_1c30d942:

    # n "Sparky stands quietly in the corner of the kitchen."
    n "Sparky permanece en silencio en un rincón de la cocina."

# game/scripts/scriptkitchen.rpy:936
translate spanish kitchensparky_3e246313:

    # o "I-I'm going to talk to him alone if that's okay."
    o "Voy a hablar con él a solas si te parece bien."

# game/scripts/scriptkitchen.rpy:940
translate spanish kitchensparky_b515871a:

    # b "Okay, I got your back!"
    b "¡Está bien, te cubro!"

# game/scripts/scriptkitchen.rpy:944
translate spanish kitchensparky_5dbcba6a:

    # a "Be careful..."
    a "Ten cuidado..."

# game/scripts/scriptkitchen.rpy:955
translate spanish kitchensparky_59bd6dd1:

    # n "Olive slowly walks up to Sparky."
    n "Olive camina lentamente hacia Sparky."

# game/scripts/scriptkitchen.rpy:957
translate spanish kitchensparky_90c4ab6a:

    # o "Sparky?"
    o "¿Sparky?"

# game/scripts/scriptkitchen.rpy:960
translate spanish kitchensparky_5896ac34:

    # s "I can hear everything you're saying about me. I know you hate me."
    s "Puedo oír todo lo que dices sobre mí. Sé que me odias."

# game/scripts/scriptkitchen.rpy:965
translate spanish kitchensparky_6e20cfd2:

    # o "Th-th-the only thing I've been saying behind your back is..."
    o "Lo único que he estado diciendo a tus espaldas es..."

# game/scripts/scriptkitchen.rpy:966
translate spanish kitchensparky_a19ad9f4:

    # o "Nice tail."
    o "Bonita cola."

# game/scripts/scriptkitchen.rpy:969
translate spanish kitchensparky_43e105d1:

    # s "HUH?!"
    s "¡¿EH?!"

# game/scripts/scriptkitchen.rpy:972
translate spanish kitchensparky_b526899b:

    # s "AHAHAH that's actually a pretty good line."
    s "AHAHAH, esa es realmente una broma bastante buena."

# game/scripts/scriptkitchen.rpy:973
translate spanish kitchensparky_39d261f0:

    # s "Did you learn it from Brownie?"
    s "¿Lo aprendiste de Brownie?"

# game/scripts/scriptkitchen.rpy:976
translate spanish kitchensparky_b006deb9:

    # o "I'm m-most creative when I'm afraid!"
    o "¡Soy más creativa cuando tengo miedo!"

# game/scripts/scriptkitchen.rpy:979
translate spanish kitchensparky_181b30d9:

    # s "Ahh, I am pretty scary right now huh?"
    s "Ahh... doy bastante miedo ahora mismo, ¿no?"

# game/scripts/scriptkitchen.rpy:980
translate spanish kitchensparky_fc51f34c:

    # s "It feels like a voice in my head is trying to get me to turn on you guys."
    s "Se siente como si una voz en mi cabeza estuviera tratando de hacer que me vuelva en contra de ustedes."

# game/scripts/scriptkitchen.rpy:983
translate spanish kitchensparky_91821757:

    # o "Eh?! N-no! I haven't said anything about you!"
    o "¡¿Eh?! ¡N-no! ¡No he dicho nada sobre ti!"

# game/scripts/scriptkitchen.rpy:986
translate spanish kitchensparky_9ac41e40:

    # s "Really?!"
    s "¡¿De verdad?!"

# game/scripts/scriptkitchen.rpy:988
translate spanish kitchensparky_afdf4bf2:

    # s "Oh my Dog I really am going insane."
    s "Por todos los perros, realmente me estoy volviendo loco."

# game/scripts/scriptkitchen.rpy:991
translate spanish kitchensparky_f99ea018:

    # o "M-maybe a nap would help!"
    o "¡Tal vez una siesta ayudaría!"

# game/scripts/scriptkitchen.rpy:994
translate spanish kitchensparky_df6397a1:

    # s "No! I already told you, things get bad when I fall asleep."
    s "¡No! Ya te lo dije, la cosa se pone mal cuando me quedo dormido."

# game/scripts/scriptkitchen.rpy:996
translate spanish kitchensparky_6d31c118:

    # s "I'm starting to think that my behaviour and these zombies... They can't be a coincidence!"
    s "Estoy empezando a pensar que mi comportamiento y estos zombies... ¡No pueden ser una coincidencia!"

# game/scripts/scriptkitchen.rpy:1000
translate spanish kitchensparky_209abc52:

    # n "Sparky desperately grabs onto Olive's shoulders. They manage to remain calm." with vpunch
    n "Sparky se agarra desesperadamente a los hombros de Olive." with vpunch

# game/scripts/scriptkitchen.rpy:1002
translate spanish kitchensparky_5c7f2feb:

    # n "Sparky desperately grabs onto Olive's shoulders. Angel tenses up as he watches from afar." with vpunch
    n "Sparky se agarra desesperadamente a los hombros de Olive. Angel se tensa mientras observa desde lejos." with vpunch

# game/scripts/scriptkitchen.rpy:1004
translate spanish kitchensparky_025eb898:

    # n "Sparky desperately grabs onto Olive's shoulders. Brownie tenses up as she watches from afar." with vpunch
    n "Sparky se agarra desesperadamente a los hombros de Olive. Brownie se tensa mientras observa desde lejos." with vpunch

# game/scripts/scriptkitchen.rpy:1006
translate spanish kitchensparky_ccf4976e:

    # n "Sparky desperately grabs onto Olive's shoulders. Brownie and Angel tense up as they watch from afar." with vpunch
    n "Sparky se agarra desesperadamente a los hombros de Olive. Brownie y Angel se tensan mientras observan desde lejos." with vpunch

# game/scripts/scriptkitchen.rpy:1008
translate spanish kitchensparky_d5e48983:

    # s "Y-you have to believe me, I don't want to hurt any of you!"
    s "¡T-Tienes que creerme, no quiero lastimar a ninguno de ustedes!"

# game/scripts/scriptkitchen.rpy:1011
translate spanish kitchensparky_e59072eb:

    # o "I know!! I trust you Sparky, you're s-super handsome and cool and tall and a r-really good boy!"
    o "¡¡Lo sé!! Confío en ti Sparky, eres súper guapo, genial, alto y ¡muy buen chico!"

# game/scripts/scriptkitchen.rpy:1014
translate spanish kitchensparky_2072a691:

    # s "Pfft you think that about everyone Olive!"
    s "¡Pfft piensas eso de todos, Olive!"

# game/scripts/scriptkitchen.rpy:1017
translate spanish kitchensparky_035a5100:

    # n "Olive gives Sparky a soft and totally not surprising hug!"
    n "¡Olive le da a Sparky un suave y nada sorprendente abrazo!"

# game/scripts/scriptkitchen.rpy:1020
translate spanish kitchensparky_d3ca95cf:

    # o "I'll take you t-to Coco! I bet she can help get rid of whatever's haunting you!"
    o "¡Te llevaré c-con Coco! ¡Apuesto a que ella puede ayudarte a deshacerte de lo que sea que te atormenta!"

# game/scripts/scriptkitchen.rpy:1022
translate spanish kitchensparky_2193631a:

    # o "We'll take you t-to Coco! I bet she can help get rid of whatever's haunting you!"
    o "¡Te llevaremos c-con Coco! ¡Apuesto a que ella puede ayudarte a deshacerte de lo que sea que te atormenta!"

# game/scripts/scriptkitchen.rpy:1025
translate spanish kitchensparky_d54c61f6:

    # s "I hope so..."
    s "Eso espero..."

# game/scripts/scriptkitchen.rpy:1045
translate spanish kitchensparky_99ac9f87:

    # o "I'd better leave him alone..."
    o "Será mejor que lo deje en paz..."

# game/scripts/scriptkitchen.rpy:1051
translate spanish kitchensparky_ed2b15c6:

    # o "We'd better leave him alone..."
    o "Será mejor que lo dejemos en paz..."

# game/scripts/scriptkitchen.rpy:1073
translate spanish kitchensparky_79f98c68:

    # o "SPARKY!!"
    o "¡¡SPARKY!!"

# game/scripts/scriptkitchen.rpy:1076
translate spanish kitchensparky_ac63aee7:

    # n "Olive jumps onto Sparky giving him a big hug!" with vpunch
    n "¡Olive salta sobre Sparky y le da un gran abrazo!" with vpunch

# game/scripts/scriptkitchen.rpy:1079
translate spanish kitchensparky_81461070:

    # b "W-wait Olly!"
    b "¡E-Espera, Olly!"

# game/scripts/scriptkitchen.rpy:1086
translate spanish kitchensparky_369e0b17:

    # n "Sparky flinches and pushes Olive away!" with vpunch
    n "¡Sparky se estremece y empuja a Olive!" with vpunch

# game/scripts/scriptkitchen.rpy:1089
translate spanish kitchensparky_b287c54f:

    # a "Olive! Are you okay...?"
    a "¡Olive! ¿Estás bien...?"

# game/scripts/scriptkitchen.rpy:1092
translate spanish kitchensparky_976183e0:

    # s "AGH!"
    s "¡AGH!"

# game/scripts/scriptkitchen.rpy:1093
translate spanish kitchensparky_818711dd:

    # s "S-sorry Olive! You caught me off guard!"
    s "¡Lo siento, Olive! ¡Me pillaste con la guardia baja!"

# game/scripts/scriptkitchen.rpy:1096
translate spanish kitchensparky_01f2349c:

    # o "Oh i-it's okay!! Sorry for jumping on you!"
    o "¡¡Oh, está bien!! ¡Perdón por saltar sobre ti!"

# game/scripts/scriptkitchen.rpy:1103
translate spanish kitchensparky_1e238a8d:

    # s "No it's totally fine!"
    s "¡No, está totalmente bien!"

# game/scripts/scriptkitchen.rpy:1106
translate spanish kitchensparky_7bf73af3:

    # n "Sparky pulls Olive into a far more subdued hug."
    n "Sparky le da a Olive un abrazo mucho más moderado."

# game/scripts/scriptkitchen.rpy:1109
translate spanish kitchensparky_74e17924:

    # n "They sink into it relieved."
    n "Se relaja en el abrazo con alivio."

# game/scripts/scriptkitchen.rpy:1111
translate spanish kitchensparky_0a7e9348:

    # s "Brownie and I got here a while ago. Are the zombies still out there?"
    s "Brownie y yo llegamos aquí hace un tiempo. ¿Siguen los zombies?"

# game/scripts/scriptkitchen.rpy:1114
translate spanish kitchensparky_7516ae00:

    # o "Yeah! There's like a th-thousand of them!"
    o "¡Sí! ¡Hay como mil de ellos!"

# game/scripts/scriptkitchen.rpy:1118
translate spanish kitchensparky_ed352691:

    # n "Brownie seems relieved."
    n "Brownie parece aliviada."

# game/scripts/scriptkitchen.rpy:1123
translate spanish kitchensparky_783c4514:

    # s "I'm happy to see you're alright! And you've started gathering everyone together!"
    s "¡Me alegra ver que estás bien! ¡Y has empezado a reunir a todos!"

# game/scripts/scriptkitchen.rpy:1125
translate spanish kitchensparky_2605666a:

    # s "Does this mean Coco is just about finished?"
    s "¿Significa esto que Coco está a punto de terminar?"

# game/scripts/scriptkitchen.rpy:1129
translate spanish kitchensparky_f12ff5c0:

    # a "No... She said she'd come find me as soon as she was..."
    a "No... Ella dijo que vendría a buscarme tan pronto como estuviera libre..."

# game/scripts/scriptkitchen.rpy:1133
translate spanish kitchensparky_c255f657:

    # b "Noooooo she's still up in her room trying to figure out how to kill a thousand zombos."
    b "Nooooo, ella todavía está en su habitación tratando de descubrir cómo matar mil zombis."

# game/scripts/scriptkitchen.rpy:1136
translate spanish kitchensparky_d8f60977:

    # s "Oh too bad..."
    s "Ah, qué lástima..."

# game/scripts/scriptkitchen.rpy:1141
translate spanish kitchensparky_bf01b038:

    # a "Hmm... I haven't known you for long Sparky but you seem kind of off... Is something wrong?"
    a "Hmm... No te conozco desde hace mucho, Sparky, pero parece que te pasa algo... ¿Hay algo mal?"

# game/scripts/scriptkitchen.rpy:1145
translate spanish kitchensparky_0e6f5b20:

    # o "S-Sparky are you okay? Y-you seem tired!"
    o "S-Sparky ¿estás bien? ¡Pareces cansado!"

# game/scripts/scriptkitchen.rpy:1149
translate spanish kitchensparky_6358ae1a:

    # b "That's an understatement."
    b "Eso es quedarse corto."

# game/scripts/scriptkitchen.rpy:1152
translate spanish kitchensparky_8d2a4b08:

    # s "I'm... I'm okay. I just haven't been able to get much sleep for the past few days."
    s "Estoy... estoy bien. Simplemente no he podido dormir mucho estos últimos días."

# game/scripts/scriptkitchen.rpy:1156
translate spanish kitchensparky_13990b9e:

    # o "L-let's nap together then!"
    o "¡Entonces tomemos una siesta juntos!"

# game/scripts/scriptkitchen.rpy:1158
translate spanish kitchensparky_f0441ce3:

    # o "L-let's all nap then!"
    o "¡Entonces tomemos una siesta!"

# game/scripts/scriptkitchen.rpy:1165
translate spanish kitchensparky_5bbe7a1e:

    # s "NO!" with vpunch
    s "¡NO!" with vpunch

# game/scripts/scriptkitchen.rpy:1167
translate spanish kitchensparky_3ab811ed:

    # s "I-I mean, that'd be a bad idea..."
    s "Q-quiero decir, eso sería una mala idea..."

# game/scripts/scriptkitchen.rpy:1171
translate spanish kitchensparky_20ef66b9:

    # s "I seem to have started sleepwalking..."
    s "Parece que comencé a caminar sonámbulo..."

# game/scripts/scriptkitchen.rpy:1176
translate spanish kitchensparky_185bb084:

    # o "That doesn't sound too bad! Th-that just means I should hug you while you nap!"
    o "¡Eso no suena tan mal! ¡E-eso sólo significa que debería abrazarte mientras duermes!"

# game/scripts/scriptkitchen.rpy:1179
translate spanish kitchensparky_6abce558:

    # o "That doesn't sound too bad! Th-that just means Angel and I should hug you while you nap!"
    o "¡Eso no suena tan mal! ¡E-eso solo significa que Angel y yo deberíamos abrazarte mientras duermes!"

# game/scripts/scriptkitchen.rpy:1182
translate spanish kitchensparky_effdda74:

    # a "I-it does?!"
    a "¡¿D-de verdad?!"

# game/scripts/scriptkitchen.rpy:1186
translate spanish kitchensparky_9e91eb46:

    # s "Woof. Maybe sleepwalking is a bit of an understatement."
    s "Quizás decir que soy sonámbulo es quedarse corto."

# game/scripts/scriptkitchen.rpy:1187
translate spanish kitchensparky_cbc86151:

    # s "When I wake up everyone around me looks horrified. Sometimes even hurt."
    s "Cuando despierto, todos a mi alrededor parecen horrorizados. A veces incluso heridos."

# game/scripts/scriptkitchen.rpy:1188
translate spanish kitchensparky_d9c7616e:

    # s "And I don't remember anything but I feel like I've said or done things that I'd regret..."
    s "Y no recuerdo nada pero siento que he dicho o hecho cosas de las que me arrepentiría..."

# game/scripts/scriptkitchen.rpy:1190
translate spanish kitchensparky_c1752f66:

    # s "I can't let myself hurt anyone else, so no napping for the time being. In fact,"
    s "No puedo permitirme lastimar a nadie más, así que nada de siestas por el momento. De hecho,"

# game/scripts/scriptkitchen.rpy:1193
translate spanish kitchensparky_11f62112:

    # s "I shouldn't even be around you right now..."
    s "Ni siquiera debería estar cerca de ti ahora mismo..."

# game/scripts/scriptkitchen.rpy:1196
translate spanish kitchensparky_64d2411a:

    # o "Aww Sparky! If you h-hurt anyone I'm sure they'd understand you d-didn't mean to!!"
    o "¡Aww, Sparky! ¡¡Si lastimas a alguien, seguro que entenderán que no fue tu intención!!"

# game/scripts/scriptkitchen.rpy:1199
translate spanish kitchensparky_21a49732:

    # s "Heh, that's a nice sentiment Olive..."
    s "Je, ese es un lindo sentimiento Olive..."

# game/scripts/scriptkitchen.rpy:1200
translate spanish kitchensparky_d77a477b:

    # s "But better safe than sorry!"
    s "¡Pero más vale prevenir que curar!"

# game/scripts/scriptkitchen.rpy:1206
translate spanish kitchensparky_e2244056:

    # n "Sparky backs into the corner of the kitchen."
    n "Sparky regresa a la esquina de la cocina."

# game/scripts/scriptkitchen.rpy:1209
translate spanish kitchensparky_9fcd987b:

    # s "I shouldn't even be around you two right now..."
    s "Ni siquiera debería estar cerca de ustedes dos en este momento..."

# game/scripts/scriptkitchen.rpy:1212
translate spanish kitchensparky_dd671d6c:

    # a "On the contrary... This sounds like something you can't handle alone..."
    a "Al contrario... Esto suena como algo que no puedes manejar solo..."

# game/scripts/scriptkitchen.rpy:1213
translate spanish kitchensparky_18e3e2c6:

    # a "You should consider speaking with Coco once she's free."
    a "Deberías considerar hablar con Coco una vez que esté libre."

# game/scripts/scriptkitchen.rpy:1216
translate spanish kitchensparky_e11e47f9:

    # s "I'll do that. Thanks Angel!"
    s "Haré eso. Gracias Angel!"

# game/scripts/scriptkitchen.rpy:1222
translate spanish kitchensparky_e2244056_1:

    # n "Sparky backs into the corner of the kitchen."
    n "Sparky regresa a la esquina de la cocina."

# game/scripts/scriptkitchen.rpy:1233
translate spanish kitchensparky_ec5590e7:

    # b "Okay now THAT'S an understatement!"
    b "Bien, ¡ESO es quedarse corto!"

# game/scripts/scriptkitchen.rpy:1237
translate spanish kitchensparky_61b4b229:

    # a "Brownie do you mind enlightening us as to why you're so averse to Sparky?"
    a "Brownie, ¿te molestaría explicarnos por qué le tienes tanta aversión a Sparky?"

# game/scripts/scriptkitchen.rpy:1241
translate spanish kitchensparky_c4dcd3ae:

    # o "B-B-BROWNIE! Don't be a b-bad dog!!"
    o "¡B-B-BROWNIE! ¡¡No seas un mal perro!!"

# game/scripts/scriptkitchen.rpy:1242
translate spanish kitchensparky_5a0dc9de:

    # o "You're going to make Sparky f-f-feel bad!!"
    o "¡¡Vas a hacer que Sparky se s-s-sienta mal!!"

# game/scripts/scriptkitchen.rpy:1245
translate spanish kitchensparky_b33acd73:

    # b "Alriiiight, dropping the passive aggressive act now."
    b "Muy biieeen, voy a dejar de lado esa actitud pasivo-agresiva."

# game/scripts/scriptkitchen.rpy:1249
translate spanish kitchensparky_00a47dcb:

    # b "Sparky, you fell asleep while we were hangin' out and started mumbling about all the ways you were gonna ''make me pay''!"
    b "¡Sparky, te quedaste dormido mientras estábamos juntos y empezaste a murmurar sobre todas las formas en que ibas a ''hacerme pagar''!"

# game/scripts/scriptkitchen.rpy:1251
translate spanish kitchensparky_f7da908c:

    # b "It was really fuckin' disgusting!"
    b "¡Fue jodidamente asqueroso!"

# game/scripts/scriptkitchen.rpy:1254
translate spanish kitchensparky_a3784f54:

    # s "What?! I-I don't even remember that!!"
    s "¡¿Qué?! ¡¡Ni siquiera recuerdo eso!!"

# game/scripts/scriptkitchen.rpy:1257
translate spanish kitchensparky_59c39bac:

    # b "Well maybe your gross dreams are a manifestation of your inner feelings or some Freudian bullshit like that."
    b "Bueno, tal vez tus sueños asquerosos sean una manifestación de tus sentimientos internos o alguna tontería por el estilo."

# game/scripts/scriptkitchen.rpy:1260
translate spanish kitchensparky_6ae0132c:

    # n "Sparky looks horrified with himself."
    n "Sparky parece horrorizado de sí mismo."

# game/scripts/scriptkitchen.rpy:1262
translate spanish kitchensparky_07ceaf1c:

    # s "I-I'm sorry, you should all just stay away from me."
    s "Lo siento, deberían mantenerse alejados de mí."

# game/scripts/scriptkitchen.rpy:1266
translate spanish kitchensparky_ec77e385:

    # o "N-no!!"
    o "¡¡N-no!!"

# game/scripts/scriptkitchen.rpy:1269
translate spanish kitchensparky_d798441b:

    # b "Wait Sparky I'm sorry, like really genuinely sorry."
    b "Espera Sparky, lo siento, realmente lo siento."

# game/scripts/scriptkitchen.rpy:1270
translate spanish kitchensparky_6500d438:

    # b "Maybe I shouldn't've ditched you. You might seriously need some help!"
    b "Quizás no debería haberte abandonado. ¡Es posible que realmente necesites ayuda!"

# game/scripts/scriptkitchen.rpy:1273
translate spanish kitchensparky_4fc97f8f:

    # s "Don't talk to me. I need to figure this out by myself."
    s "No me hables. Necesito resolver esto por mi cuenta."

# game/scripts/scriptkitchen.rpy:1278
translate spanish kitchensparky_e2244056_2:

    # n "Sparky backs into the corner of the kitchen."
    n "Sparky regresa a la esquina de la cocina."

# game/scripts/scriptkitchen.rpy:1287
translate spanish kitchengiveup_07abc845:

    # o "..."
    o "..."

# game/scripts/scriptkitchen.rpy:1289
translate spanish kitchengiveup_b7f68439:

    # o "O-okay you're r-right."
    o "E-está bien, tienes razón."

# game/scripts/scriptkitchen.rpy:1292
translate spanish kitchengiveup_e1a6c995:

    # c "Let's think of something else."
    c "Pensemos en otra cosa."

# game/scripts/scriptkitchen.rpy:1305
translate spanish kitchenmeat01_196becab:

    # o "All the zombies outside are j-just a bunch of angry d-dogs right?"
    o "Todos los zombies afuera son solo un grupo de p-perros enojados, ¿verdad?"

# game/scripts/scriptkitchen.rpy:1307
translate spanish kitchenmeat01_51dd6216:

    # o "A-and dogs love meat!"
    o "¡Y a los perros les encanta la carne!"

# game/scripts/scriptkitchen.rpy:1310
translate spanish kitchenmeat01_43058a2c:

    # c "Oh no..."
    c "Oh, no..."

# game/scripts/scriptkitchen.rpy:1313
translate spanish kitchenmeat01_eac6e2d5:

    # o "So maybe if we give them some as a gift th-th-they'll listen to us!!"
    o "Así que tal vez si les damos un poco como regalo ¡¡nos escucharán!!"

# game/scripts/scriptkitchen.rpy:1316
translate spanish kitchenmeat01_0b15d51e:

    # c "OLIVE."
    c "OLIVE."

# game/scripts/scriptkitchen.rpy:1317
translate spanish kitchenmeat01_0eb537ac:

    # c "You're VERY sweet and we all love you for it but,"
    c "Eres MUY dulce y todos te amamos por eso pero,"

# game/scripts/scriptkitchen.rpy:1319
translate spanish kitchenmeat01_0775daf5:

    # c "THAT IS THE WORST IDEA I HAVE EVER HEARD!!"
    c "¡¡ES LA PEOR IDEA QUE HE ESCUCHADO!!"

# game/scripts/scriptkitchen.rpy:1320
translate spanish kitchenmeat01_4af45e8c:

    # c "They don't want meat unless it's OURS!"
    c "¡No quieren carne a menos que sea la NUESTRA!"

# game/scripts/scriptkitchen.rpy:1331
translate spanish kitchenmeat02_80e19672:

    # o "How do you know they're bad dogs?! Have you asked?!"
    o "¡¿Cómo sabes que son perros malos?! ¿Les has preguntado?"

# game/scripts/scriptkitchen.rpy:1334
translate spanish kitchenmeat02_543a7032:

    # c "I don't need to ask!! All they talk about is revenge!"
    c "¡¡No necesito preguntar!! ¡Sólo hablan de vengarse!"

# game/scripts/scriptkitchen.rpy:1335
translate spanish kitchenmeat02_b9afc25f:

    # c "And they chased you through the woods while groaning about it. A-and they just coincidentally showed up at the same time as Patches."
    c "Y te persiguieron por el bosque mientras se quejaban de eso. Y casualmente aparecieron al mismo tiempo que Patches."

# game/scripts/scriptkitchen.rpy:1337
translate spanish kitchenmeat02_cdd4ee23:

    # c "WE CAN'T TRUST THEM."
    c "NO PODEMOS CONFIAR EN ELLOS."

# game/scripts/scriptkitchen.rpy:1351
translate spanish kitchenmeat03_982baa83:

    # o "Please I j-just want to talk to them!"
    o "¡Por favor, s-solo quiero hablar con ellos!"

# game/scripts/scriptkitchen.rpy:1352
translate spanish kitchenmeat03_09af5bfc:

    # o "They're all angry and hurt! What are we going to do against a th-thousand zombies even if we have a weapon!"
    o "¡Están todos enojados y heridos! ¡¿Qué vamos a hacer contra mil zombis aunque tengamos un arma?!"

# game/scripts/scriptkitchen.rpy:1355
translate spanish kitchenmeat03_199af8ec:

    # c "We're going to get my wand back and I-I'll-"
    c "Vamos a recuperar mi varita y yo-yo-"

# game/scripts/scriptkitchen.rpy:1358
translate spanish kitchenmeat03_36e16111:

    # o "Are you going to k-kill them again?!"
    o "¡¿Vas a matarlos de nuevo?!"

# game/scripts/scriptkitchen.rpy:1361
translate spanish kitchenmeat03_431866b5:

    # c "It's us or them Olive."
    c "Somos nosotros o ellos Olive."

# game/scripts/scriptkitchen.rpy:1363
translate spanish kitchenmeat03_f6006a9e:

    # n "Coco shakily stands between Olive and the fridge full of meat."
    n "Coco se interpone temblorosamente entre Olive y la nevera llena de carne."

# game/scripts/scriptkitchen.rpy:1373
translate spanish kitchenmeat04_0c2d334f:

    # o "My birthday wish is for you to trust the meat!!"
    o "¡¡Mi deseo de cumpleaños es que confíes en la carne!!"

# game/scripts/scriptkitchen.rpy:1376
translate spanish kitchenmeat04_d19f855d:

    # c "..."
    c "..."

# game/scripts/scriptkitchen.rpy:1378
translate spanish kitchenmeat04_ae231d57:

    # o "Th-there was a note on your door! It said you owe me one birthday w-wish!"
    o "¡Había una nota en tu puerta! ¡Decía que me debes un deseo por mi cumpleaños!"

# game/scripts/scriptkitchen.rpy:1380
translate spanish kitchenmeat04_d19f855d_1:

    # c "..."
    c "..."

# game/scripts/scriptkitchen.rpy:1382
translate spanish kitchenmeat04_d60a7594:

    # n "Coco begrudgingly steps out of the way."
    n "Coco se aparta del camino a regañadientes."

# game/scripts/scriptkitchen.rpy:1384
translate spanish kitchenmeat04_e2213f67:

    # n "Olive is surprised this worked."
    n "Olive se sorprende de que eso haya funcionado."

# game/scripts/scriptkitchen.rpy:1387
translate spanish kitchenmeat04_a7f47ca2:

    # n "Olive finds a tray in one of the cupboards and scoops as much meat onto it as possible."
    n "Olive encuentra una bandeja en uno de los armarios y echa en ella tanta carne como puede."

# game/scripts/scriptkitchen.rpy:1389
translate spanish kitchenmeat04_8b5d494c:

    # n "They walk with it towards the door,"
    n "Camina con la bandeja hacia la puerta,"

# game/scripts/scriptkitchen.rpy:1391
translate spanish kitchenmeat04_bc1b2f75:

    # n "And kick the chair out from under the doorknob!"
    n "¡Y saca la silla de debajo del pomo de la puerta!"

# game/scripts/scriptkitchen.rpy:1393
translate spanish kitchenmeat04_36135779:

    # c "AGHH!! OLIVE WHAT ARE YOU DOING?!"
    c "¡¡AGHH!! ¡¿OLIVE QUÉ ESTÁS HACIENDO?!"

# game/scripts/scriptkitchen.rpy:1404
translate spanish kitchenmeat04_ca4ee851:

    # n "The door bursts open and zombies stream into the kitchen!" with vpunch
    n "¡La puerta se abre de golpe y los zombis entran en la cocina!" with vpunch

# game/scripts/scriptkitchen.rpy:1407
translate spanish kitchenmeat04_93d10807:

    # n "Coco panics and jumps on the kitchen table. Olive follows in order to gain some height."
    n "Coco entra en pánico y salta sobre la mesa de la cocina. Olive la sigue para ganar algo de altura."

# game/scripts/scriptkitchen.rpy:1408
translate spanish kitchenmeat04_f0f0dce1:

    # n "In the loudest voice they can manage, they scream."
    n "Grita con la voz más alta que puede."

# game/scripts/scriptkitchen.rpy:1410
translate spanish kitchenmeat04_3d1eba5d:

    # o "WAIT!!"
    o "¡¡ESPEREN!!"

# game/scripts/scriptkitchen.rpy:1412
translate spanish kitchenmeat04_9376e73e:

    # o "WE'RE GOING TO T-TALK THIS OUT!"
    o "¡VAMOS A H-HABLAR DE ESTO!"

# game/scripts/scriptkitchen.rpy:1414
translate spanish kitchenmeat04_682ce8e2:

    # o "OVER AN ASSORTMENT!!"
    o "¡¡¡SOBRE UNOS APERITIVOS"

# game/scripts/scriptkitchen.rpy:1416
translate spanish kitchenmeat04_6d49bf47:

    # o "OF DELICIOUS MEAAATS!!!"
    o "DE UNAS CARNES DELICIOSAS!!!"

# game/scripts/scriptkitchen.rpy:1419
translate spanish kitchenmeat04_0f69d142:

    # n "They start throwing chunks of meat into the crowd of zombies."
    n "Olive comienza a arrojar trozos de carne a la multitud de zombis."

# game/scripts/scriptkitchen.rpy:1421
translate spanish kitchenmeat04_4a2b9848:

    # c "Holy shit is this really how I'm going to die?"
    c "Mierda, ¿es así realmente como voy a morir?"

# game/scripts/scriptkitchen.rpy:1424
translate spanish kitchenmeat04_8c439cc7:

    # n "The zombies..."
    n "Los zombis..."

# game/scripts/scriptkitchen.rpy:1427
translate spanish kitchenmeat04_d0b32008:

    # n "Start eating the meat."
    n "Empiezan a comer la carne."

# game/scripts/scriptkitchen.rpy:1429
translate spanish kitchenmeat04_5ca5af93:

    # n "Olive continues throwing meat at the zombies. It's a blood bath the likes of which they've never seen."
    n "Olive continúa arrojando carne a los zombies. Es un baño de sangre como nunca antes habían visto."

# game/scripts/scriptkitchen.rpy:1431
translate spanish kitchenmeat04_8df45713:

    # n "Eventually the tray empties and all that's left is a small pool of blood."
    n "Finalmente la bandeja se vacía y lo único que queda es un pequeño charco de sangre."

# game/scripts/scriptkitchen.rpy:1433
translate spanish kitchenmeat04_07bd8011:

    # o "O-okay!! Now let's talk!"
    o "¡¡E-está bien!! ¡Ahora hablemos!"

# game/scripts/scriptkitchen.rpy:1434
translate spanish kitchenmeat04_1dd1029d:

    # o "Wh-what d-d-do you guys want?!"
    o "¡¿Q-qué quieren?!"

# game/scripts/scriptkitchen.rpy:1437
translate spanish kitchenmeat04_9ff2718f:

    # z "MEeEeAaT!!"
    z "¡¡CArnEeEe!!"

# game/scripts/scriptkitchen.rpy:1439
translate spanish kitchenmeat04_49c57efe:

    # z "NOoOoOo YOU MOoOoRONS WE WANT REeVEeNGE!!!"
    z "¡¡¡NOoOoOo, PeDAZo dE IDIOoOoOTAS!!! ¡¡¡QUeREmOoOoOS VEnGAnZa!!!"

# game/scripts/scriptkitchen.rpy:1441
translate spanish kitchenmeat04_82342b2f:

    # z "YEeEeEeAaAaH REeVEeEeNGE!!!"
    z "¡¡¡SIiIiiIi!!! ¡¡¡VEnGAaaaAAaNZaAAaA!!!"

# game/scripts/scriptkitchen.rpy:1443
translate spanish kitchenmeat04_04491cf3:

    # o "O-okay, revenge!! B-but revenge won't get you your lives back or your bodies f-fixed."
    o "¡¡E-está bien, venganza!! P-pero la venganza no les devolverá sus vidas ni sus cuerpos."

# game/scripts/scriptkitchen.rpy:1444
translate spanish kitchenmeat04_c84be950:

    # o "M-maybe revenge doesn't make you happy!!"
    o "¡¡Quizás la venganza no les haga felices!!"

# game/scripts/scriptkitchen.rpy:1447
translate spanish kitchenmeat04_20918e51:

    # z "H-HAaAaPPY?"
    z "¿F-FEliZzZzZ?"

# game/scripts/scriptkitchen.rpy:1449
translate spanish kitchenmeat04_5f73fa63:

    # o "Yeah!! What makes me happy is e-eating snacks with a bunch of really n-nice friends!"
    o "¡¡Sí!! ¡Lo que me hace feliz es c-comer bocadillos con mis amigos que son realmente a-agradables conmigo!"

# game/scripts/scriptkitchen.rpy:1451
translate spanish kitchenmeat04_fc0937e3:

    # o "You could all be my friends!!"
    o "¡¡Todos ustedes podrían ser mis amigos!!"

# game/scripts/scriptkitchen.rpy:1454
translate spanish kitchenmeat04_c879ae4c:

    # z "F-FUuRIEeNDS???"
    z "¿¿A-aMiGOssSsS???"

# game/scripts/scriptkitchen.rpy:1456
translate spanish kitchenmeat04_e2d3ded4:

    # o "YEAH! FURIENDS!!!"
    o "¡SÍ! ¡¡FURRMIGOS!!"

# game/scripts/scriptkitchen.rpy:1457
translate spanish kitchenmeat04_4940370d:

    # o "If you help us get Coco's magic wand back we can fix you up using her magic!"
    o "¡Si nos ayudan a recuperar la varita mágica de Coco, podemos arreglarlos usando su magia!"

# game/scripts/scriptkitchen.rpy:1460
translate spanish kitchenmeat04_3e0390ff:

    # c "Uh..."
    c "Oh..."

# game/scripts/scriptkitchen.rpy:1463
translate spanish kitchenmeat04_a6b9f9de:

    # z "REeEeALLY?!"
    z "¡¿De vErDaD?!"

# game/scripts/scriptkitchen.rpy:1464
translate spanish kitchenmeat04_6d312d4c:

    # z "THAaAaT SOoOoUNDS..."
    z "ESo SueNa..."

# game/scripts/scriptkitchen.rpy:1469
translate spanish kitchenmeat04_7d7f99db:

    # n "A flurry of knives suddenly flies through the door!" with vpunch
    n "¡De repente una ráfaga de cuchillos atraviesa la puerta!" with vpunch

# game/scripts/scriptkitchen.rpy:1471
translate spanish kitchenmeat04_8672a5cc:

    # n "They zip around, slicing and stabbing everything in their path."
    n "Los cuchillos se mueven rápidamente, cortando y apuñalando todo a su paso."

# game/scripts/scriptkitchen.rpy:1473
translate spanish kitchenmeat04_5a05a61d:

    # c "G-GET DOWN OLIVE!!"
    c "¡¡BAJA OLIVE!!"

# game/scripts/scriptkitchen.rpy:1480
translate spanish kitchenmeat04_105113eb:

    # n "Coco grabs Olive and pulls them under the kitchen table."
    n "Coco agarra a Olive y le empuja debajo de la mesa de la cocina."

# game/scripts/scriptkitchen.rpy:1484
translate spanish kitchenmeat04_3b544ca7:

    # n "The knives have sliced a path through the zombies." with vpunch
    n "Los cuchillos han abierto un camino a través de los zombies." with vpunch

# game/scripts/scriptkitchen.rpy:1488
translate spanish kitchenmeat04_11ef7e8b:

    # p "Ahh stabbing traitors, a beloved pastime!"
    p "¡Ahh apuñalar a los traidores, un buen pasatiempo!"

# game/scripts/scriptkitchen.rpy:1489
translate spanish kitchenmeat04_9a0f1551:

    # p "Now where are you two? I need to add you to my collection!"
    p "¿Dónde están ustedes dos? ¡Necesito agregarlos a mi colección!"

# game/scripts/scriptkitchen.rpy:1491
translate spanish kitchenmeat04_f35c3c4f:

    # p "Sparky's taking care of the others as we speak!"
    p "¡Sparky se está ocupando de los demás mientras hablamos!"

# game/scripts/scriptkitchen.rpy:1496
translate spanish kitchenmeat04_f3629768:

    # n "Patches steps forward right into the tray of blood."
    n "Patches avanza hacia la bandeja de sangre."

# game/scripts/scriptkitchen.rpy:1498
translate spanish kitchenmeat04_ba3cb33e:

    # p "So this is what won them over, huh? A bunch of disgusting meat and empty promises?"
    p "Entonces esto es lo que los convenció, ¿eh? ¿Un montón de carne asquerosa y promesas vacías?"

# game/scripts/scriptkitchen.rpy:1499
translate spanish kitchenmeat04_b71a99a8:

    # p "I'll never understand how others are so quick to trust."
    p "Nunca entenderé cómo los demás pueden confiar tan rápido."

# game/scripts/scriptkitchen.rpy:1501
translate spanish kitchenmeat04_84e73b6f:

    # p "And after Ginger gave them life and I gave them justice..."
    p "Y después de que Ginger les diera vida y yo les diera justicia..."

# game/scripts/scriptkitchen.rpy:1503
translate spanish kitchenmeat04_672ce414:

    # p "It still wasn't enough to keep them loyal..."
    p "Todavía no era suficiente para mantenerlos leales..."

# game/scripts/scriptkitchen.rpy:1505
translate spanish kitchenmeat04_62043b7b:

    # n "Patches notices Olive's tail sticking out from under the kitchen table."
    n "Patches nota la cola de Olive sobresaliendo de debajo de la mesa."

# game/scripts/scriptkitchen.rpy:1507
translate spanish kitchenmeat04_6f186379:

    # p "Hehehe there you are!"
    p "¡Jejeje ahí estás!"

# game/scripts/scriptkitchen.rpy:1509
translate spanish kitchenmeat04_fec6a507:

    # n "Patches reaches for Olive's tail but a zombie playing dead on the ground grabs his leg!"
    n "Patches intenta alcanzar la cola de Olive, ¡pero un zombi que se hacía el muerto en el suelo lo agarra de la pierna!"

# game/scripts/scriptkitchen.rpy:1513
translate spanish kitchenmeat04_21bf487c:

    # n "He hits the floor and loses grip on the wand!" with vpunch
    n "¡Cae al suelo y pierde el control de la varita!" with vpunch

# game/scripts/scriptkitchen.rpy:1520
translate spanish kitchenmeat04_0cc6877d:

    # n "Coco scrambles out from under the table to grab it!"
    n "¡Coco sale de debajo de la mesa para agarrarla!"

# game/scripts/scriptkitchen.rpy:1524
translate spanish kitchenmeat04_d5fc6376:

    # p "NO!!"
    p "¡¡NO!!"

# game/scripts/scriptkitchen.rpy:1527
translate spanish kitchenmeat04_0c44800c:

    # n "Coco sends a massive blast of energy at Patches!" with vpunch
    n "¡Coco envía una explosión masiva de energía a Patches!" with vpunch

# game/scripts/scriptkitchen.rpy:1528
translate spanish kitchenmeat04_ec4efbf0:

    # n "The kitchen is filled with bright green light."
    n "La cocina se llena de luz verde brillante."

# game/scripts/scriptkitchen.rpy:1537
translate spanish kitchenmeat04_cb6cfaac:

    # n "Patches is gone."
    n "Patches desapareció."

# game/scripts/scriptkitchen.rpy:1539
translate spanish kitchenmeat04_68d0e416:

    # o "AHH!! D-did you v-vaporize him?!"
    o "¡¡AH!! ¡¿Lo v-vaporizaste?!"

# game/scripts/scriptkitchen.rpy:1542
translate spanish kitchenmeat04_7f8b1ff2:

    # c "AGHH NO! He got away!!"
    c "¡AGHH NO! ¡¡Se escapó!!"

# game/scripts/scriptkitchen.rpy:1545
translate spanish kitchenmeat04_76718886:

    # o "I w-wonder who Ginger is..."
    o "Me pregunto quién es Ginger..."

# game/scripts/scriptkitchen.rpy:1548
translate spanish kitchenmeat04_b404aa2b:

    # n "Screaming is heard from upstairs." with vpunch
    n "Se oyen gritos desde el piso de arriba." with vpunch

# game/scripts/scriptkitchen.rpy:1550
translate spanish kitchenmeat04_74e4e472:

    # c "ANGEL AND BROWNIE!!"
    c "¡¡ANGEL Y BROWNIE!!"

# game/scripts/scriptkitchen.rpy:1553
translate spanish kitchenmeat04_f510a8de:

    # o "S-S-SPARKY!!"
    o "¡¡S-S-SPARKY!!"

# game/scripts/scriptkitchen.rpy:1556
translate spanish kitchenmeat04_408d8655:

    # c "We need to go!"
    c "¡Tenemos que irnos!"

translate spanish strings:

    # game/scripts/scriptkitchen.rpy:31
    old "{color=#86c4eb}Inspect fridge.{/color}"
    new "{color=#86c4eb}Revisar la heladera.{/color}"

    # game/scripts/scriptkitchen.rpy:31
    old "{color=#86c4eb}Inspect knife block.{/color}"
    new "{color=#86c4eb}Revisar el taco de cuchillos.{/color}"

    # game/scripts/scriptkitchen.rpy:31
    old "{color=#86c4eb}Inspect pots and pans.{/color}"
    new "{color=#86c4eb}Revisar ollas y sartenes.{/color}"

    # game/scripts/scriptkitchen.rpy:31
    old "{color=#86c4eb}Talk to Sparky.{/color}"
    new "{color=#86c4eb}Hablar con Sparky.{/color}"

    # game/scripts/scriptkitchen.rpy:31
    old "{color=#ffcd65}Leave.{/color}"
    new "{color=#ffcd65}Salir.{/color}"

    # game/scripts/scriptkitchen.rpy:135
    old "Offer cake."
    new "Ofrecer pastel."

    # game/scripts/scriptkitchen.rpy:135
    old "Offer blood."
    new "Ofrecer sangre."

    # game/scripts/scriptkitchen.rpy:258
    old "Open fridge."
    new "Abrir la heladera."

    # game/scripts/scriptkitchen.rpy:618
    old "Forgive Coco."
    new "Perdonar a Coco."

    # game/scripts/scriptkitchen.rpy:831
    old "Compliment her plan."
    new "Elogiar su plan."

    # game/scripts/scriptkitchen.rpy:831
    old "Question the plan."
    new "Cuestionar su plan."

    # game/scripts/scriptkitchen.rpy:932
    old "Ask Sparky out."
    new "Invitarlo a salir de la cocina."

    # game/scripts/scriptkitchen.rpy:932
    old "Leave Sparky alone."
    new "Dejar a Sparky en paz."

    # game/scripts/scriptkitchen.rpy:962
    old "Joke."
    new "Bromear."

    # game/scripts/scriptkitchen.rpy:962
    old "Deny."
    new "Negar."

    # game/scripts/scriptkitchen.rpy:1301
    old "Trust the meat."
    new "Confía en la carne."

    # game/scripts/scriptkitchen.rpy:1327
    old "Give up."
    new "Darse por vencido."

    # game/scripts/scriptkitchen.rpy:1370
    old "Wish."
    new "Desear."

