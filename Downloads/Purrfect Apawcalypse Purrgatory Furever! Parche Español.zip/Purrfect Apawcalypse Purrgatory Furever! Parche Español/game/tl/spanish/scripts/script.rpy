﻿# TODO: Translation updated at 2024-11-25 12:57

# game/scripts/script.rpy:402
translate spanish start_0ae9bcd0:

    # ""
    ""

# game/scripts/script.rpy:407
translate spanish start_0ae9bcd0_1:

    # ""
    ""

# game/scripts/script.rpy:412
translate spanish start_0ae9bcd0_2:

    # ""
    ""

# game/scripts/script.rpy:417
translate spanish start_04131c66:

    # "Last week one thousand dogs were killed,"
    "La semana pasada mil perros fueron asesinados,"

# game/scripts/script.rpy:418
translate spanish start_f7ab9a79:

    # "At the paws of one of the most evil creatures known to dogkind..."
    "En las garras de una de las criaturas más malvadas conocidas por los perros..."

# game/scripts/script.rpy:420
translate spanish start_c5c8e936:

    # "A cat!"
    "¡Una gata!"

# game/scripts/script.rpy:422
translate spanish start_48525d46:

    # "On the hunt for the killer of her dear little brother,"
    "A la caza del asesino de su querido hermano pequeño,"

# game/scripts/script.rpy:424
translate spanish start_c9209008:

    # "She killed all who stood in her way and even some who didn't."
    "Mató a todos los que se interpusieron en su camino e incluso a algunos que no lo hicieron."

# game/scripts/script.rpy:426
translate spanish start_49e75cd8:

    # "Though her frenzy struck fear into the heart of every dog there,"
    "Aunque su frenesí infundió miedo en el corazón de todos los perros presentes,"

# game/scripts/script.rpy:427
translate spanish start_8dde5553:

    # "The killer remained elusive..."
    "El asesino seguía prófugo..."

# game/scripts/script.rpy:429
translate spanish start_df7b7333:

    # "Until a puppy named Olive showed up!"
    "¡Hasta que apareció una cachorrita llamada Olive!"

# game/scripts/script.rpy:431
translate spanish start_c6f2d9bc:

    # "With an uncanny ability to be in the right place at the right time they and their friends helped find the killer,"
    "Con una asombrosa habilidad para estar en el lugar correcto en el momento correcto, ella y sus amigos ayudaron a encontrar al asesino."

# game/scripts/script.rpy:433
translate spanish start_26c8f1a3:

    # "Thus freeing the cat from her rampage and offering her lost brother..."
    "Liberando así a la gata de su furia y ofreciéndole a su hermano perdido..."

# game/scripts/script.rpy:435
translate spanish start_5ed841bc:

    # "A new body!"
    "¡Un nuevo cuerpo!"

# game/scripts/script.rpy:437
translate spanish start_a5cf0327:

    # "These cats and dogs lived happily ever after!"
    "¡Estos perros y gatos vivieron felices para siempre!"

# game/scripts/script.rpy:439
translate spanish start_7f12ee28:

    # "But the weight of one thousand dead dogs still hangs in their consciences."
    "Pero el peso de mil perros muertos aún pesa sobre sus conciencias."

# game/scripts/script.rpy:459
translate spanish screamheard_e07c904f:

    # n "The group hears a high pitched scream coming from the bedroom!"
    n "¡El grupo escucha un grito agudo proveniente del dormitorio!"

# game/scripts/script.rpy:464
translate spanish screamheard_2f2614bd:

    # o "C-COCO?!"
    o "¡¿C-COCO?!"

# game/scripts/script.rpy:467
translate spanish screamheard_040a4ae1:

    # b "Oh snap is she okay?!"
    b "Oh, vaya, ¿está bien?"

# game/scripts/script.rpy:470
translate spanish screamheard_ea3cb669:

    # a "We need to get to her now!!!"
    a "¡¡¡Necesitamos entrar ahora!!!"

# game/scripts/script.rpy:491
translate spanish bestending_25457b9d:

    # x ""
    x ""

# game/scripts/script.rpy:497
translate spanish bestending_5fcb4909:

    # n "Everyone survived!"
    n "¡Todos sobrevivieron!"

# game/scripts/script.rpy:503
translate spanish bestending_25457b9d_1:

    # x ""
    x ""

# game/scripts/script.rpy:509
translate spanish bestending_62336751:

    # n "Almost everyone survived."
    n "Casi todos sobrevivieron."

# game/scripts/script.rpy:533
translate spanish heartrewards_73b0e9b3:

    # n "You didn't make anyone particularly happy."
    n "No hiciste a nadie particularmente feliz."

# game/scripts/script.rpy:541
translate spanish heartrewards_f0e43841:

    # n "You made Brownie super happy!"
    n "¡Hiciste súper feliz a Brownie!"

# game/scripts/script.rpy:551
translate spanish heartrewards_685542c2:

    # n "You made Angel super happy!"
    n "¡Hiciste súper feliz a Angel!"

# game/scripts/script.rpy:561
translate spanish heartrewards_36efda11:

    # n "You made Coco super happy!"
    n "¡Hiciste súper feliz a Coco!"

# game/scripts/script.rpy:571
translate spanish heartrewards_1e11e178:

    # n "You made Sparky super happy!"
    n "¡Hiciste súper feliz a Sparky!"

# game/scripts/script.rpy:581
translate spanish heartrewards_422fabdd:

    # n "You made Ginger super happy!"
    n "¡Hiciste súper feliz a Ginger!"

# game/scripts/script.rpy:591
translate spanish heartrewards_9bf4cb9c:

    # n "You made Patches super happy!"
    n "¡Hiciste súper feliz a Patches!"

# game/scripts/script.rpy:607
translate spanish heartrewards_db1de16b:

    # n "You made everyone super happy!"
    n "¡Hiciste a todos súper felices!"

# game/scripts/script.rpy:616
translate spanish heartrewards_189df6ec:

    # n "Almost..."
    n "Casi..."

# game/scripts/script.rpy:630
translate spanish gameover_ff750c90:

    # x "{w=0.2}{nw}"
    x "{w=0.2}{nw}"

# game/scripts/script.rpy:632
translate spanish gameover_e19a8e13:

    # x "{w=1.5}{nw}"
    x "{w=1.5}{nw}"

# game/scripts/script.rpy:635
translate spanish gameover_4ebcda40:

    # x "{w=1}{nw}"
    x "{w=1}{nw}"

# game/scripts/script.rpy:638
translate spanish gameover_ff750c90_1:

    # x "{w=0.2}{nw}"
    x "{w=0.2}{nw}"

translate spanish strings:

    # game/scripts/script.rpy:89
    old "Olive"
    new "Olive"

    # game/scripts/script.rpy:90
    old "Angel"
    new "Angel"

    # game/scripts/script.rpy:91
    old "Brownie"
    new "Brownie"

    # game/scripts/script.rpy:92
    old "Sparky"
    new "Sparky"

    # game/scripts/script.rpy:94
    old "Ginger?"
    new "¿Ginger?"

    # game/scripts/script.rpy:95
    old "Coco"
    new "Coco"

    # game/scripts/script.rpy:96
    old "Ginger"
    new "Ginger"

    # game/scripts/script.rpy:97
    old "Patches"
    new "Patches"

    # game/scripts/script.rpy:98
    old "Zombies"
    new "Zombis"

    # game/scripts/script.rpy:477
    old "Try again."
    new "Intentar de nuevo."

    # game/scripts/script.rpy:514
    old "Credits."
    new "Créditos."

    # game/scripts/script.rpy:514
    old "Play again."
    new "Jugar de nuevo"

