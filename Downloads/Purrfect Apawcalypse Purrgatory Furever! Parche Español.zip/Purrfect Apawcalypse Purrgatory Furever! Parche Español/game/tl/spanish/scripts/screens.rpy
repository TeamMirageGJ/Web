﻿# TODO: Translation updated at 2024-11-25 12:57

translate spanish strings:

    # game/scripts/screens.rpy:148
    old "Back"
    new "Atrás"

    # game/scripts/screens.rpy:149
    old "Play"
    new "Auto"

    # game/scripts/screens.rpy:150
    old "Skip"
    new "Saltar"

    # game/scripts/screens.rpy:151
    old "Save"
    new "Guardar"

    # game/scripts/screens.rpy:152
    old "Load"
    new "Cargar"

    # game/scripts/screens.rpy:153
    old "Options"
    new "Opciones"

    # game/scripts/screens.rpy:173
    old "Start"
    new "Comenzar"

    # game/scripts/screens.rpy:175
    old "About"
    new "Acerca de..."

    # game/scripts/screens.rpy:182
    old "End Replay"
    new "Finalizar repetición"

    # game/scripts/screens.rpy:184
    old "Main"
    new "Principal"

    # game/scripts/screens.rpy:186
    old "Quit"
    new "Salir"

    # game/scripts/screens.rpy:351
    old "{#file_time}%B %d, %H:%M"
    new "{#file_time}%B %d, %H:%M"

    # game/scripts/screens.rpy:351
    old "Empty"
    new "Vacío"

    # game/scripts/screens.rpy:401
    old "Display"
    new "Pantalla"

    # game/scripts/screens.rpy:402
    old "Window"
    new "Ventana"

    # game/scripts/screens.rpy:403
    old "Fullscreen"
    new "Pantalla completa"

    # game/scripts/screens.rpy:409
    old "Click to Go Back"
    new "Clic para volver"

    # game/scripts/screens.rpy:411
    old "On Left Side"
    new "En el lado izquierdo"

    # game/scripts/screens.rpy:412
    old "On Right Side"
    new "En el lado derecho"

    # game/scripts/screens.rpy:419
    old "Unseen Text"
    new "Texto no leído"

    # game/scripts/screens.rpy:420
    old "After Choices"
    new "Tras decidir"

    # game/scripts/screens.rpy:421
    old "Transitions"
    new "Transiciones"

    # game/scripts/screens.rpy:430
    old "Language"
    new "Idioma"

    # game/scripts/screens.rpy:457
    old "Text Speed"
    new "Velocidad del texto"

    # game/scripts/screens.rpy:459
    old "Auto-Play Speed"
    new "Velocidad de reproducción automática"

    # game/scripts/screens.rpy:462
    old "Music Volume"
    new "Volumen de la música"

    # game/scripts/screens.rpy:466
    old "Sound Volume"
    new "Volumen del sonido"

    # game/scripts/screens.rpy:470
    old "Test"
    new "Prueba"

    # game/scripts/screens.rpy:473
    old "Mute All"
    new "Silenciar todo"

    # game/scripts/screens.rpy:545
    old "Yes."
    new "Sí."

    # game/scripts/screens.rpy:546
    old "No."
    new "No."

    # game/scripts/screens.rpy:572
    old "Skipping"
    new "Saltando..."

    # game/scripts/screens.rpy:703
    old "Menu"
    new "Menú"

