﻿# TODO: Translation updated at 2024-11-25 12:57

# game/scripts/scriptbath.rpy:13
translate spanish bathintro_91c6c2b4:

    # n "Brownie tries to slam the door shut, but Patches' arm is in the way!"
    n "Brownie intenta cerrar la puerta de golpe, ¡pero el brazo de Patches se interpone en el camino!"

# game/scripts/scriptbath.rpy:15
translate spanish bathintro_e2fb3665:

    # b "DOG DAMMIT I AM NOT DYING IN A BATHROOM!!"
    b "¡¡Maldita sea, no me muero en el baño!!"

# game/scripts/scriptbath.rpy:18
translate spanish bathintro_bb0b5771:

    # n "Brownie slams the door on his arm until it breaks off!!" with vpunch
    n "¡Brownie cierra la puerta con su brazo hasta que se rompe!" with vpunch

# game/scripts/scriptbath.rpy:19
translate spanish bathintro_406299c8:

    # n "She locks the door."
    n "Ella cierra la puerta."

# game/scripts/scriptbath.rpy:22
translate spanish bathintro_5e059f3c:

    # n "But with zombies and magic on the other side who knows how long it'll hold."
    n "Pero con zombies y magia del otro lado, quién sabe cuánto aguantará."

# game/scripts/scriptbath.rpy:26
translate spanish bathintro_973d359c:

    # n "Something puts a huge crack in the door." with vpunch
    n "Algo abre una grieta en la puerta." with vpunch

# game/scripts/scriptbath.rpy:28
translate spanish bathintro_850ef128:

    # b "..."
    b "..."

# game/scripts/scriptbath.rpy:31
translate spanish bathintro_850ef128_1:

    # b "..."
    b "..."

# game/scripts/scriptbath.rpy:32
translate spanish bathintro_bc7a7278:

    # n "Brownie is crying."
    n "Brownie está llorando."

# game/scripts/scriptbath.rpy:34
translate spanish bathintro_7ab6a9c9:

    # o "B-BROWNIE!!"
    o "¡¡B-BROWNIE!!"

# game/scripts/scriptbath.rpy:51
translate spanish bathintro_8384a549:

    # b "HEY! What if I was actually usin' it!!"
    b "¡EY! ¿Qué pasaría si realmente lo estuviera usando?"

# game/scripts/scriptbath.rpy:54
translate spanish bathintro_63280b0a:

    # a "Then you would've locked the door..."
    a "Entonces habrías cerrado la puerta..."

# game/scripts/scriptbath.rpy:58
translate spanish bathintro_7ab6a9c9_1:

    # o "B-BROWNIE!!"
    o "¡¡B-BROWNIE!!"

# game/scripts/scriptbath.rpy:61
translate spanish bathintro_399ad566:

    # b "OLLY?! OH MY DOG YOU'RE ALIVE!"
    b "¡¿OLLY?! ¡POR TODOS LOS PERROS ESTÁS VIVO!"

# game/scripts/scriptbath.rpy:66
translate spanish bathintro_6a93b04f:

    # n "Brownie hugs Olive with a vice grip and spins them around in excitement."
    n "Brownie abraza a Olive con fuerza y se ponen a girar emocionadas."

# game/scripts/scriptbath.rpy:68
translate spanish bathintro_4309c47b:

    # b "I thought you were a goner for sure!"
    b "¡Pensé que estabas muerta, de verdad!"

# game/scripts/scriptbath.rpy:71
translate spanish bathintro_54dc9a36:

    # o "D-do you guys really think I'm that w-weak?"
    o "¿De verdad creen que soy tan débil?"

# game/scripts/scriptbath.rpy:74
translate spanish bathintro_b1f76bd6:

    # b "Ehh who cares? You made it! Happy surprise birthday party!!!"
    b "Ehh ¿a quién le importa? ¡Lo lograste! ¡¡¡Feliz cumpleaños!!!"

# game/scripts/scriptbath.rpy:77
translate spanish bathintro_b05cfb7c:

    # o "H-happy surprise birthday party!!!"
    o "¡¡¡Feliz cumpleaños a mi!!!"

# game/scripts/scriptbath.rpy:80
translate spanish bathintro_bb8e4b4e:

    # a "..."
    a "..."

# game/scripts/scriptbath.rpy:83
translate spanish bathintro_98be2850:

    # n "Brownie nudges Angel."
    n "Brownie le da un codazo a Ángel."

# game/scripts/scriptbath.rpy:85
translate spanish bathintro_b51ede79:

    # a "O-oh! H-happy surprise birthday party!"
    a "¡Oh! ¡Feliz cumpleaños!"

# game/scripts/scriptbath.rpy:89
translate spanish bathintro_6b3b7908:

    # s "Heheh, happy surprise birthday Olive!"
    s "Jejeje, ¡feliz cumpleaños Olive!"

# game/scripts/scriptbath.rpy:92
translate spanish bathintro_4cd8e61c:

    # s "So Brownie, I think I may have scared you off back in the kitchen... I don't know what I did, but I didn't mean any harm!"
    s "Entonces, Brownie, creo que te asusté en la cocina... No sé lo que hice, ¡pero no fue mi intención hacerte daño!"

# game/scripts/scriptbath.rpy:95
translate spanish bathintro_4079552e:

    # o "Huh? Sparky?! Scary?! What are you t-talking about?"
    o "¿Eh? ¡¿Sparky?! ¡¿Aterrador?! ¿De qué estás hablando?"

# game/scripts/scriptbath.rpy:97
translate spanish bathintro_634ee722:

    # o "He's just a big fluffy good boy!"
    o "¡El es un buen chico!"

# game/scripts/scriptbath.rpy:100
translate spanish bathintro_a4c09233:

    # b "I CAN'T believe you brought him in here."
    b "No puedo creer que lo hayas traído aquí."

# game/scripts/scriptbath.rpy:103
translate spanish bathintro_6dbdf9a8:

    # b "Sorry not sorry. I totally ditched you Sparky!"
    b "Lo siento,pero no lo siento. ¡Te abandone por completo, Sparky!"

# game/scripts/scriptbath.rpy:106
translate spanish bathintro_0c9df12a:

    # s "I kind of figured... No one spends a half hour alone in the bathroom unless it's because of the social dynamic."
    s "Me imaginé... Nadie pasa media hora solo en el baño a menos que sea por la parte social."

# game/scripts/scriptbath.rpy:109
translate spanish bathintro_9ac22ece:

    # s "Why though?"
    s "¿Pero por qué?"

# game/scripts/scriptbath.rpy:114
translate spanish bathintro_b86b1766:

    # a "Sometimes it's just nice and quiet in here..."
    a "A veces aquí es agradable y tranquilo..."

# game/scripts/scriptbath.rpy:117
translate spanish bathintro_906a0147:

    # s "If you don't mind me asking... Why did you ditch me?"
    s "Si no te importa que te pregunte... ¿Por qué me abandonaste?"

# game/scripts/scriptbath.rpy:120
translate spanish bathintro_f8025b23:

    # b "You fell asleep while we were hangin' out and started mumbling about all the ways you were gonna ''make me pay''!!"
    b "¡¡Te quedaste dormido mientras estábamos juntos y empezaste a murmurar sobre todas las formas en que ibas a ''hacerme pagar''!!"

# game/scripts/scriptbath.rpy:122
translate spanish bathintro_f7da908c:

    # b "It was really fuckin' disgusting!"
    b "¡Fue terriblemente asqueroso!"

# game/scripts/scriptbath.rpy:125
translate spanish bathintro_31537bc0:

    # s "What?! I-I'm so sorry! I didn't mean to freak you out. I don't even remember saying anything!!"
    s "¡¿Qué?! ¡Lo siento mucho! No quise asustarte. ¡¡Ni siquiera recuerdo haber dicho nada!!"

# game/scripts/scriptbath.rpy:128
translate spanish bathintro_59c39bac:

    # b "Well maybe your gross dreams are a manifestation of your inner feelings or some Freudian bullshit like that."
    b "Bueno, tal vez tus sueños asquerosos sean una manifestación de tus sentimientos o alguna tontería estupida como esa."

# game/scripts/scriptbath.rpy:132
translate spanish bathintro_6ae0132c:

    # n "Sparky looks horrified with himself."
    n "Sparky parece horrorizado consigo mismo."

# game/scripts/scriptbath.rpy:135
translate spanish bathintro_456b6594:

    # s "I-I'm sorry, maybe you really should just stay away from me."
    s "Lo siento, tal vez deberías mantenerte alejada de mí."

# game/scripts/scriptbath.rpy:138
translate spanish bathintro_c2175868:

    # o "NOoOoOo!!"
    o "¡¡NOoooo!!"

# game/scripts/scriptbath.rpy:140
translate spanish bathintro_5a6f8ab1:

    # o "This just means it's e-even MORE important that we take you to Coco!!"
    o "¡Esto simplemente significa que es aún MÁS importante que te llevemos a Coco!"

# game/scripts/scriptbath.rpy:143
translate spanish bathintro_d69ad2dc:

    # o "Once you're fixed I b-bet you'll be a lot nicer!"
    o "Una vez que estés arreglado, ¡apuesto a que serás mucho mejor!"

# game/scripts/scriptbath.rpy:146
translate spanish bathintro_6fb2d176:

    # s "F-fixed?"
    s "¿E-arreglado?"

# game/scripts/scriptbath.rpy:150
translate spanish bathintro_0294c0f5:

    # a "Coco can fix anything... But her solutions are often cruel and unusual."
    a "Coco puede arreglar cualquier cosa... Pero sus soluciones suelen ser crueles e inusuales."

# game/scripts/scriptbath.rpy:153
translate spanish bathintro_478e854d:

    # b "BAHAHA good luck Sparky!"
    b "BAHAHA buena suerte Sparky!"

# game/scripts/scriptbath.rpy:156
translate spanish bathintro_4cca0892:

    # o "Come on, we're going n-n-now!!"
    o "¡¡Vamos, nos vamos a-a-ahora!!"

# game/scripts/scriptbath.rpy:165
translate spanish bathintro_862c81fa:

    # o "What are you doing in the bathroom Brownie?"
    o "¿Qué haces en el baño Brownie?"

# game/scripts/scriptbath.rpy:167
translate spanish bathintro_ae457642:

    # o "I m-mean, if you're not using it for its intended purrposes..."
    o "Quiero decir, si no lo estás usando para sus Purrpósitos previstos..."

# game/scripts/scriptbath.rpy:170
translate spanish bathintro_bfba4208:

    # b "Oh y'knooooow, just hanging out!"
    b "¡Oh, ya sabes, simplemente pasando el rato!"

# game/scripts/scriptbath.rpy:174
translate spanish bathintro_355b43b2:

    # a "Really."
    a "En realidad."

# game/scripts/scriptbath.rpy:177
translate spanish bathintro_b6f3ff38:

    # b "O-okay. Don't tell Sparky, but when I told him I had to go use the bathroom a half hour ago it was really just an excuse to, uhh,"
    b "O-está bien. No se lo digas a Sparky, pero cuando le dije que tenía que ir al baño hace media hora, en realidad fue solo una excusa para, uhh,"

# game/scripts/scriptbath.rpy:180
translate spanish bathintro_e08d5bb2:

    # o "OH! I g-guess it is k-kinda nice in here!"
    o "¡OH! ¡Supongo que es un poco agradable aquí!"

# game/scripts/scriptbath.rpy:183
translate spanish bathintro_07abc845:

    # o "..."
    o "..."

# game/scripts/scriptbath.rpy:185
translate spanish bathintro_69561c7f:

    # b "Uuugh okay okay."
    b "Uf, está bien, está bien."

# game/scripts/scriptbath.rpy:186
translate spanish bathintro_764e56ef:

    # b "To keep you from thinking of me as some kinda freak who hangs out alone in bathrooms all day, I'll tell you the truth."
    b "Para evitar que pienses en mí como una especie de bicho raro que se pasa el día solo en los baños, te diré la verdad."

# game/scripts/scriptbath.rpy:188
translate spanish bathintro_e86f4127:

    # b "Don't tell Sparky, but when I told him I had to go use the bathroom a half hour ago it was really just an excuse to, uhh,"
    b "No se lo digas a Sparky, pero cuando le dije que tenía que ir al baño hace media hora, en realidad fue solo una excusa para, uhh,"

# game/scripts/scriptbath.rpy:190
translate spanish bathintro_09e766cb:

    # b "Ditch him."
    b "Deshacerme de él."

# game/scripts/scriptbath.rpy:193
translate spanish bathintro_8340ef54:

    # o "B-but why?!?! Sparky is so h-handsome and c-cool and t-tall!!"
    o "P-pero ¿por qué?!?! ¡¡Sparky es tan a-asombroso, guapó y alto!!"

# game/scripts/scriptbath.rpy:196
translate spanish bathintro_4f0a12fb:

    # b "Olive you think that about literally everyone, even if they're shorter than you!"
    b "Olive, piensas eso de literalmente todos, ¡incluso si son más bajos que tú!"

# game/scripts/scriptbath.rpy:198
translate spanish bathintro_ec7ccdb9:

    # b "Truth is he's been acting like such a FREAK lately!! I won't get into it though. If you wanna know just go talk to him!"
    b "¡¡La verdad es que últimamente ha estado actuando como un RARITO!! Aunque no profundizare en eso. ¡Si quieres saberlo, ve a hablar con él!"

# game/scripts/scriptbath.rpy:202
translate spanish bathintro_2182ba12:

    # a "Hmm... Maybe we'd better check on him..."
    a "Hmm... Quizás será mejor que vayamos a ver cómo está..."

# game/scripts/scriptbath.rpy:214
translate spanish bathintro_8511a4d0:

    # o "I'll go check on h-him!!"
    o "¡¡Iré a ver cómo está!!"

# game/scripts/scriptbath.rpy:261
translate spanish bathbrownie_b8b90cb7:

    # o "B-Brownie are you busy?"
    o "B-Brownie ¿estás ocupada?"

# game/scripts/scriptbath.rpy:264
translate spanish bathbrownie_e04989db:

    # b "Yes, very."
    b "Sí, mucho."

# game/scripts/scriptbath.rpy:266
translate spanish bathbrownie_7e1a9e19:

    # n "Brownie is leaning coolly against the bathroom sink doing absolutely nothing."
    n "Brownie está recostada fríamente contra el lavabo del baño sin hacer absolutamente nada."

# game/scripts/scriptbath.rpy:269
translate spanish bathbrownie_c27383b3:

    # o "W-would you b-be willing to take a break and come hang out with me?"
    o "¿Estarías dispuesta a tomar un descanso y venir a pasar el rato conmigo?"

# game/scripts/scriptbath.rpy:273
translate spanish bathbrownie_413bfadb:

    # n "Angel rolls his eyes."
    n "Angel pone los ojos en blanco."

# game/scripts/scriptbath.rpy:275
translate spanish bathbrownie_3e9f3e02:

    # o "W-would you b-be willing to take a break and come hang out with Angel and me?"
    o "¿Estarías dispuesta a tomar un descanso y venir a pasar el rato con Angel y conmigo?"

# game/scripts/scriptbath.rpy:280
translate spanish bathbrownie_32ba3df9:

    # n "Sparky looks at Brownie suspiciously."
    n "Sparky mira a Brownie sospechosamente."

# game/scripts/scriptbath.rpy:284
translate spanish bathbrownie_b8051c36:

    # n "Angel rolls his eyes and Sparky looks at Brownie suspiciously."
    n "Angel pone los ojos en blanco y Sparky mira a Brownie sospechosamente."

# game/scripts/scriptbath.rpy:289
translate spanish bathbrownie_20526e91:

    # o "W-would you b-be willing to take a break and help us talk to Coco?"
    o "¿E-estarías dispuesta a tomar un descanso y ayudarnos a hablar con Coco?"

# game/scripts/scriptbath.rpy:291
translate spanish bathbrownie_7d951410:

    # o "It'd be s-so helpful for Sparky if you could come!!"
    o "¡¡Sería muy útil para Sparky si pudieras venir!!"

# game/scripts/scriptbath.rpy:294
translate spanish bathbrownie_d77d5755:

    # n "Sparky sweats nervously."
    n "Sparky suda nerviosamente."

# game/scripts/scriptbath.rpy:296
translate spanish bathbrownie_2a267fd7:

    # b "Heh, I guess you could use an eye-witness!"
    b "¡Je, supongo que te vendría bien un testigo!"

# game/scripts/scriptbath.rpy:299
translate spanish bathbrownie_f9578a92:

    # b "But, Sparky, if you try ANYTHING I will break off both your legs and beat you to death with them!!"
    b "¡Pero, Sparky, si intentas ALGO, te romperé ambas piernas y te mataré a golpes con ellas!"

# game/scripts/scriptbath.rpy:300
translate spanish bathbrownie_afdbd14e:

    # b "And we all know you can't play your dumb sports without legs."
    b "Y todos sabemos que no puedes practicar deportes estupidos sin piernas."

# game/scripts/scriptbath.rpy:304
translate spanish bathbrownie_74f0858a:

    # o "This means you'll finally get to see Coco's r-room!!"
    o "¡¡Esto significa que finalmente podrás ver la habitación de Coco!!"

# game/scripts/scriptbath.rpy:305
translate spanish bathbrownie_b35a0463:

    # o "I saw a bit of it earlier! It's full of books and p-plants and Coco!"
    o "¡Vi un poco antes! ¡Está lleno de libros, p-plantas y Coco!"

# game/scripts/scriptbath.rpy:308
translate spanish bathbrownie_84b0eef6:

    # b "FUR REAL?! I'm so flippin' excited!!"
    b "¡¿DE VERDAD?! ¡¡Estoy tan emocionada!!"

# game/scripts/scriptbath.rpy:311
translate spanish bathbrownie_959ab58b:

    # o "This means we'll finally get to see Coco's bedroom!"
    o "¡Esto significa que finalmente podremos ver el dormitorio de Coco!"

# game/scripts/scriptbath.rpy:314
translate spanish bathbrownie_0926bd08:

    # b "YEAH! I'm so flippin' excited to see the real Coco!!"
    b "¡SÍ! ¡¡Estoy tan emocionada de ver a la verdadera Coco!!"

# game/scripts/scriptbath.rpy:319
translate spanish bathbrownie_6d94152a:

    # n "Olive and Brownie laugh and hug. Sparky shudders."
    n "Olive y Brownie se ríen y se abrazan. Sparky se estremece."

# game/scripts/scriptbath.rpy:323
translate spanish bathbrownie_35ca276d:

    # n "Olive and Brownie laugh and hug. Sparky shudders while Angel gives him an apologetic pat on the back."
    n "Olive y Brownie se ríen y se abrazan. Sparky se estremece mientras Angel le da una palmadita en la espalda a modo de disculpa."

# game/scripts/scriptbath.rpy:334
translate spanish bathbrownie_cca71538:

    # b "Heh, well I guess we can't get this party started without everyone together!"
    b "Je, bueno, ¡supongo que no podemos comenzar esta fiesta sin todos juntos!"

# game/scripts/scriptbath.rpy:336
translate spanish bathbrownie_9fe9bb11:

    # b "Just promise me you won't tell Sparky I ditched him!"
    b "¡Solo prométeme que no le dirás a Sparky que lo abandone!"

# game/scripts/scriptbath.rpy:339
translate spanish bathbrownie_21cba007:

    # o "Okie dokie!!"
    o "¡¡Okie dokie!!"

# game/scripts/scriptbath.rpy:354
translate spanish bathbrownie_3741fd5a:

    # n "Olive stares at Brownie while deciding whether or not they're brave enough to ask her out."
    n "Olive mira fijamente a Brownie mientras decide si es lo suficientemente valiente como para invitarla a salir del baño."

# game/scripts/scriptbath.rpy:361
translate spanish bathbrownie_85ef1e84:

    # n "Brownie gives them a wink."
    n "Brownie les guiña un ojo."

# game/scripts/scriptbath.rpy:377
translate spanish bathbath_3f76ae62:

    # o "No w-weapon here!"
    o "¡No hay armas aquí!"

# game/scripts/scriptbath.rpy:388
translate spanish bathbath_3f76ae62_1:

    # o "No w-weapon here!"
    o "¡No hay armas aquí!"

# game/scripts/scriptbath.rpy:391
translate spanish bathbath_ec3785c8:

    # c "Unless we want to drown him."
    c "A menos que queramos ahogarlo."

# game/scripts/scriptbath.rpy:394
translate spanish bathbath_4e746425:

    # o "D-D-DROWN HIM?!"
    o "¡¿A-A-AHOGARLO?!"

# game/scripts/scriptbath.rpy:396
translate spanish bathbath_ba814032:

    # o "W-with these w-widdle paws?"
    o "¿Con estas p-patitas?"

# game/scripts/scriptbath.rpy:398
translate spanish bathbath_5adeba87:

    # o "Ahahahah I think you're super talented Coco! Talented enough to think of something else!"
    o "¡Jajajaja creo que eres súper talentosa Coco! ¡Lo suficientemente talentosa como para pensar en otra cosa!"

# game/scripts/scriptbath.rpy:400
translate spanish bathbath_6a630ab6:

    # n "Olive is trembling."
    n "Olive está temblando."

# game/scripts/scriptbath.rpy:402
translate spanish bathbath_d19f855d:

    # c "..."
    c "..."

# game/scripts/scriptbath.rpy:405
translate spanish bathbath_1ef5d7fb:

    # c "You're right! I AM talented!"
    c "¡Tienes razón! ¡SOY talentosa!"

# game/scripts/scriptbath.rpy:407
translate spanish bathbath_69ea4a34:

    # c "Let's think of something else!"
    c "¡Pensemos en otra cosa!"

# game/scripts/scriptbath.rpy:419
translate spanish bathbath_c6876359:

    # n "Sparky is still too big for this tub!"
    n "¡Sparky todavía es demasiado grande para esta bañera!"

# game/scripts/scriptbath.rpy:433
translate spanish bathbath_90dfad1b:

    # o "Sparky! You might be too t-tall to fit in this tub!!"
    o "¡Sparky! ¡¡Quizás seas demasiado alto para caber en esta bañera!!"

# game/scripts/scriptbath.rpy:436
translate spanish bathbath_752322ea:

    # s "Heheh. I guess that'll happen when everything here is made for cats."
    s "Jejeje. Supongo que eso sucederá todo aquí esta hecho para gatos."

# game/scripts/scriptbath.rpy:439
translate spanish bathbath_18767666:

    # o "Oooh right! Your b-bathtub must be huge!!"
    o "¡Oh, cierto! ¡¡Tu b-bañera debe ser enorme!!"

# game/scripts/scriptbath.rpy:442
translate spanish bathbath_0f56d751:

    # s "Yeah but my family doesn't really use it. We just hose off in the yard."
    s "Sí, pero mi familia realmente no lo usa. Simplemente nos limpiamos con la manguera en el patio."

# game/scripts/scriptbath.rpy:448
translate spanish bathbath_5d41f1ff:

    # g "That sounds adorable!!"
    g "¡¡Eso suena adorable!!"

# game/scripts/scriptbath.rpy:450
translate spanish bathbath_63c36a67:

    # o "Dawww you guys sound cute."
    o "Dawww, ustedes suenan muy lindos."

# game/scripts/scriptbath.rpy:459
translate spanish bathbath_361d22d1:

    # n "The bathtub is drained."
    n "La bañera está vaciada."

# game/scripts/scriptbath.rpy:464
translate spanish bathbath_56bc34c3:

    # n "The bathtub is clogged."
    n "La bañera está atascada."

# game/scripts/scriptbath.rpy:475
translate spanish bathbath_d4dcb836:

    # n "Olive reaches into the cloudy bathwater to pull out whatever is plugging the drain."
    n "Olive mete la mano en el agua turbia del baño para sacar lo que sea que esté obstruyendo el desagüe."

# game/scripts/scriptbath.rpy:478
translate spanish bathbath_6fc84780:

    # b "This is weird even for you."
    b "Esto es extraño incluso para ti."

# game/scripts/scriptbath.rpy:483
translate spanish bathbath_00791bf3:

    # a "Olive... What are you doing...?"
    a "Olive... ¿Qué estás haciendo...?"

# game/scripts/scriptbath.rpy:487
translate spanish bathbath_7d59968a:

    # s "Olive! Careful, we don't know what's cloggin-"
    s "¡Olive! Cuidado, no sabemos qué está obstruyendola."

# game/scripts/scriptbath.rpy:491
translate spanish bathbath_5cc264a3:

    # o "AHHH!!" with vpunch
    o "¡¡AHHH!!" with vpunch

# game/scripts/scriptbath.rpy:497
translate spanish bathbath_a723b817:

    # s "OLIVE!!"
    s "¡¡OLIVE!!"

# game/scripts/scriptbath.rpy:500
translate spanish bathbath_36009da3:

    # n "Sparky grabs Olive's arm and rips it out of the water."
    n "Sparky agarra el brazo de Olive y lo saca del agua."

# game/scripts/scriptbath.rpy:502
translate spanish bathbath_fed84bf8:

    # n "Their paw is full of disgusting fur, sopping wet. The tub begins draining."
    n "Su pata está llena de un pelaje repugnante y empapado. La bañera comienza a drenarse."

# game/scripts/scriptbath.rpy:506
translate spanish bathbath_8afb01b6:

    # n "Brownie glances worriedly at Olive flailing in the disgusting bathwater."
    n "Brownie mira preocupada a Olive que se agita en el agua repugnante del baño."

# game/scripts/scriptbath.rpy:510
translate spanish bathbath_8b4f07ae:

    # n "She's relieved when Olive pulls their paw out, simply full of disgusting fur. The tub begins draining."
    n "Se siente aliviada cuando Olive saca la pata simplemente llena de pelaje repugnante. La bañera comienza a drenarse."

# game/scripts/scriptbath.rpy:515
translate spanish bathbath_adcc96b4:

    # b "AGH OLLY!!"
    b "¡¡AGH OLLY!!"

# game/scripts/scriptbath.rpy:519
translate spanish bathbath_a723b817_1:

    # s "OLIVE!!"
    s "¡¡OLIVE!!"

# game/scripts/scriptbath.rpy:522
translate spanish bathbath_5e6d5496:

    # n "Brownie pulls Olive's arm out of the drain."
    n "Brownie saca el brazo de Olive del desagüe."

# game/scripts/scriptbath.rpy:524
translate spanish bathbath_fed84bf8_1:

    # n "Their paw is full of disgusting fur, sopping wet. The tub begins draining."
    n "Su pata está llena de un pelaje repugnante y empapado. La bañera comienza a drenarse."

# game/scripts/scriptbath.rpy:527
translate spanish bathbath_d967c5f0:

    # n "Olive quickly pulls their arm out of the drain!"
    n "¡Olive rápidamente saca su brazo del desagüe!"

# game/scripts/scriptbath.rpy:529
translate spanish bathbath_fed84bf8_2:

    # n "Their paw is full of disgusting fur, sopping wet. The tub begins draining."
    n "Su pata está llena de un pelaje repugnante y empapado. La bañera comienza a drenarse."

# game/scripts/scriptbath.rpy:532
translate spanish bathbath_8b4e9ca2:

    # b "Oh, is that all?"
    b "¿Eso es todo?"

# game/scripts/scriptbath.rpy:536
translate spanish bathbath_f6d0e7a5:

    # o "Ahhh i-it's gross and sad. I can't stop thinking about how sad cats are when th-they take baths."
    o "Ahhh e-es asqueroso y triste. No puedo dejar de pensar en lo tristes que se ponen los gatos cuando se bañan."

# game/scripts/scriptbath.rpy:540
translate spanish bathbath_584e51a8:

    # b "AHAHA true. No wonder Coco's so uptight!"
    b "JAJAJA cierto. ¡Con razón Coco está tan tensa!"

# game/scripts/scriptbath.rpy:544
translate spanish bathbath_21d2d32c:

    # n "Sparky sighs in relief."
    n "Sparky suspira aliviado."

# game/scripts/scriptbath.rpy:548
translate spanish bathbath_ecf46674:

    # a "... That's more of a stereotype than anything..."
    a "... Eso es más un estereotipo que otra cosa..."

# game/scripts/scriptbath.rpy:552
translate spanish bathbath_ef318a44:

    # a "... I have no idea what possesses you to do these things..."
    a "... No tengo idea qué te posee para hacer estas cosas..."

# game/scripts/scriptbath.rpy:555
translate spanish bathbath_1a63308b:

    # a "But I suppose it's more entertaining than keeping guard downstairs..."
    a "Pero supongo que es más entretenido que hacer de perro guardian abajo..."

# game/scripts/scriptbath.rpy:558
translate spanish bathbath_a98e7b3e:

    # n "The tub drains revealing a key!"
    n "¡La bañera se drena revelando una llave!"

# game/scripts/scriptbath.rpy:565
translate spanish bathbath_a730b0cb:

    # s "A key! Great work Olive!!"
    s "¡Una llave! Gran trabajo Olive!!"

# game/scripts/scriptbath.rpy:577
translate spanish bathbath_aa5a2bcd:

    # b "WHOA a key?! Good job!"
    b "¡¿QUE es una llave?! ¡Buen trabajo!"

# game/scripts/scriptbath.rpy:587
translate spanish bathbath_071e8c00:

    # a "... It looks like one of Coco's keys... It should be useful."
    a "... Parece una de las llaves de Coco... Debería ser útil."

# game/scripts/scriptbath.rpy:598
translate spanish bathbath_c7dcd8ac:

    # o "A k-key!! I bet this'll be really handy!"
    o "¡¡Una l-llave!! ¡Apuesto a que esto será muy útil!"

# game/scripts/scriptbath.rpy:604
translate spanish bathbath_24477a21:

    # a "That's three keys... Let's hurry up and get to Coco's room!"
    a "Son tres llaves... ¡Démonos prisa y lleguemos a la habitación de Coco!"

# game/scripts/scriptbath.rpy:614
translate spanish bathbath_66613586:

    # o "Th-there might be s-s-something gross in there!"
    o "¡Podría haber algo asqueroso ahí dentro!"

# game/scripts/scriptbath.rpy:620
translate spanish bathbath_3f71fedb:

    # b "HEHE Olly you're such a weenie!"
    b "JEJE Olly, ¡eres un miedoso!"

# game/scripts/scriptbath.rpy:625
translate spanish bathbath_5b313554:

    # n "Brownie pinches Olive's cheeks. They're embarrassed."
    n "Brownie pellizca las mejillas de Olive. Están avergonzadas."

# game/scripts/scriptbath.rpy:638
translate spanish bathsink_928b2a0b:

    # n "Under the sink is a bunch of fur products, many marketed towards dalmatians."
    n "Debajo del fregadero hay un montón de productos de piel, muchos de ellos dirigidos a los dálmatas."

# game/scripts/scriptbath.rpy:645
translate spanish bathsink_928b2a0b_1:

    # n "Under the sink is a bunch of fur products, many marketed towards dalmatians."
    n "Debajo del fregadero hay un montón de productos de piel, muchos de ellos dirigidos a los dálmatas."

# game/scripts/scriptbath.rpy:647
translate spanish bathsink_bcc93eb3:

    # g "I've always wondered what Patches was like as a dalmatian."
    g "Siempre me he preguntado cómo era Patches como dálmata."

# game/scripts/scriptbath.rpy:649
translate spanish bathsink_3bf74eac:

    # g "Not that I care what kind of body he has!"
    g "¡No es que me importe qué tipo de cuerpo el tiene!"

# game/scripts/scriptbath.rpy:652
translate spanish bathsink_df713b92:

    # o "D-does he miss it? Being a d-dalmatian?"
    o "¿El lo extraña? ¿El ser un d-dálmata?"

# game/scripts/scriptbath.rpy:656
translate spanish bathsink_ab08e7e0:

    # g "I think he does... More than he lets on."
    g "Creo que sí... Más de lo que deja ver."

# game/scripts/scriptbath.rpy:660
translate spanish bathsink_ed9054b1:

    # s "Well, it's hard to feel bad for him after everything he's done."
    s "Bueno, es difícil sentirse mal por él después de todo lo que ha hecho."

# game/scripts/scriptbath.rpy:666
translate spanish bathsink_7d97b5a3:

    # n "Under the sink is a bunch of fur products."
    n "Debajo del fregadero hay un montón de productos de piel."

# game/scripts/scriptbath.rpy:670
translate spanish bathsink_26c5070a:

    # o "D-do you have any fur-cutting scissors?"
    o "¿Tienes alguna tijera para cortar pelaje?"

# game/scripts/scriptbath.rpy:674
translate spanish bathsink_e5c5f8e2:

    # c "WOW that'd be a great idea if we had any."
    c "WOW, sería una gran idea si tuviéramos alguna."

# game/scripts/scriptbath.rpy:676
translate spanish bathsink_fb5d7858:

    # c "Angel never cuts his damn fur and I shed a lot."
    c "Angel nunca se corta su maldito pelaje y yo perdí mucho."

# game/scripts/scriptbath.rpy:678
translate spanish bathsink_e02f4676:

    # c "Regardless, it's good to see you're capable of thinking with murderous intent!"
    c "De todos modos, ¡es bueno ver que eres capaz de pensar con intenciones asesinas!"

# game/scripts/scriptbath.rpy:681
translate spanish bathsink_a2217440:

    # o "I-I don't know. Maybe a fur cut would scare Patches away."
    o "N-no lo sé. Tal vez un corte de pelaje ahuyentaría a Patches."

# game/scripts/scriptbath.rpy:683
translate spanish bathsink_d7f37527:

    # o "I don't really kn-know how I'd use scissors to hurt someone."
    o "Realmente no sé cómo usaría las tijeras para lastimar a alguien."

# game/scripts/scriptbath.rpy:686
translate spanish bathsink_7828af32:

    # c "With the blade Olive!! STAB STAB STAB!"
    c "Con las cuchillas Olive!! ¡Una puñalada!"

# game/scripts/scriptbath.rpy:694
translate spanish bathsink_7d97b5a3_1:

    # n "Under the sink is a bunch of fur products."
    n "Debajo del fregadero hay un montón de productos de piel."

# game/scripts/scriptbath.rpy:698
translate spanish bathsink_050bb5b1:

    # c "What're we gonna do? Give him a bath?"
    c "¿Qué vamos a hacer? ¿Darle un baño?"

# game/scripts/scriptbath.rpy:701
translate spanish bathsink_0af9467c:

    # o "A B-B-BATH? WITH SPARKY?"
    o "¿UN B-B-BAÑO? ¿CON SPARKY?"

# game/scripts/scriptbath.rpy:704
translate spanish bathsink_1b3a6d26:

    # c "You know, day-dreaming about having a bath with Sparky will make it way harder to kill him!"
    c "Ya sabes, ¡soñar estando despierto sobre bañarte con Sparky hará que te sea mucho más difícil matarlo!"

# game/scripts/scriptbath.rpy:708
translate spanish bathsink_928b2a0b_2:

    # n "Under the sink is a bunch of fur products, many marketed towards dalmatians."
    n "Debajo del fregadero hay un montón de productos de piel, muchos de ellos dirigidos a los dálmatas."

# game/scripts/scriptbath.rpy:718
translate spanish bathsink_07d7379a:

    # n "Amidst the products is a small first aid kit!"
    n "¡En medio de los productos hay un pequeño botiquín de primeros auxilios!"

# game/scripts/scriptbath.rpy:720
translate spanish bathsink_f9c8a04d:

    # o "I w-wonder why she needs this. C-can't she just heal Angel and Brownie using magic?"
    o "Me pregunto por qué necesita esto. ¿No puede simplemente curar a Angel y Brownie usando magia?"

# game/scripts/scriptbath.rpy:723
translate spanish bathsink_54dc4162:

    # s "Oh right! I'm not sure what the extent of her abilities are."
    s "¡Ah, claro! No estoy seguro de cuál es el alcance de sus habilidades."

# game/scripts/scriptbath.rpy:724
translate spanish bathsink_ccfc67a7:

    # s "I guess, if she could heal she could've just healed Angel's body instead of giving him Patches'..."
    s "Supongo que si pudiera curar, podría haber curado el cuerpo de Angel en lugar de darle el de Patches..."

# game/scripts/scriptbath.rpy:727
translate spanish bathsink_07abc845:

    # o "..."
    o "..."

# game/scripts/scriptbath.rpy:729
translate spanish bathsink_f059523e:

    # s "Oh. Oh no."
    s "Oh. Oh, no."

# game/scripts/scriptbath.rpy:730
translate spanish bathsink_178088a5:

    # s "I-I don't think she can undo death... But she promised the zombies she'd fix their bodies!"
    s "N-no creo que pueda deshacer la muerte... ¡Pero les prometió a los zombies que arreglaría sus cuerpos!"

# game/scripts/scriptbath.rpy:733
translate spanish bathsink_df736784:

    # o "B-but, that means she's going to break her promise!! And they'll all be sad!!"
    o "¡¡P-pero eso significa que va a romper su promesa!! ¡¡Y todos estarán tristes!!"

# game/scripts/scriptbath.rpy:736
translate spanish bathsink_83ed4106:

    # s "I think they'll be more than just sad."
    s "Creo que estarán más que tristes."

# game/scripts/scriptbath.rpy:738
translate spanish bathsink_1e08be97:

    # s "We can't tell anyone about this, or else the zombies will freak out!!"
    s "¡¡No podemos contarle a nadie sobre esto, o los zombies se asustarán!!"

# game/scripts/scriptbath.rpy:741
translate spanish bathsink_8ddd7dcf:

    # o "Do you think th-them seeing the first aid kit... They'll g-get suspicious??"
    o "¿Crees que al ver el botiquín... sospecharán?"

# game/scripts/scriptbath.rpy:745
translate spanish bathsink_00bfb817:

    # n "As the two speak in hushed whispers, the bathroom door opens. A zombie peers in."
    n "Mientras los dos hablan en susurros, la puerta del baño se abre. Un zombi se asoma."

# game/scripts/scriptbath.rpy:747
translate spanish bathsink_5b1df227:

    # z "OoOoOH SORRY."
    z "OoOoOh lo siento."

# game/scripts/scriptbath.rpy:749
translate spanish bathsink_de4dc1a7:

    # z "WILL KNOoOCK NEeXT TIME."
    z "TOCARE LA PRÓXIMA VEZ."

# game/scripts/scriptbath.rpy:751
translate spanish bathsink_71215c0a:

    # z "NICE FIRST AaAaID KIT."
    z "BONITO BOTIQUIN."

# game/scripts/scriptbath.rpy:753
translate spanish bathsink_78f796c6:

    # n "The zombie slowly shambles away."
    n "El zombi se aleja lentamente."

# game/scripts/scriptbath.rpy:756
translate spanish bathsink_f8f688d8:

    # s "Huh. I guess we're okay."
    s "Eh. Supongo que estamos bien."

# game/scripts/scriptbath.rpy:764
translate spanish bathsink_de9ad468:

    # o "I guess Angel's trying to feel at home in his n-new body!"
    o "¡Supongo que Angel está tratando de sentirse como en casa en su n-nuevo cuerpo!"

# game/scripts/scriptbath.rpy:771
translate spanish bathsink_2d234069:

    # o "Aww Angel, are y-you trying to feel at home in your n-new body?"
    o "Aww Angel, ¿estás tratando de sentirte como en casa en tu n-nuevo cuerpo?"

# game/scripts/scriptbath.rpy:774
translate spanish bathsink_42d76105:

    # a "No... I just miss how fast my fur used to grow..."
    a "No... Sólo extraño lo rápido que solía crecer mi pelaje..."

# game/scripts/scriptbath.rpy:781
translate spanish bathsink_4f449ef5:

    # o "W-well I think you look nice no matter what kind of fur you have!!"
    o "¡¡B-bueno, creo que te ves bien sin importar el tipo de pelaje que tengas!!"

# game/scripts/scriptbath.rpy:785
translate spanish bathsink_22171b72:

    # n "Olive pets Angel's fur. He's very happy!"
    n "Olive acaricia el pelaje de Angel. ¡El está muy feliz!"

# game/scripts/scriptbath.rpy:796
translate spanish bathtoilet_b7e6f476:

    # n "It's a toilet."
    n "Es un baño."

# game/scripts/scriptbath.rpy:802
translate spanish bathtoilet_433fc7c1:

    # g "I hate toilets."
    g "Odio los baños."

# game/scripts/scriptbath.rpy:805
translate spanish bathtoilet_cd32b583:

    # o "ME T-TOO!"
    o "¡YO T-TAMBIÉN!"

# game/scripts/scriptbath.rpy:807
translate spanish bathtoilet_6b25906c:

    # o "They're s-so noisy!"
    o "¡Son tan ruidosos!"

# game/scripts/scriptbath.rpy:812
translate spanish bathtoilet_8e74a4a9:

    # g "... I was slowly cut in half by a demon cat while hiding in a lonely, disgusting bathroom stall."
    g "... Una gata demonio me cortó lentamente por la mitad mientras me escondía en un baño solitario y repugnante."

# game/scripts/scriptbath.rpy:813
translate spanish bathtoilet_2baa6513:

    # g "... I relive it everytime I close my eye."
    g "... Lo revivo cada vez que cierro mi ojo."

# game/scripts/scriptbath.rpy:816
translate spanish bathtoilet_28c185cd:

    # o "Oh! That's pretty b-bad too!"
    o "¡Oh! ¡Eso también es bastante m-malo!"

# game/scripts/scriptbath.rpy:825
translate spanish bathtoilet_49caa2e2:

    # c "We've got our weapon, let's get going!"
    c "¡Tenemos nuestra arma, vámonos!"

# game/scripts/scriptbath.rpy:831
translate spanish bathtoilet_db2c1766:

    # c "Aughh, how do we beat Patches with a toilet?!"
    c "Aughh, ¡¿cómo le ganamos a Patches con un inodoro?!"

# game/scripts/scriptbath.rpy:833
translate spanish bathtoilet_dd448a0e:

    # c "Oh wait!!"
    c "¡¡Ah espera!!"

# game/scripts/scriptbath.rpy:838
translate spanish bathtoilet_a00a3f02:

    # n "Coco lifts up the heavy ceramic toilet lid and shoves it into Olive's paws!"
    n "¡Coco levanta la pesada tapa de cerámica del inodoro y la pone en las patas de Olive!"

# game/scripts/scriptbath.rpy:840
translate spanish bathtoilet_c3853e29:

    # c "Try it out!"
    c "¡Pruébalo!"

# game/scripts/scriptbath.rpy:843
translate spanish bathtoilet_43bceaae:

    # n "Olive swings the toilet lid around like a very uncoordinated dog!"
    n "¡Olive mueve la tapa del inodoro como una perrita muy descoordinada!"

# game/scripts/scriptbath.rpy:846
translate spanish bathtoilet_91d44fc1:

    # c "Could you try and be a LITTLE more menacing with it?"
    c "¿Podrías intentar ser un POCO más amenazador con eso?"

# game/scripts/scriptbath.rpy:850
translate spanish bathtoilet_89625f65:

    # o "I-it's still pretty heavy."
    o "Todavía pesa bastante."

# game/scripts/scriptbath.rpy:853
translate spanish bathtoilet_23e5aa61:

    # c "Who cares! You can still wave it around, although you could try to be a LITTLE more menacing with it!"
    c "¡A quién le importa! Aún puedes agitarlo, ¡aunque podrías intentar ser un POCO más amenazador con él!"

# game/scripts/scriptbath.rpy:856
translate spanish bathtoilet_97e84ad1:

    # o "U-uhh."
    o "U-uhh."

# game/scripts/scriptbath.rpy:858
translate spanish bathtoilet_6124fc08:

    # o "Rrrr."
    o "Rrrr."

# game/scripts/scriptbath.rpy:862
translate spanish bathtoilet_9c825d60:

    # c "We'll work on that."
    c "Trabajaremos en eso."

# game/scripts/scriptbath.rpy:864
translate spanish bathtoilet_b4f4c392:

    # c "Let's get going!"
    c "¡Vamos!"

# game/scripts/scriptbath.rpy:867
translate spanish bathtoilet_855f9598:

    # c "Great, now let's find a weapon for me!"
    c "Genial, ¡ahora busquemos un arma para mí!"

# game/scripts/scriptbath.rpy:875
translate spanish bathtoilet_9d1be9f9:

    # n "The toilet's tank lid has been removed."
    n "Se ha quitado la tapa del tanque del inodoro."

# game/scripts/scriptbath.rpy:880
translate spanish bathtoilet_be49492d:

    # c "Aughh, how do we beat Sparky with a toilet?!"
    c "Aughh, ¡¿cómo le ganamos a Sparky con un inodoro?!"

# game/scripts/scriptbath.rpy:885
translate spanish bathtoilet_5d737c4e:

    # o "M-maybe we can scare him away with how loud the toilet is!!"
    o "¡¡Tal vez podamos asustarlo con lo ruidoso que es el baño!!"

# game/scripts/scriptbath.rpy:888
translate spanish bathtoilet_e69e42b8:

    # c "No."
    c "No."

# game/scripts/scriptbath.rpy:891
translate spanish bathtoilet_bece6f64:

    # o "Maybe we can pretend we're using it! Sparky's too polite to interrupt important b-business!"
    o "¡Quizás podamos fingir que lo estamos usando! ¡Sparky es demasiado educado para interrumpir negocios  i-importantes!"

# game/scripts/scriptbath.rpy:894
translate spanish bathtoilet_e69e42b8_1:

    # c "No."
    c "No."

# game/scripts/scriptbath.rpy:897
translate spanish bathtoilet_f3cb3eba:

    # o "Maybe we can show him how gross and spooky the inside of the t-toilet t-tank is!"
    o "¡Quizás podamos mostrarle lo asqueroso y espeluznante que es el interior del tanque del inodoro!"

# game/scripts/scriptbath.rpy:900
translate spanish bathtoilet_106f85cf:

    # c "NO-"
    c "NO-"

# game/scripts/scriptbath.rpy:903
translate spanish bathtoilet_d17048fc:

    # c "Wait... That's perfect!!"
    c "Espera... ¡¡Eso es perfecto!!"

# game/scripts/scriptbath.rpy:905
translate spanish bathtoilet_83d6aa4f:

    # n "Coco lifts the lid off the tank of the toilet!"
    n "¡Coco levanta la tapa del tanque del inodoro!"

# game/scripts/scriptbath.rpy:908
translate spanish bathtoilet_77e6de2c:

    # n "It's heavy and ceramic."
    n "Es pesado y cerámico."

# game/scripts/scriptbath.rpy:912
translate spanish bathtoilet_2fef3562:

    # c "This'll knock him out! Maybe it'll do even more..."
    c "¡Esto lo noqueará! Tal vez haga aún más..."

# game/scripts/scriptbath.rpy:915
translate spanish bathtoilet_11eaa384:

    # o "W-W-WHAT?!"
    o "¡¿Q-Q-QUÉ?!"

# game/scripts/scriptbath.rpy:919
translate spanish bathtoilet_93be74a1:

    # n "A loud crash is heard through the bathroom door!" with vpunch
    n "¡Se oye un fuerte estruendo a través de la puerta del baño!" with vpunch

# game/scripts/scriptbath.rpy:921
translate spanish bathtoilet_506fdf19:

    # o "AHH!"
    o "¡AHH!"

# game/scripts/scriptbath.rpy:924
translate spanish bathtoilet_0a92c015:

    # c "That must be him!! LET'S GO!"
    c "¡¡Ese debe ser él!! ¡VAMOS!"

# game/scripts/scriptbath.rpy:931
translate spanish bathtoilet_49879f42:

    # o "I d-don't know. Let's keep looking!"
    o "No lo sé. ¡Sigamos buscando!"

# game/scripts/scriptbath.rpy:939
translate spanish bathtoilet_e8448e29:

    # n "Olive blocks Sparky from grabbing the toilet handle."
    n "Olive impide que Sparky agarre la manija del inodoro."

# game/scripts/scriptbath.rpy:941
translate spanish bathtoilet_289db982:

    # o "It's too loud Sparky!!"
    o "¡¡Es demasiado ruidoso, Sparky!!"

# game/scripts/scriptbath.rpy:949
translate spanish bathtoilet_0651bd1f:

    # n "Olive blocks Brownie from grabbing the toilet handle."
    n "Olive impide que Brownie agarre la manija del inodoro."

# game/scripts/scriptbath.rpy:951
translate spanish bathtoilet_93f87b43:

    # o "It's too loud Brownie!!"
    o "¡¡Es demasiado ruidoso, Brownie!!"

# game/scripts/scriptbath.rpy:957
translate spanish bathtoilet_67ddd686:

    # o "Toilets are l-loud and scary."
    o "Los baños son ruidosos y dan miedo."

# game/scripts/scriptbath.rpy:962
translate spanish bathtoilet_67ddd686_1:

    # o "Toilets are l-loud and scary."
    o "Los baños son ruidosos y dan miedo."

# game/scripts/scriptbath.rpy:968
translate spanish bathtoilet_7dd45c5d:

    # s "Aww Olive they're not so bad! You just need to get used to it!"
    s "¡Aww Olive, no son tan malos! ¡Solo necesitas acostumbrarte!"

# game/scripts/scriptbath.rpy:970
translate spanish bathtoilet_70365107:

    # n "Sparky reaches for the toilet handle."
    n "Sparky alcanza la manija del inodoro."

# game/scripts/scriptbath.rpy:972
translate spanish bathtoilet_89305fe4:

    # o "NO!!"
    o "¡¡NO!!"

# game/scripts/scriptbath.rpy:978
translate spanish bathtoilet_b81f21d6:

    # n "Olive slaps his paw away!" with vpunch
    n "¡Olive le da una palmada en la pata!" with vpunch

# game/scripts/scriptbath.rpy:987
translate spanish bathtoilet_7d7ce969:

    # a "All I can hope is that in some alternate universe, cats have found a quieter way to conduct their business."
    a "Todo lo que puedo esperar es que en algún universo alternativo los gatos hayan encontrado una forma más silenciosa de realizar sus actividades."

# game/scripts/scriptbath.rpy:994
translate spanish bathtoilet_4980c762:

    # b "Oh really?"
    b "¿Ah, de verdad?"

# game/scripts/scriptbath.rpy:1002
translate spanish bathtoilet_a7e59966:

    # n "Brownie flushes the toilet a billion times in a row!"
    n "¡Brownie tira la cadena millones de veces seguidas!"

# game/scripts/scriptbath.rpy:1004
translate spanish bathtoilet_c2a055dc:

    # o "AHH NO!"
    o "¡AHH NO!"

# game/scripts/scriptbath.rpy:1008
translate spanish bathtoilet_b745cb04:

    # b "BWAHAHAH!!"
    b "¡¡BWAHAHAH!!"

# game/scripts/scriptbath.rpy:1012
translate spanish bathtoilet_da5daf64:

    # a "The water bill..."
    a "El recibo del agua..."

# game/scripts/scriptbath.rpy:1015
translate spanish bathtoilet_8050bc64:

    # s "Brownie! That's wasteful!"
    s "¡Brownie! ¡Eso es un desperdicio!"

# game/scripts/scriptbath.rpy:1026
translate spanish needtogo_82a35251:

    # c "WE NEED TO GO OLIVE! Angel and Brownie are in trouble!"
    c "¡NECESITAMOS IRNOS OLIVE! ¡Angel y Brownie están en problemas!"

# game/scripts/scriptbath.rpy:1037
translate spanish gameover05_9086f929:

    # n "Olive gives Brownie a big hug!!"
    n "Olive le da un fuerte abrazo a Brownie!!"

# game/scripts/scriptbath.rpy:1039
translate spanish gameover05_4f017c5f:

    # b "OLLY!! YOU'RE GOING TO MAKE ME CRY MORE!!"
    b "¡¡OLLY!! ¡¡ME VAS A HACER LLORAR MÁS!!"

# game/scripts/scriptbath.rpy:1042
translate spanish gameover05_1200fb51:

    # o "I'm s-sorry!!"
    o "¡¡Lo-lo siento!!"

# game/scripts/scriptbath.rpy:1046
translate spanish gameover05_51cfa201:

    # o "You might just be my last friend a-alive..."
    o "Podrías ser mi última amiga v-viva..."

# game/scripts/scriptbath.rpy:1049
translate spanish gameover05_f41cdfb9:

    # o "And I think you're really cool!"
    o "¡Y creo que eres realmente genial!"

# game/scripts/scriptbath.rpy:1053
translate spanish gameover05_7998593a:

    # o "And I like your sweater a lot."
    o "Y me gusta mucho tu suéter."

# game/scripts/scriptbath.rpy:1056
translate spanish gameover05_99c487c4:

    # b "Pfft, you really do make everything better Olive."
    b "Pfft, realmente haces que todo sea mejor, Olive."

# game/scripts/scriptbath.rpy:1059
translate spanish gameover05_352379e5:

    # n "Brownie gives Olive a little peck on the cheek."
    n "Brownie le da a Olive un pequeño beso en la mejilla."

# game/scripts/scriptbath.rpy:1063
translate spanish gameover05_951e687d:

    # n "The door breaks down!" with vpunch
    n "¡La puerta se rompe!" with vpunch

# game/scripts/scriptbath.rpy:1067
translate spanish gameover05_fb3845c4:

    # n "Zombies flood into the bathroom taking no time to find Olive and Brownie." with vpunch
    n "Los zombies invaden el baño y no tardan en encontrar a Olive y Brownie." with vpunch

# game/scripts/scriptbath.rpy:1089
translate spanish gameover05_d421d533:

    # n "Olive and Brownie sit in the bathtub together."
    n "Olive y Brownie se sientan juntas en la bañera."

# game/scripts/scriptbath.rpy:1090
translate spanish gameover05_63566d05:

    # n "They tentatively hold paws."
    n "Tentativamente se sostienen de las patas."

# game/scripts/scriptbath.rpy:1092
translate spanish gameover05_b6cb0bd8:

    # b "Thanks Olly, I'm glad I'm not alone."
    b "Gracias Olly, me alegro de no estar sola."

# game/scripts/scriptbath.rpy:1095
translate spanish gameover05_ff33629c:

    # o "Yeah..."
    o "Sí..."

# game/scripts/scriptbath.rpy:1098
translate spanish gameover05_449299a2:

    # b "Weird, I think I just got deja vu."
    b "Qué raro, creo que acabo de tener un deja vu."

# game/scripts/scriptbath.rpy:1102
translate spanish gameover05_951e687d_1:

    # n "The door breaks down!" with vpunch
    n "¡La puerta se rompe!" with vpunch

# game/scripts/scriptbath.rpy:1106
translate spanish gameover05_d9c1623d:

    # n "Zombies flood into the bathroom, taking no time to find Olive and Brownie." with vpunch
    n "Los zombies invaden el baño y no tardan en encontrar a Olive y Brownie." with vpunch

translate spanish strings:

    # game/scripts/scriptbath.rpy:228
    old "{color=#ff9da6}Talk to Brownie.{/color}"
    new "{color=#ff9da6}Hablar con Brownie.{/color}"

    # game/scripts/scriptbath.rpy:228
    old "{color=#ff9da6}Inspect bathtub.{/color}"
    new "{color=#ff9da6}Inspeccionar la bañera.{/color}"

    # game/scripts/scriptbath.rpy:228
    old "{color=#ff9da6}Look under sink.{/color}"
    new "{color=#ff9da6}Mire debajo del fregadero.{/color}"

    # game/scripts/scriptbath.rpy:228
    old "{color=#ff9da6}Inspect toilet.{/color}"
    new "{color=#ff9da6}Inspeccionar el baño.{/color}"

    # game/scripts/scriptbath.rpy:228
    old "{color=#ffc1ed}Leave.{/color}"
    new "{color=#ffc1ed}Salir.{/color}"

    # game/scripts/scriptbath.rpy:250
    old "Ask Brownie out."
    new "Invitarla a salir del baño."

    # game/scripts/scriptbath.rpy:250
    old "Leave Brownie alone."
    new "Dejar a Brownie en paz."

    # game/scripts/scriptbath.rpy:465
    old "Unclog drain."
    new "Desatascar el drenaje."

    # game/scripts/scriptbath.rpy:465
    old "Leave it."
    new "Déjalo."

    # game/scripts/scriptbath.rpy:882
    old "Suggest ideas."
    new "Sugerir ideas."

    # game/scripts/scriptbath.rpy:882
    old "Keep searching."
    new "Seguir buscando."

    # game/scripts/scriptbath.rpy:1031
    old "Give her a hug."
    new "Darle un abrazo."

    # game/scripts/scriptbath.rpy:1031
    old "{color=#ffffff66}Give her a hug.{/color}"
    new "{color=#ffffff66}Dale un abrazo.{/color}"

    # game/scripts/scriptbath.rpy:1031
    old "{color=#ffffff66}Hold her paw.{/color}"
    new "{color=#ffffff66}Sosténer su pata.{/color}"

    # game/scripts/scriptbath.rpy:1031
    old "Hold her paw."
    new "Sosténer su pata."

