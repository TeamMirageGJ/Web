﻿# TODO: Translation updated at 2024-11-25 12:57

# game/scripts/scriptliving.rpy:25
translate spanish livingintro_c8ea8a4a:

    # p "..."
    p "..."

# game/scripts/scriptliving.rpy:27
translate spanish livingintro_c3ccd053:

    # b "I-is he dead?"
    b "¿E-está muerto?"

# game/scripts/scriptliving.rpy:30
translate spanish livingintro_253b094a:

    # a "... Does dead even mean anything anymore?"
    a "... ¿Acaso la muerte significa algo a este punto?"

# game/scripts/scriptliving.rpy:34
translate spanish livingintro_30472d86:

    # n "Patches wakes up gasping for air!" with vpunch
    n "¡Patches se despierta buscando aire desesperadamente!" with vpunch

# game/scripts/scriptliving.rpy:35
translate spanish livingintro_d648f9c8:

    # p "Olive?!"
    p "¡¿Olive?!"

# game/scripts/scriptliving.rpy:38
translate spanish livingintro_78ca18e3:

    # o "Patches!!"
    o "¡¡Patches!!"

# game/scripts/scriptliving.rpy:39
translate spanish livingintro_fea77653:

    # o "Isn't this s-so exciting?! With Ginger's magic we stitched up your body!"
    o "¡¿No es esto tan emocionante?! ¡Con la magia de Ginger cosimos tu cuerpo!"

# game/scripts/scriptliving.rpy:40
translate spanish livingintro_f4054061:

    # o "We even gave you some of Angel's old clothes!!"
    o "¡¡Incluso te regalamos algo de ropa vieja de Angel!!"

# game/scripts/scriptliving.rpy:43
translate spanish livingintro_48238eaa:

    # a "No need to return it, I'd have to burn it..."
    a "No hace falta que la devuelvas, tendría que quemarla..."

# game/scripts/scriptliving.rpy:47
translate spanish livingintro_c508c72d:

    # b "Pfft nice one."
    b "Pfff, buena broma."

# game/scripts/scriptliving.rpy:51
translate spanish livingintro_fc10aa9c:

    # n "Brownie gives Angel a high five."
    n "Brownie choca los cinco con Angel."

# game/scripts/scriptliving.rpy:54
translate spanish livingintro_e572310d:

    # o "RUDE!"
    o "¡QUE GROSEROS!"

# game/scripts/scriptliving.rpy:57
translate spanish livingintro_08204456:

    # p "What the f-"
    p "¿Qué carajos?"

# game/scripts/scriptliving.rpy:60
translate spanish livingintro_c26cc9fb:

    # n "Patches tries to sit up but something jerks his neck back." with vpunch
    n "Patches intenta sentarse pero algo le tira el cuello." with vpunch

# game/scripts/scriptliving.rpy:63
translate spanish livingintro_fbc77261:

    # p "What. WHAT THE HELL IS THIS?!"
    p "Qué. ¡¿QUÉ MIERDA ES ESTO?!"

# game/scripts/scriptliving.rpy:65
translate spanish livingintro_ba13e51d:

    # n "Patches throws a fit!" with vpunch
    n "¡Patches se pone furioso!" with vpunch

# game/scripts/scriptliving.rpy:66
translate spanish livingintro_c4b9b7ed:

    # n "He's trying to tear off the collar!" with vpunch
    n "¡El esta intentando arrancarse el collar!" with vpunch

# game/scripts/scriptliving.rpy:67
translate spanish livingintro_8047d216:

    # n "Though his teeth and claws are sharp it does little against the strange glowing chains." with vpunch
    n "Aunque sus dientes y garras son afilados, no hacen mucho contra las cadenas brillantes." with vpunch

# game/scripts/scriptliving.rpy:69
translate spanish livingintro_171c32a8:

    # o "Coco g-g-gave me a magic leash!!"
    o "¡Coco me d-d-dio una correa mágica!"

# game/scripts/scriptliving.rpy:70
translate spanish livingintro_5dff3857:

    # o "It's supposed to keep you from doing evil things!"
    o "¡Se supone que te impedirá hacer cosas malas!"

# game/scripts/scriptliving.rpy:71
translate spanish livingintro_eff8b6e9:

    # o "Y-you only have to wear it until everyone's convinced you're a good b-boy!"
    o "¡Solo tienes que usarlo hasta que todos estén convencidos de que eres un buen p-perro!"

# game/scripts/scriptliving.rpy:73
translate spanish livingintro_194a9714:

    # o "W-which shouldn't take long r-right? I know you're a good b-boy deep down inside!"
    o "¿Lo cual no debería tomar mucho tiempo c-cierto? ¡Sé que en el fondo eres un buen p-perrete!"

# game/scripts/scriptliving.rpy:76
translate spanish livingintro_8d2735bd:

    # p "Oh my Dog. A leash?! REALLY?!"
    p "Por todos los perros... ¡¿Una correa?! ¡¿ENSERIO?!"

# game/scripts/scriptliving.rpy:78
translate spanish livingintro_b9f48204:

    # p "Do you have any idea how demeaning this is?!"
    p "¿Tienen idea de lo humillante que es esto?"

# game/scripts/scriptliving.rpy:81
translate spanish livingintro_872315b1:

    # o "But th-this was the only way th-they'd let you come back with me!"
    o "¡Pero e-esa era la única manera en que te dejarían volver c-conmigo!"

# game/scripts/scriptliving.rpy:84
translate spanish livingintro_4e80b3cf:

    # a "Heh... It's a good look on you Patches."
    a "Je... Te queda bien, Patches."

# game/scripts/scriptliving.rpy:87
translate spanish livingintro_b8bb8167:

    # p "And YOU!"
    p "¡TU!"

# game/scripts/scriptliving.rpy:88
translate spanish livingintro_bf664d67:

    # p "So what?! Does Angel own my body now?"
    p "¡¿Entonces que?! ¿Angel es el dueño de mi cuerpo ahora?"

# game/scripts/scriptliving.rpy:89
translate spanish livingintro_9a1de808:

    # p "Why do I have to be in stuck this inferior twink's body?!"
    p "¡¿Por qué tengo que estar atrapado en el cuerpo de este jovencito inferior?!"

# game/scripts/scriptliving.rpy:92
translate spanish livingintro_bae0a6d7:

    # a "I-inferior twink?"
    a "¿Jovencito i-inferior?"

# game/scripts/scriptliving.rpy:99
translate spanish livingintro_731a7dc1:

    # c "Look buddy we're doing you a HUUUGE favor!"
    c "¡Mira amigo, te estamos haciendo un ENOOORME favor!"

# game/scripts/scriptliving.rpy:100
translate spanish livingintro_da17795b:

    # c "Maybe you can have your body back once you've proven that you're a, uhh, ''good boy''."
    c "Tal vez puedas recuperar tu cuerpo una vez que hayas demostrado que eres un, emm, ''un buen perro''."

# game/scripts/scriptliving.rpy:104
translate spanish livingintro_75be6c74:

    # c "For now though you're stuck in Angel's inferior twink body."
    c "Pero por ahora estás atrapado en el cuerpo de jovencito inferior de Angel."

# game/scripts/scriptliving.rpy:105
translate spanish livingintro_d0343d0b:

    # c "It's far easier to stop if it goes on a killing spree."
    c "Será mucho más fácil frenarte si intentas matarnos a todos."

# game/scripts/scriptliving.rpy:108
translate spanish livingintro_240c863c:

    # a "S-stop talking about my body like that!"
    a "¡Deja de hablar así de mi cuerpo!"

# game/scripts/scriptliving.rpy:111
translate spanish livingintro_8e312495:

    # p "Wait. What do I have to do to prove I'm good?!"
    p "Esperen. ¡¿Qué tengo que hacer para demostrar que soy un perro bueno?!"

# game/scripts/scriptliving.rpy:118
translate spanish livingintro_9203ba7f:

    # b "Uhh don't manipulate anyone, don't stab anyone and don't kill anyone."
    b "Uhh no manipules a nadie, no apuñales a nadie y no mates a nadie."

# game/scripts/scriptliving.rpy:121
translate spanish livingintro_b3106d91:

    # b "Olive's got you on a tight leash 24/7 just to make sure too!"
    b "¡Olive te tiene bajo control las 24 horas del día, los 7 días de la semana, para asegurarnos!"

# game/scripts/scriptliving.rpy:124
translate spanish livingintro_c13028d9:

    # p "WHAT."
    p "QUÉ."

# game/scripts/scriptliving.rpy:127
translate spanish livingintro_49ddea28:

    # o "W-w-we're gonna be b-best friends!!"
    o "¡¡V-v-vamos a ser m-mejores amigos!!"

# game/scripts/scriptliving.rpy:130
translate spanish livingintro_7e331014:

    # n "Olive gives Patches a BIG hug! He's stunned."
    n "¡Olive le da un GRAN abrazo a Patches! Está atónito."

# game/scripts/scriptliving.rpy:132
translate spanish livingintro_0ba692fd:

    # o "THIS IS THE BEST SURPRISE BIRTHDAY PARTY EVER!"
    o "¡ESTA ES LA MEJOR FIESTA DE CUMPLEAÑOS!"

# game/scripts/scriptliving.rpy:135
translate spanish livingintro_a9eb27f9:

    # p "I'm going to kill you all in your sleep!"
    p "¡Los mataré a todos mientras duermen!"

# game/scripts/scriptliving.rpy:139
translate spanish livingintro_6964ced6:

    # n "Everyone laughs wildly at Patches' predicament."
    n "Todos se ríen salvajemente por la situación de Patches."

# game/scripts/scriptliving.rpy:155
translate spanish livingintro_90bc693b:

    # n "Coco jumps onto the living room table, knocking a bunch of plates over and threatening to ruin the lovely birthday cake." with vpunch
    n "Coco salta a la mesa de la sala, tirando un montón de platos y amenazando con arruinar el delicioso pastel de cumpleaños." with vpunch

# game/scripts/scriptliving.rpy:157
translate spanish livingintro_531a78c9:

    # c "ALRIGHT ZOMBOS. HERE'S THE PLAN IF YOU WANT YOUR, uhh,"
    c "MUY BIEN ZOMBOS. AQUÍ ESTÁ EL PLAN SI QUIEREN SUS, uhh,"

# game/scripts/scriptliving.rpy:158
translate spanish livingintro_54d7c6f0:

    # c "YOUR BODIES HEALED AND YOUR LIVES BACK!"
    c "¡SUS CUERPOS SANADOS Y VUESTRAS VIDAS DE VUELTA!"

# game/scripts/scriptliving.rpy:163
translate spanish livingintro_818ec935:

    # z "BOoOoDIES??"
    z "¿¿CUeRrRpoS??"

# game/scripts/scriptliving.rpy:166
translate spanish livingintro_802d386d:

    # n "The zombies gather around, moaning and shambling less violently than before."
    n "Los zombis se reúnen alrededor, gimiendo y deambulando con menos violencia que antes."

# game/scripts/scriptliving.rpy:168
translate spanish livingintro_4ab535c3:

    # c "Your so called saviors Patches and whatsername,"
    c "Su supuesto patches salvador y como se llame,"

# game/scripts/scriptliving.rpy:171
translate spanish livingintro_1b9321b6:

    # o "I-I think it was Ginger!"
    o "¡Creo que es Ginger!"

# game/scripts/scriptliving.rpy:174
translate spanish livingintro_9ab4ef3d:

    # c "PATCHES AND GINGER have betrayed you!!!"
    c "¡¡¡PATCHES Y GINGER los han traicionado!!!"

# game/scripts/scriptliving.rpy:175
translate spanish livingintro_df160f30:

    # c "They're going to attack at any moment to try and wipe every single one of us out,"
    c "Van a atacar en cualquier momento para intentar eliminarnos a todos y cada uno de nosotros."

# game/scripts/scriptliving.rpy:177
translate spanish livingintro_8e5e88ba:

    # c "But only because together we're strong enough to take them down!"
    c "¡Pero juntos somos lo suficientemente fuertes para acabar con ellos!"

# game/scripts/scriptliving.rpy:179
translate spanish livingintro_6e046219:

    # c "So fan out and keep an eye out for em! If you find them let me know and I'll take care of the rest!"
    c "¡Dispérsense y manténganse alerta! ¡Si los encuentran avísenme y yo me encargaré del resto!"

# game/scripts/scriptliving.rpy:181
translate spanish livingintro_3ceaf8ce:

    # c "Understood?"
    c "¿Comprendido?"

# game/scripts/scriptliving.rpy:184
translate spanish livingintro_6a112f44:

    # z "BOoOoDdIEeEeS!!"
    z "¡¡CueRPoOos!!"

# game/scripts/scriptliving.rpy:186
translate spanish livingintro_986d545c:

    # z "FUuUuRIENDS!!"
    z "¡¡AmIiIGoS!!"

# game/scripts/scriptliving.rpy:191
translate spanish livingintro_678e9807:

    # n "The zombies slowly make their way out of the living room, permeating every area of the estate."
    n "Los zombis salen lentamente de la sala de estar, impregnando cada área de la finca."

# game/scripts/scriptliving.rpy:193
translate spanish livingintro_c4b10250:

    # c "Ugh it's going to take forever to get the smell of dead dog out of this house."
    c "Uf, va a tomar una eternidad sacar el olor a perro muerto de esta casa."

# game/scripts/scriptliving.rpy:199
translate spanish livingintro_cc5a1e9c:

    # s "Wait, so what are WE going to do?!"
    s "Espera, entonces, ¿qué vamos a hacer?"

# game/scripts/scriptliving.rpy:203
translate spanish livingintro_fb427cf1:

    # c "We're going to sit the hell down and wait for them to find Patches and Ginger."
    c "Nos sentaremos y esperaremos a que encuentren a Patches y Ginger."

# game/scripts/scriptliving.rpy:206
translate spanish livingintro_5a9b8906:

    # s "B-but I want to help!!"
    s "¡¡P-pero quiero ayudar!!"

# game/scripts/scriptliving.rpy:209
translate spanish livingintro_01b42ae5:

    # c "Who's going to do a better job of finding them? One living dog or a thousand dead ones?"
    c "¿Quién hará un mejor trabajo para encontrarlos? ¿Un perro vivo o mil muertos?"

# game/scripts/scriptliving.rpy:212
translate spanish livingintro_3d001c39:

    # s "I m-mean, I like to think I'm a lot smarter than a bunch of rotting corpses."
    s "Q-quiero decir, me gusta pensar que soy mucho más inteligente que un montón de cadáveres en descomposición."

# game/scripts/scriptliving.rpy:215
translate spanish livingintro_636a450d:

    # c "UUUUUGH okay okay. If you really want to help go get me a first aid kit from the bathroom upstairs."
    c "UUUUUGH está bien, está bien. Si realmente quieres ayudar, ve a buscar un botiquín de primeros auxilios al baño de arriba."

# game/scripts/scriptliving.rpy:218
translate spanish livingintro_387c0c71:

    # s "Okay!!"
    s "¡¡Ok!!"

# game/scripts/scriptliving.rpy:222
translate spanish livingintro_504ea445:

    # c "OH and Olive, you watch him! Make sure he doesn't do anything stupid or get himself possessed again."
    c "¡OH y Olive, vigilalo! Asegúrate de que no haga nada estúpido ni se deje poseer nuevamente."

# game/scripts/scriptliving.rpy:225
translate spanish livingintro_0908c727:

    # o "O-okie dokie!!"
    o "¡¡O-okie dokie!!"

# game/scripts/scriptliving.rpy:245
translate spanish livingintro_8d44a326:

    # n "The crowd of zombies has dissipated. They appear to be streaming through the front door."
    n "La horda de zombis se ha dispersado. Se les ve salir en masa por la puerta del frente."

# game/scripts/scriptliving.rpy:246
translate spanish livingintro_ca2ba2eb:

    # n "Looks like Coco's plan is working!"
    n "¡Parece que el plan de Coco está funcionando!"

# game/scripts/scriptliving.rpy:248
translate spanish livingintro_314d533c:

    # n "Olive runs upstairs, tripping a few times. Luckily no one was alive to see." with vpunch
    n "Olive sube corriendo las escaleras, tropezando un par de veces. Por suerte, nadie estaba vivo para verla." with vpunch

# game/scripts/scriptliving.rpy:259
translate spanish livingintro_1ae400be:

    # n "Shredded up zombies are strewn about, likely from Patches' earlier tantrum."
    n "Hay restos de zombis esparcidos por doquier, seguramente por el ataque de ira de Patches."

# game/scripts/scriptliving.rpy:260
translate spanish livingintro_5cf97881:

    # n "The ones that are able to move don't seem to want to hurt Coco or Olive. They're just mingling and looking at Olive's birthday cake."
    n "Los que pueden moverse no parecen querer lastimar a Coco u Olive. Simplemente están socializando y mirando el pastel de cumpleaños."

# game/scripts/scriptliving.rpy:263
translate spanish livingintro_ce0054c5:

    # c "What on earth was in that meat?!"
    c "¡¿Qué diablos había en esa carne?!"

# game/scripts/scriptliving.rpy:266
translate spanish livingintro_88b43345:

    # o "It's just really yummy!!"
    o "¡¡Es realmente deliciosa!!"

# game/scripts/scriptliving.rpy:274
translate spanish livingintro_05b67e82:

    # o "WOW! It's so nice in here! I wonder w-where everybody is!"
    o "¡GUAU! ¡Es tan lindo aquí! ¡Me pregunto dónde están todos!"

# game/scripts/scriptliving.rpy:288
translate spanish livingintro_ece75cf2:

    # n "The front door has been opened!"
    n "¡la puerta de la entrada se ha abierto!"

# game/scripts/scriptliving.rpy:290
translate spanish livingintro_340d8a6b:

    # n "The zombies notice Olive and Coco and slowly shamble towards them."
    n "Los zombies notan a Olive y Coco y lentamente avanzan hacia ellas."

# game/scripts/scriptliving.rpy:292
translate spanish livingintro_4073ebed:

    # c "DAMMIT!! Why now?!"
    c "¡¡MIERDA!! ¡¿Por qué ahora?!"

# game/scripts/scriptliving.rpy:293
translate spanish livingintro_f794fa2a:

    # c "Come on we need to go!!"
    c "¡¡Vamos, tenemos que irnos!!"

# game/scripts/scriptliving.rpy:297
translate spanish livingintro_00ab9c97:

    # n "Coco grabs Olive's paw and runs to the kitchen!"
    n "¡Coco agarra la pata de Olive y corre hacia la cocina!"

# game/scripts/scriptliving.rpy:318
translate spanish livingmenuinteract_2fe5b17d:

    # c "LET'S GO OLIVE!!"
    c "¡¡VAMOS OLIVE!!"

# game/scripts/scriptliving.rpy:328
translate spanish livingmenuinteract_225d0b35:

    # n "The cushions are covered in loose feathers."
    n "Los cojines están cubiertos de plumas."

# game/scripts/scriptliving.rpy:338
translate spanish livingmenuinteract_23f274ae:

    # n "Coco grabs a cushion and whips it at Olive's face!" with vpunch
    n "¡Coco agarra un cojín y lo lanza hacia la cara de Olive!" with vpunch

# game/scripts/scriptliving.rpy:339
translate spanish livingmenuinteract_c3969891:

    # n "Feathers fly everywhere."
    n "Las plumas vuelan por todas partes."

# game/scripts/scriptliving.rpy:341
translate spanish livingmenuinteract_ad10498e:

    # c "WE NEED TO GO!!"
    c "¡¡TENEMOS QUE IRNOS!!"

# game/scripts/scriptliving.rpy:345
translate spanish livingmenuinteract_9e692821:

    # z "PILLOoOoOoW FIGHT?"
    z "¿PELEA DE ALMOHADAaAaAaS?"

# game/scripts/scriptliving.rpy:348
translate spanish livingmenuinteract_68a741e3:

    # c "NO!! PATCHES FIGHT! SPARKY FIGHT! NO PILLOW FIGHT!"
    c "¡¡NO!! ¡PATCHES, PELEA! ¡SPARKY, PELEA! ¡NADA DE PELEAS DE ALMOHADAS!"

# game/scripts/scriptliving.rpy:351
translate spanish livingmenuinteract_501d941f:

    # z "OoOoOoH..."
    z "OoOoOoH..."

# game/scripts/scriptliving.rpy:354
translate spanish livingmenuinteract_4b9692dd:

    # n "The zombies and Olive look disappointed."
    n "Los zombies y Olive parecen decepcionados."

# game/scripts/scriptliving.rpy:375
translate spanish livingmenunavigate_52c2ef95:

    # c "We NEED to go upstairs!! Angel's in trouble!"
    c "¡NECESITAMOS subir las escaleras! ¡Angel está en problemas!"

# game/scripts/scriptliving.rpy:393
translate spanish livingmenunavigate_1a8b018c:

    # n "Coco glares at Olive. She flexes her paws menacingly."
    n "Coco mira a Olive. Ella flexiona sus patas de manera amenzante."

# game/scripts/scriptliving.rpy:401
translate spanish livingmenunavigate_291f7c6c:

    # c "It's the purrfect time for a walk right Olive?!"
    c "Es el momento perfecto para dar un paseo, ¿verdad Olive?"

# game/scripts/scriptliving.rpy:404
translate spanish livingmenunavigate_3329d8d1:

    # o "YEAH!"
    o "¡SÍ!"

# game/scripts/scriptliving.rpy:408
translate spanish livingmenunavigate_80db770f:

    # c "I WILL STRANGLE YOU AND FEEL NOTHING IF YOU DON'T GO UPSTAIRS RIGHT NOW!!"
    c "¡¡TE VOY A ESTRANGULAR Y NO SENTIRÉ NI UNA PIZCA DE CULPA SI NO SUBES AHORA MISMO!!"

# game/scripts/scriptliving.rpy:422
translate spanish livingtable_d83002fd:

    # n "The table is set for Olive's surprise birthday party. The teapot is completely empty."
    n "La mesa está preparada para la fiesta sorpresa de cumpleaños de Olive. La tetera está completamente vacía."

# game/scripts/scriptliving.rpy:430
translate spanish livingtable_b25db0f8:

    # o "E-everyone was just here!"
    o "¡T-todos estuvieron aquí!"

# game/scripts/scriptliving.rpy:433
translate spanish livingtable_6a9bd994:

    # s "Did Patches take them somewhere?"
    s "¿Patches los llevó a alguna parte?"

# game/scripts/scriptliving.rpy:436
translate spanish livingtable_88c4027b:

    # g "Knowing him... He's probably waiting for us somewhere..."
    g "Conociéndolo... Probablemente nos esté esperando en alguna parte..."

# game/scripts/scriptliving.rpy:439
translate spanish livingtable_ce9c0dec:

    # s "Waiting? Why?!"
    s "¿Esperando? ¡¿Por qué?!"

# game/scripts/scriptliving.rpy:442
translate spanish livingtable_34c56fde:

    # g "He uhh, talks a lot about all the ways he's going to hurt you guys."
    g "Él uhh, habla mucho sobre todas las formas en que los va a lastimar."

# game/scripts/scriptliving.rpy:443
translate spanish livingtable_171aff91:

    # g "And most of them are long and painful and require spectators."
    g "Y la mayoría son largas, dolorosas y requieren público."

# game/scripts/scriptliving.rpy:446
translate spanish livingtable_e260da8b:

    # s "Ugh how did you ever fall for a guy like him?"
    s "Ugh, ¿cómo te enamoraste de un tipo como él?"

# game/scripts/scriptliving.rpy:449
translate spanish livingtable_4f874ef6:

    # g "You wouldn't understand. I think I might be..."
    g "No lo entenderías. Creo que podría ser..."

# game/scripts/scriptliving.rpy:452
translate spanish livingtable_72e7ea7d:

    # g "Insecure."
    g "Una persona insegura."

# game/scripts/scriptliving.rpy:454
translate spanish livingtable_a0d24bb3:

    # s "Oh."
    s "Oh."

# game/scripts/scriptliving.rpy:461
translate spanish livingtable_2fe5b17d:

    # c "LET'S GO OLIVE!!"
    c "¡¡VAMOS DE OLIVE!!"

# game/scripts/scriptliving.rpy:465
translate spanish livingtable_d83002fd_1:

    # n "The table is set for Olive's surprise birthday party. The teapot is completely empty."
    n "La mesa está preparada para la fiesta sorpresa de cumpleaños de Olive. La tetera está completamente vacía."

# game/scripts/scriptliving.rpy:473
translate spanish livingtable_e6781263:

    # o "Wow is this what a tea party looks like?! What a cute cup!!"
    o "¡¿Así es como se ve una fiesta de té?! Que linda taza!!"

# game/scripts/scriptliving.rpy:479
translate spanish livingtable_b878c1d8:

    # o "Aww no one'll mind if I try just a b-bit!"
    o "¡Aww, a nadie le importará si pruebo sólo un poquito!"

# game/scripts/scriptliving.rpy:482
translate spanish livingtable_f12fffa8:

    # n "Olive picks up the teapot and drinks straight from the spout. A bunch of lukewarm tea spills down their chin and onto their overalls."
    n "Olive toma la tetera y bebe directamente del pico. El té tibio se le derrama por la barbilla, empapando sus mangas."

# game/scripts/scriptliving.rpy:484
translate spanish livingtable_898cddfb:

    # o "Y-you don't think anyone would mind if I tried just a bit, r-right?"
    o "No crees que a nadie le importaría si pruebo un poco, ¿verdad?"

# game/scripts/scriptliving.rpy:488
translate spanish livingtable_2f0ef3ad:

    # b "Only if it means I get to eat some cake!!"
    b "¡¡Solo si eso significa que puedo comer pastel!!"

# game/scripts/scriptliving.rpy:490
translate spanish livingtable_ee8b8ce2:

    # n "Brownie picks a biscuit from off the side of the cake and chows down!"
    n "¡Brownie toma una galleta del costado del pastel y la come!"

# game/scripts/scriptliving.rpy:494
translate spanish livingtable_f6fef1a6:

    # s "It's your birthday, I'm sure no one minds!"
    s "¡Es tu cumpleaños, estoy seguro de que a nadie le importa!"

# game/scripts/scriptliving.rpy:498
translate spanish livingtable_dd46d4ce:

    # n "Olive picks up the teapot as if to pour it, but instead drinks directly from the spout."
    n "Olive toma la tetera como para servirla, pero bebe directamente del pico."

# game/scripts/scriptliving.rpy:502
translate spanish livingtable_e59eeada:

    # b "AHAHAH oh my Dog you're insane!"
    b "¡JAJAJA, por mis Perros, estás demente!"

# game/scripts/scriptliving.rpy:506
translate spanish livingtable_e46721ea:

    # s "O-Olive!! I don't think that's how you-"
    s "O-Olive!! No creo que así sea como tú-"

# game/scripts/scriptliving.rpy:509
translate spanish livingtable_965c1c1b:

    # o "WOW!! That was so good!"
    o "¡¡GUAU!! ¡Eso estuvo tan bueno!"

# game/scripts/scriptliving.rpy:515
translate spanish livingtable_b754d528:

    # n "They take another swig but start choking." with vpunch
    n "Toma otro trago pero comienza a ahogarse." with vpunch

# game/scripts/scriptliving.rpy:519
translate spanish livingtable_22b32a1a:

    # n "Angel looks at Olive from the other side of the room, alarmed."
    n "Angel mira a Olive desde el otro lado de la habitación, alarmado."

# game/scripts/scriptliving.rpy:521
translate spanish livingtable_db9c3d87:

    # a "Uh... Olive? Are you okay...?"
    a "Eh... ¿Olive? Estás bien...?"

# game/scripts/scriptliving.rpy:525
translate spanish livingtable_943f1636:

    # s "OLIVE!"
    s "¡OLIVE!"

# game/scripts/scriptliving.rpy:527
translate spanish livingtable_d1b05c95:

    # n "Sparky grabs Olive by the waist, ready to knock out whatever they're choking on."
    n "Sparky agarra a Olive por la cintura, listo para hacerle escupir cualquier cosa con la que se esté ahogando."

# game/scripts/scriptliving.rpy:530
translate spanish livingtable_b17106d6:

    # b "ACK! OLIVE!"
    b "¡ACK! ¡OLIVE!"

# game/scripts/scriptliving.rpy:536
translate spanish livingtable_02835d52:

    # n "Olive coughs out a small key."
    n "Olive tose una pequeña llave."

# game/scripts/scriptliving.rpy:539
translate spanish livingtable_ac069f61:

    # n "They turn towards Angel, coughing and sputtering."
    n "Se gira hacia Angel, tosiendo y escupiendo restos de té."

# game/scripts/scriptliving.rpy:541
translate spanish livingtable_5e0accb0:

    # o "O-OH R-RIGHT, you're right over there!"
    o "¡O-OH, E-ES CIERTO, estás justo ahí!"

# game/scripts/scriptliving.rpy:542
translate spanish livingtable_187f9610:

    # o "Uhh I was just s-smelling the tea!"
    o "¡Uhh, solo estaba oliendo el té!"

# game/scripts/scriptliving.rpy:545
translate spanish livingtable_aa59afd1:

    # a "Oh... Okay!"
    a "¡Ah, okey!"

# game/scripts/scriptliving.rpy:549
translate spanish livingtable_45d42507:

    # n "They turn back towards the table and whisper to themselves."
    n "Se gira hacia la mesa y susurra para sí misma."

# game/scripts/scriptliving.rpy:552
translate spanish livingtable_9e2225de:

    # o "A key! Th-this should be useful!"
    o "¡Una llave! ¡Esto debería ser útil!"

# game/scripts/scriptliving.rpy:558
translate spanish livingtable_cd756e59:

    # b "A key?! Who the hell puts a key in a teapot?!"
    b "¡¿Una llave?! ¿Quién diablos pone una llave en una tetera?"

# game/scripts/scriptliving.rpy:562
translate spanish livingtable_ba83e9f5:

    # b "Aw well. Hopefully almost choking to death was worth it!"
    b "En fin. ¡Espero que casi morir asfixiado haya valido la pena!"

# game/scripts/scriptliving.rpy:566
translate spanish livingtable_9389cfc2:

    # s "Hopefully it comes in handy."
    s "Ojalá sea útil."

# game/scripts/scriptliving.rpy:570
translate spanish livingtable_e6c2ee26:

    # s "A key?! Thank Dog you didn't choke to death on it."
    s "¡¿Una llave?! Menos mal que no te asfixiaste con ella."

# game/scripts/scriptliving.rpy:573
translate spanish livingtable_aed72931:

    # o "Y-yaAaAay."
    o "Y-yaAaAay."

# game/scripts/scriptliving.rpy:586
translate spanish livingtable_4f0ae7ac:

    # o "I-I should wait until we're all together to try some!"
    o "¡Debería esperar hasta que estemos todos juntos para probar un poco!"

# game/scripts/scriptliving.rpy:595
translate spanish livingtable_e6781263_1:

    # o "Wow is this what a tea party looks like?! What a cute cup!!"
    o "¡¿Así es como se ve una fiesta de té?! Que linda taza!!"

# game/scripts/scriptliving.rpy:599
translate spanish livingtable_6535e0b9:

    # a "Oh thank you... It's customary for cats to have tea parties every so often."
    a "Oh, gracias... Es costumbre que los gatos hagan fiestas de té de vez en cuando."

# game/scripts/scriptliving.rpy:603
translate spanish livingtable_a96cb3e2:

    # b "AHAHAH I guess you could say tea parties are for pussies."
    b "¡JAJAJA! Supongo que se podría decir que las fiestas de té son para miedosos."

# game/scripts/scriptliving.rpy:609
translate spanish livingtable_e7abcc30:

    # n "Brownie lifts her paw up for a high five. Angel doesn't move."
    n "Brownie levanta su pata para chocar esos cinco. Angel no se mueve."

# game/scripts/scriptliving.rpy:612
translate spanish livingtable_04b40b43:

    # n "Olive rushes to high five her though, not as reward for the awesome joke but because Olive is always itching to hold paws."
    n "Olive corre a chocarle la mano, aunque no para celebrar el chiste, sino porque se muere de ganas de tomarla de la pata."

# game/scripts/scriptliving.rpy:617
translate spanish livingtable_ae03c7f2:

    # n "Sparky elbows her in the ribs."
    n "Sparky le da un codazo en las costillas."

# game/scripts/scriptliving.rpy:622
translate spanish livingtable_166a7c51:

    # o "C-can I try some?!"
    o "¿P-puedo probar un poco?"

# game/scripts/scriptliving.rpy:625
translate spanish livingtable_a6be5e3c:

    # a "Of course!"
    a "¡Por supuesto!"

# game/scripts/scriptliving.rpy:632
translate spanish livingtable_b33a8746:

    # n "Before Angel can pour Olive a cup of tea, they pick up the teapot and drink straight from the spout."
    n "Antes de que Angel pueda servirle una taza de té a Olive, ella toma la tetera y bebe directamente del pico."

# game/scripts/scriptliving.rpy:636
translate spanish livingtable_e5e260d0:

    # n "A bunch of lukewarm tea spills down their chin and onto their overalls. Angel doesn't seem to mind."
    n "Un poco té tibio se le derrama por la barbilla, empapando su ropa.. A Angel no parece importarle."

# game/scripts/scriptliving.rpy:639
translate spanish livingtable_143bf4c2:

    # n "Brownie grimaces a little but Angel seems content."
    n "Brownie hace una pequeña mueca pero a Angel parece no importarle."

# game/scripts/scriptliving.rpy:642
translate spanish livingtable_5a456cc5:

    # n "Sparky feels some secondhand embarrassment but Angel seems content."
    n "Sparky siente cierta vergüenza ajena, pero a Angel parece no importarle."

# game/scripts/scriptliving.rpy:646
translate spanish livingtable_beba2b9c:

    # n "Brownie and Sparky grimace a little but Angel seems content."
    n "Brownie y Sparky hacen una pequeña mueca, pero a Angel parece no importarle."

# game/scripts/scriptliving.rpy:648
translate spanish livingtable_965c1c1b_1:

    # o "WOW!! That was so good!"
    o "¡¡GUAU!! ¡Eso estuvo tan bueno!"

# game/scripts/scriptliving.rpy:652
translate spanish livingtable_9fc4d3e6:

    # a "I'm so glad!"
    a "¡Me alegro mucho!"

# game/scripts/scriptliving.rpy:659
translate spanish livingtable_c1c3bfe1:

    # n "Olive takes another swig but starts choking." with vpunch
    n "Olive toma otro trago pero comienza a ahogarse." with vpunch

# game/scripts/scriptliving.rpy:661
translate spanish livingtable_4bd403f6:

    # a "O-Olive!!"
    a "O-Olive!!"

# game/scripts/scriptliving.rpy:664
translate spanish livingtable_6c0eab70:

    # n "Angel grabs the teapot from Olive. They cough out a small key."
    n "Angel le quita la tetera a Olive. Ella tose una pequeña llave."

# game/scripts/scriptliving.rpy:669
translate spanish livingtable_fd75939f:

    # b "Lucky! It must be one of Coco's keys!"
    b "¡Suertudo! ¡Debe ser una de las llaves de Coco!"

# game/scripts/scriptliving.rpy:672
translate spanish livingtable_e6c2ee26_1:

    # s "A key?! Thank Dog you didn't choke to death on it."
    s "¡¿Una llave?! Gracias a los Perros que no te asfixiaste con ella."

# game/scripts/scriptliving.rpy:676
translate spanish livingtable_cd756e59_1:

    # b "A key?! Who the hell puts a key in a teapot?!"
    b "¡¿Una llave?! ¿Quién diablos pone una llave en una tetera?"

# game/scripts/scriptliving.rpy:680
translate spanish livingtable_b6d1901d:

    # a "Oh it's just one of Coco's keys! I guess she hid it in there while I wasn't looking..."
    a "¡Oh, es sólo una de las llaves de Coco! Supongo que lo escondió allí mientras yo no miraba..."

# game/scripts/scriptliving.rpy:683
translate spanish livingtable_1385aa6f:

    # n "Olive coughs and sputters."
    n "Olive tose y escupe un poco de te."

# game/scripts/scriptliving.rpy:687
translate spanish livingtable_aed72931_1:

    # o "Y-yaAaAay."
    o "Y-yaAaAay."

# game/scripts/scriptliving.rpy:694
translate spanish livingtable_24477a21:

    # a "That's three keys... Let's hurry up and get to Coco's room!"
    a "Son tres llaves... ¡Démonos prisa y lleguemos a la habitación de Coco!"

# game/scripts/scriptliving.rpy:700
translate spanish livingcushions_2fe5b17d:

    # c "LET'S GO OLIVE!!"
    c "¡¡VAMOS DE OLIVE!!"

# game/scripts/scriptliving.rpy:703
translate spanish livingcushions_82213c1d:

    # n "Five cushions are placed neatly around the table."
    n "Alrededor de la mesa hay cinco cojines cuidadosamente colocados."

# game/scripts/scriptliving.rpy:709
translate spanish livingcushions_f3855e4d:

    # o "There are f-five cushions! One for Brownie, Sparky, Angel, Coco and m-me!"
    o "¡Hay cinco cojines! ¡Para Brownie, Sparky, Angel, Coco y yo!"

# game/scripts/scriptliving.rpy:711
translate spanish livingcushions_d4546c21:

    # o "I guess no one was expecting one th-thousand undead guests. We'd better get more pillows!"
    o "Supongo que nadie esperaba mil invitados zombies. ¡Será mejor que consigamos más cojines!"

# game/scripts/scriptliving.rpy:717
translate spanish livingcushions_d4546c21_1:

    # o "I guess no one was expecting one th-thousand undead guests. We'd better get more pillows!"
    o "Supongo que nadie esperaba mil invitados zombies. ¡Será mejor que consigamos más cojines!"

# game/scripts/scriptliving.rpy:721
translate spanish livingcushions_d42bedaf:

    # a "That's a very sweet sentiment Olive but I think the solution here is less zombies, not more pillows..."
    a "Ese es un sentimiento muy dulce, Olive, pero creo que la solución aquí es menos zombies mejor, entonces no más cojines..."

# game/scripts/scriptliving.rpy:726
translate spanish livingcushions_5522e772:

    # o "When this is all over w-we should s-stack these pillows up and make a nice fluffy bed f-for you Sparky!"
    o "Cuando todo esto termine, deberíamos apilar estos cojines y hacer una bonita y mullida cama para ti, Sparky."

# game/scripts/scriptliving.rpy:733
translate spanish livingcushions_c8147964:

    # a "Heh... We have a bed upstairs Olive..."
    a "Je... Tenemos camas arriba, Olive..."

# game/scripts/scriptliving.rpy:736
translate spanish livingcushions_95f55c23:

    # o "B-but this way Sparky can nap with us while we have a tea party!"
    o "¡P-pero de esta manera Sparky puede tomar una siesta con nosotros mientras tomamos el té!"

# game/scripts/scriptliving.rpy:740
translate spanish livingcushions_6e2e9076:

    # b "Oof that's so sweet I might get a cavity just thinking about it."
    b "Uf, eso es tan dulce que me va a salir una caries de solo pensarlo."

# game/scripts/scriptliving.rpy:744
translate spanish livingcushions_aeae00dc:

    # s "That honestly sounds very nice..."
    s "Sinceramente suena muy bien..."

# game/scripts/scriptliving.rpy:746
translate spanish livingcushions_c9170687:

    # s "But..."
    s "Pero..."

# game/scripts/scriptliving.rpy:748
translate spanish livingcushions_d434ff26:

    # s "If Coco can't fix me and I start hurting anyone in my sleep promise me you'll do whatever you can to stop me."
    s "Si Coco no puede arreglarme y empiezo a lastimar a alguien mientras duermo, prométeme que harás todo lo que puedas para detenerme."

# game/scripts/scriptliving.rpy:755
translate spanish livingcushions_ae3e64e4:

    # o "Oh l-like tie you up?"
    o "Oh, ¿c-como atarte?"

# game/scripts/scriptliving.rpy:759
translate spanish livingcushions_833ce8c8:

    # s "Hehehe sure."
    s "Jejeje seguro."

# game/scripts/scriptliving.rpy:761
translate spanish livingcushions_adb2a5c8:

    # n "Sparky pats Olive on the head as reward for their innocence."
    n "Sparky le da una palmada en la cabeza a Olive como recompensa por su inocencia."

# game/scripts/scriptliving.rpy:766
translate spanish livingcushions_850ef128:

    # b "..."
    b "..."

# game/scripts/scriptliving.rpy:769
translate spanish livingcushions_66203de6:

    # b "Heheh, like I said Sparky, if you try anything I'll just break your legs!"
    b "Jeje, como dije Sparky, si intentas algo, ¡te romperé tus piernas de mierda!"

# game/scripts/scriptliving.rpy:772
translate spanish livingcushions_771d3762:

    # s "Thanks Brownie!"
    s "Gracias Brownie!"

# game/scripts/scriptliving.rpy:775
translate spanish livingcushions_934ea2fd:

    # o "NOOOoOoOoOo!!"
    o "¡¡NOOOoOoOoOo!!"

# game/scripts/scriptliving.rpy:781
translate spanish livingcushions_afad15e5:

    # a "We'll make sure you don't do anything you'll regret Sparky..."
    a "Nos aseguraremos de que no hagas nada de lo que te arrepientas, Sparky..."

# game/scripts/scriptliving.rpy:784
translate spanish livingcushions_40c620e8:

    # s "Thanks Angel."
    s "Gracias Angel."

# game/scripts/scriptliving.rpy:804
translate spanish livingangel_1d560cf6:

    # o "H-hey Angel! W-what are you up to?"
    o "¡H-hola Angel! ¿Q-qué estás haciendo?"

# game/scripts/scriptliving.rpy:807
translate spanish livingangel_6183ce02:

    # a "... Coco asked me to stand guard over the entrance to make sure the zombies don't get in..."
    a "... Coco me pidió que vigile la entrada para asegurarme de que los zombies no entraran..."

# game/scripts/scriptliving.rpy:809
translate spanish livingangel_40ff6078:

    # a "I'd stand outside and watch the gate but... Their groaning gives me a headache and makes me feel bad..."
    a "Me quedaría afuera y miraría la puerta, pero... Sus gemidos me dan dolor de cabeza y me hacen sentir mal..."

# game/scripts/scriptliving.rpy:823
translate spanish livingangel_83a1acc3:

    # o "It doesn't look like the zombies will be b-breaking in anytime soon!"
    o "¡No parece que los zombies vayan a irrumpir pronto!"

# game/scripts/scriptliving.rpy:825
translate spanish livingangel_5eccabb6:

    # o "W-well, I don't think the zombies will be breaking in a-anytime soon."
    o "B-bueno, no creo que los zombies vayan a entrar pronto."

# game/scripts/scriptliving.rpy:831
translate spanish livingangel_6d1250e1:

    # b "Pfft I can't believe you got swindled into guard dog duty. If these zombies ever manage to get past the gate I'll eat my own socks."
    b "Pfft, no puedo creer que te hayan puesto como perrito guardián. Si estos zombies alguna vez logran pasar por esa puerta, me comeré mis propios calcetines."

# game/scripts/scriptliving.rpy:835
translate spanish livingangel_ba2bbc34:

    # b "Dude if these zombies ever manage to get past the gate I'll eat my own socks."
    b "Amigo, si estos zombies alguna vez logran pasar la puerta, me comeré mis propios calcetines."

# game/scripts/scriptliving.rpy:838
translate spanish livingangel_2dda7ae7:

    # a "Yeah... I guess they have no more of an affinity for metal fences as they did when they were alive..."
    a "Ya... Imagino que les gustan las vallas metálicas tan poco como cuando estaban vivos..."

# game/scripts/scriptliving.rpy:842
translate spanish livingangel_d6953597:

    # o "W-would you like to hang out w-with me until C-Coco is done uhh, ''taking care'' of them?"
    o "¿T-te gustaría pasar el rato c-conmigo hasta que C-Coco termine de, emm, ''cuidar'' de ellos?"

# game/scripts/scriptliving.rpy:847
translate spanish livingangel_d8dab8ba:

    # o "W-would you like to come visit Coco with Sparky and me?"
    o "¿Te gustaría venir a visitar a Coco con Sparky?"

# game/scripts/scriptliving.rpy:850
translate spanish livingangel_7f1af8bf:

    # a "I don't think that's a good idea... We shouldn't bother Coco unless absolutely necessary."
    a "No creo que sea una buena idea... No deberíamos molestar a Coco a menos que sea absolutamente necesario."

# game/scripts/scriptliving.rpy:853
translate spanish livingangel_9fa616c2:

    # o "B-but it's super important!! T-t-tell him Sparky!"
    o "¡¡P-pero es súper importante!! D-d-díselo Sparky!"

# game/scripts/scriptliving.rpy:856
translate spanish livingangel_40040b62:

    # s "Uhh, I guess I've been having some issues related to the whole Hachiko High incident and possibly todays events."
    s "Uhh, supongo que he estado teniendo algunos problemas relacionados con todo esto del incidente en el instituto Hachiko y posiblemente, con lo que ha pasado hoy."

# game/scripts/scriptliving.rpy:857
translate spanish livingangel_44aa5b33:

    # s "Everytime I sleep I have vivid and violent nightmares about dogs being killed. When I wake up the people around me are scared or hurt and the place is trashed."
    s "Cada vez que duermo tengo pesadillas vívidas y violentas sobre perros muertos. Y cuando me despierto, la gente que me rodea está asustada o herida y el lugar está destrozado."

# game/scripts/scriptliving.rpy:859
translate spanish livingangel_7cb42d02:

    # s "I'm so tired now I can't even tell the difference between dreams and reality."
    s "Estoy tan cansado ahora que ni siquiera puedo distinguir la diferencia entre los sueños y la realidad."

# game/scripts/scriptliving.rpy:862
translate spanish livingangel_4ecc8a25:

    # a "... That does sound serious..."
    a "... Eso suena serio..."

# game/scripts/scriptliving.rpy:866
translate spanish livingangel_03804078:

    # o "W-would you like to hang out w-with me and Brownie until C-Coco is done uhh, ''taking care'' of them?"
    o "¿Te gustaría pasar el rato conmigo y con Brownie hasta que C-Coco termine de ''cuidar'' de ellos?"

# game/scripts/scriptliving.rpy:869
translate spanish livingangel_ec77292f:

    # b "Yeah man it's a heckin' riot. Walkin' around, lookin' around, talking about our feeeelings."
    b "Sí, es un maldito desmadre. Caminando por ahí, mirando cosas, hablando de nuestros seeentimientos."

# game/scripts/scriptliving.rpy:873
translate spanish livingangel_d02caaa0:

    # o "W-would you like to come visit Coco with us?"
    o "¿Te gustaría venir a visitar a Coco con nosotros?"

# game/scripts/scriptliving.rpy:876
translate spanish livingangel_696068c8:

    # s "I've been having some... Sleepwalking issues..."
    s "He estado teniendo algunos... problemas de sonambulismo..."

# game/scripts/scriptliving.rpy:879
translate spanish livingangel_850ef128:

    # b "..."
    b "..."

# game/scripts/scriptliving.rpy:881
translate spanish livingangel_a4c59122:

    # s "I MEAN, I feel like I'm becoming a monster. I'm hoping Coco can confirm otherwise."
    s "QUIERO DECIR, siento que me estoy convirtiendo en un monstruo. Espero que Coco pueda confirmar lo contrario."

# game/scripts/scriptliving.rpy:884
translate spanish livingangel_559b7537:

    # a "Hmm..."
    a "Mmm..."

# game/scripts/scriptliving.rpy:885
translate spanish livingangel_ee436add:

    # n "Angel looks through the window to see how the zombies are doing."
    n "Angel mira por la ventana para ver cómo están los zombies."

# game/scripts/scriptliving.rpy:886
translate spanish livingangel_960a1916:

    # n "They're mindlessly walking into the fence whilst moaning about revenge or something."
    n "Están caminando sin pensar hacia la reja mientras se quejan de venganza o algo así."

# game/scripts/scriptliving.rpy:889
translate spanish livingangel_e8a6a844:

    # a "... Alright! Let's hang out!"
    a "... ¡Está bien! ¡Pasemos el rato!"

# game/scripts/scriptliving.rpy:892
translate spanish livingangel_8b9a7ecf:

    # a "... Alright! I suppose this is serious enough to abandon my post and bother Coco..."
    a "... ¡Está bien! Supongo que esto es lo suficientemente grave como para abandonar mi puesto y molestar a Coco..."

# game/scripts/scriptliving.rpy:895
translate spanish livingangel_77541f61:

    # o "Y-yay!!!"
    o "¡¡¡Y-yay!!!"

# game/scripts/scriptliving.rpy:908
translate spanish livingangel_96c31b81:

    # o "I b-better not bother Angel. He's on guard duty!"
    o "Será mejor que no moleste a Angel. ¡Está de perro guardian!"

# game/scripts/scriptliving.rpy:913
translate spanish livingangel_486639f0:

    # o "We b-better not bother Angel."
    o "Será mejor que no molestemos a Angel."

# game/scripts/scriptliving.rpy:917
translate spanish livingangel_e16ea4d5:

    # b "He's too busy ''guarding'' to hang out with us anyway."
    b "De todos modos, está demasiado ocupado ''vigilando'' para estar con nosotros."

# game/scripts/scriptliving.rpy:923
translate spanish livingangel_94e3289f:

    # s "Good point. Standing guard is an important job!"
    s "Buen punto. ¡Hacer perro guardian es un trabajo importante!"

# game/scripts/scriptliving.rpy:928
translate spanish livingangel_04fbf89a:

    # o "Keeping watch is a v-very important job!! You make a very nice g-guard dog!"
    o "¡¡Estar alerta es un trabajo muy importante!! ¡Eres un perro guardián muy agradable!"

# game/scripts/scriptliving.rpy:932
translate spanish livingangel_afa22c7a:

    # a "Hehehe... Thanks Olive!"
    a "Jejeje... ¡Gracias Olive!"

# game/scripts/scriptliving.rpy:952
translate spanish livingangel_ea162656:

    # o "A-ANGEL! You're okay!!"
    o "¡A-ANGEL! ¡¡Estás bien!!"

# game/scripts/scriptliving.rpy:955
translate spanish livingangel_9399aa28:

    # n "Olive pulls Angel into an awkward hug. Angel reciprocates making it way less awkward."
    n "Olive le da a Angel un abrazo algo torpe. Angel le sigue la corriente, haciendo que sea mucho menos incómodo."

# game/scripts/scriptliving.rpy:958
translate spanish livingangel_b0562b05:

    # a "Olive! I'm so happy you made it..."
    a "¡Olive! Estoy tan feliz de que hayas llegado..."

# game/scripts/scriptliving.rpy:959
translate spanish livingangel_524e75e7:

    # a "I didn't know how to contact you... Coco was certain you would succumb to the zombies if not to your own clumsiness..."
    a "No sabía cómo contactarte... Coco estaba segura de que tropezarias y moririas ante los zombies..."

# game/scripts/scriptliving.rpy:971
translate spanish livingangel_bb33ebaf:

    # o "A-ANGEL! HI!!!"
    o "¡A-ANGEL! ¡¡¡HOLAA!!!"

# game/scripts/scriptliving.rpy:975
translate spanish livingangel_9399aa28_1:

    # n "Olive pulls Angel into an awkward hug. Angel reciprocates making it way less awkward."
    n "Olive le da a Angel un abrazo algo torpe. Angel le sigue la corriente, haciendo que sea mucho menos incómodo."

# game/scripts/scriptliving.rpy:977
translate spanish livingangel_4a75be7a:

    # n "Sparky watching awkwardly seems to counteract this though."
    n "Aunque Sparky, al mirar con incomodidad, parece contrarrestar el efecto."

# game/scripts/scriptliving.rpy:980
translate spanish livingangel_c236f53a:

    # s "Hey Angel! Long time no see!"
    s "¡Hola Angel! ¡Cuanto tiempo sin verte!"

# game/scripts/scriptliving.rpy:983
translate spanish livingangel_e95364ef:

    # a "Hi Sparky! I haven't seen you since..."
    a "Hola Sparky! No te he visto desde..."

# game/scripts/scriptliving.rpy:985
translate spanish livingangel_6c05b8ae:

    # a "We killed the entire population of Hachiko High..."
    a "Que matamos a toda la población del instituto Hachiko..."

# game/scripts/scriptliving.rpy:987
translate spanish livingangel_569b0e5d:

    # a "Sorry for that..."
    a "Perdon por eso..."

# game/scripts/scriptliving.rpy:990
translate spanish livingangel_b10194ec:

    # s "Um, it's okay I guess!"
    s "¡emm, Está bien, supongo!"

# game/scripts/scriptliving.rpy:995
translate spanish livingangel_9399aa28_2:

    # n "Olive pulls Angel into an awkward hug. Angel reciprocates making it way less awkward."
    n "Olive le da a Angel un abrazo algo torpe. Angel le sigue la corriente, haciendo que sea mucho menos incómodo."

# game/scripts/scriptliving.rpy:997
translate spanish livingangel_dfb5c25e:

    # n "Or so they think. Brownie gives them a big goofy eye roll."
    n "O eso creen. Brownie les pone los ojos en blanco con una mueca burlona."

# game/scripts/scriptliving.rpy:1001
translate spanish livingangel_4071b9ed:

    # b "BLEGH get a room!"
    b "¡PUAJ, busquen una habitación!"

# game/scripts/scriptliving.rpy:1004
translate spanish livingangel_07af6da9:

    # o "We are in a r-room!"
    o "¡Estamos en una h-habitación!"

# game/scripts/scriptliving.rpy:1008
translate spanish livingangel_9b3f5fca:

    # s "The living room in fact."
    s "De hecho, es el salón."

# game/scripts/scriptliving.rpy:1011
translate spanish livingangel_f98f4bb1:

    # b "Oh my Dog. I need to find Coco so I'm not completely surrounded by morons."
    b "Ay, por todos los perros. Necesito encontrar a Coco para no estar rodeado de puros idiotas."

# game/scripts/scriptliving.rpy:1015
translate spanish livingangel_a36cb951:

    # a "Well... I'm happy you all made it!"
    a "Bueno... ¡estoy feliz de que todos hayan llegado!"

# game/scripts/scriptliving.rpy:1018
translate spanish livingangel_296d698c:

    # a "Eheheh... I'm happy you all made it!"
    a "Eheheh... ¡Estoy feliz de que todos hayan llegado!"

# game/scripts/scriptliving.rpy:1019
translate spanish livingangel_1423962c:

    # a "I didn't know how to contact you Olive... Coco was certain you would succumb to the zombies if not to your own clumsiness..."
    a "No sabía cómo contactarte Olive... Coco estaba segura de que tropezarias y moririas ante los zombies..."

# game/scripts/scriptliving.rpy:1022
translate spanish livingangel_b5ed8f22:

    # o "EH?! I-I w-wouldn't trip and die in the woofs! I mean woods."
    o "¡¿EH?! ¡Yo n-no tropezaría y moriría en el bosque."

# game/scripts/scriptliving.rpy:1024
translate spanish livingangel_286b095e:

    # o "Well, m-maybe I did trip a few times. But th-that doesn't matter!"
    o "Bueno, tal vez tropecé un par de veces. ¡Pero e-eso no importa!"

# game/scripts/scriptliving.rpy:1026
translate spanish livingangel_e774a63b:

    # o "Where is everypuppy? And where's C-Coco?"
    o "¿Dónde están t-todos? ¿Y dónde está C-Coco?"

# game/scripts/scriptliving.rpy:1029
translate spanish livingangel_d40961f0:

    # a "Ahh! If you're worried there's no need... The others are off exploring the house while Coco is taking care of the zombies..."
    a "¡Ah! No hace falta que estes preocupada... Los demás están explorando la casa mientras Coco cuida de los zombies..."

# game/scripts/scriptliving.rpy:1032
translate spanish livingangel_d510714e:

    # o "What's with all the zombies? And where's C-Coco?"
    o "¿Qué pasa con todos esos zombies? ¿Y dónde está C-Coco?"

# game/scripts/scriptliving.rpy:1035
translate spanish livingangel_c2f7128c:

    # a "Ahh! If you're worried there's no need... Coco is taking care of the zombies..."
    a "¡Ah! Si estás preocupada, no hace falta que lo estés... Coco se está ocupando de los zombis..."

# game/scripts/scriptliving.rpy:1039
translate spanish livingangel_fcaedee7:

    # b "OH MAN!! Is she gonna magically blow em up like a total badass?!"
    b "¡¡OH, TÍO!! ¿¡Los va a hacer explotar mágicamente como una ''auténtica pasada''!?"

# game/scripts/scriptliving.rpy:1040
translate spanish livingangel_cb1ce708:

    # b "Or or or summon evil demons to do it for her?!"
    b "¿O convocar demonios malvados para que lo hagan por ella?"

# game/scripts/scriptliving.rpy:1044
translate spanish livingangel_3c6a23ee:

    # s "Ahh another one of her killing sprees?"
    s "Ahh ¿otra de sus matanzas?"

# game/scripts/scriptliving.rpy:1048
translate spanish livingangel_55b29c43:

    # o "Taking care of them? How?"
    o "¿Cuidarlos? ¿Cómo?"

# game/scripts/scriptliving.rpy:1051
translate spanish livingangel_b4bb406c:

    # a "... I'm not sure but I trust in her abilities..."
    a "... No estoy seguro pero confío en sus habilidades..."

# game/scripts/scriptliving.rpy:1053
translate spanish livingangel_ca5008c1:

    # a "For now feel free to join the others while Coco and I clean up the mess we've made..."
    a "Por ahora, siéntete libre de juntarte con los demás mientras Coco y yo limpiamos el desastre que hemos hecho..."

# game/scripts/scriptliving.rpy:1055
translate spanish livingangel_804e80e0:

    # a "For now feel free to continue exploring while Coco and I clean up the mess we've made..."
    a "Por ahora, siéntete libre de seguir explorando mientras Coco y yo limpiamos el desastre que hemos causado..."

# game/scripts/scriptliving.rpy:1057
translate spanish livingangel_9dafad7a:

    # a "... It's the least we could do..."
    a "... Es lo mínimo que podemos hacer..."

# game/scripts/scriptliving.rpy:1061
translate spanish livingangel_f1bb6877:

    # o "Oh o-okay. I'll see if I can find them!"
    o "Oh, está bien. ¡Veré si puedo encontrarlos!"

# game/scripts/scriptliving.rpy:1066
translate spanish livingangel_bc395297:

    # o "Oh o-okay. We'll talk to you later!"
    o "Oh, está bien. ¡Hablamos más tarde!"

# game/scripts/scriptliving.rpy:1084
translate spanish livingcoco_dbba75df:

    # n "Olive's friends are whispering loudly. Angel seems to be talking about a novel called ''Clifford the Tiny Red Dog''."
    n "Los amigos de Olive susurran en voz alta. Angel parece estar hablando de una novela llamada ''Clifford the Tiny Red Dog''."

# game/scripts/scriptliving.rpy:1092
translate spanish livingcoco_62a2608c:

    # c "OLIVE! What are you doing here?"
    c "¡OLIVE! ¿Qué estás haciendo aquí?"

# game/scripts/scriptliving.rpy:1098
translate spanish livingcoco_b6745e48:

    # n "Olive and Sparky listen to their friends whispering from afar. Brownie whispers loudly about hoodie pockets filled with bacon treats."
    n "Olive y Sparky escuchan a sus amigos susurrar desde lejos. Brownie ''susurra'' sobre sus bolsillos llenos de premios de bacon."

# game/scripts/scriptliving.rpy:1113
translate spanish livingcoco_f1aebb9a:

    # n "Coco, Brownie and Angel are talking in hushed whispers."
    n "Coco, Brownie y Angel hablan en voz baja."

# game/scripts/scriptliving.rpy:1114
translate spanish livingcoco_f34f11ed:

    # n "Whatever they're talking about seems to be very private."
    n "Lo que sea que estén hablando parece ser muy privado."

# game/scripts/scriptliving.rpy:1119
translate spanish livingcoco_83ef6478:

    # c "OLIVE! What the heck are you doin' here? Aren't you taking Sparky for a walk?"
    c "¡OLIVE! ¿Qué diablos estás haciendo aquí? ¿No vas a llevar a Sparky a pasear?"

# game/scripts/scriptliving.rpy:1129
translate spanish livingcoco_1bf26459:

    # c "What're you dolts waiting for?! Get the first aid kit!"
    c "¡¿Qué están esperando idiotas?! ¡Consiguan el botiquín de primeros auxilios!"

# game/scripts/scriptliving.rpy:1132
translate spanish livingcoco_a0226b68:

    # o "Y-Y-YES MA'AM!"
    o "S-S-SÍ SEÑORA!"

# game/scripts/scriptliving.rpy:1147
translate spanish livingcoco_4ba1a3bf:

    # n "Sparky looks like he wants to bother Coco."
    n "Sparky parece querer molestar a Coco."

# game/scripts/scriptliving.rpy:1152
translate spanish livingcoco_d2f77928:

    # s "So Coco, where do you think Ginger went?"
    s "Entonces Coco, ¿a dónde crees que fue Ginger?"

# game/scripts/scriptliving.rpy:1153
translate spanish livingcoco_9edf0118:

    # s "O-out of curiosity!"
    s "¡P-por curiosidad!"

# game/scripts/scriptliving.rpy:1157
translate spanish livingcoco_2a3e02b1:

    # c "Oh I don't know, probably lying dormant somewhere in your body."
    c "Oh, no lo sé... probablemente aun esté latente en algún lugar de tu cuerpo."

# game/scripts/scriptliving.rpy:1161
translate spanish livingcoco_44851b92:

    # s "W-WHAT?!"
    s "¡¿Q-QUÉ?!"

# game/scripts/scriptliving.rpy:1164
translate spanish livingcoco_a123bb93:

    # c "I'm just kidding."
    c "Estoy bromeando."

# game/scripts/scriptliving.rpy:1166
translate spanish livingcoco_49ad0150:

    # c "If I knew where she went I'd go and banish her to Inferno."
    c "Si supiera adónde fue, iría y la desterraría al Infierno."

# game/scripts/scriptliving.rpy:1169
translate spanish livingcoco_669b4054:

    # s "Oh, right."
    s "Ah, claro."

# game/scripts/scriptliving.rpy:1172
translate spanish livingcoco_24158674:

    # c "Enough stupid questions. Go get me that first aid kit."
    c "Basta de preguntas estúpidas. Ve a buscar ese botiquín de primeros auxilios."

# game/scripts/scriptliving.rpy:1184
translate spanish livingcoco_d2e7ba91:

    # o "S-Sparky, maybe we should get that f-first aid kit before we bother Coco!"
    o "S-Sparky, ¡tal vez deberíamos conseguir ese botiquín de primeros auxilios antes de molestar a Coco!"

# game/scripts/scriptliving.rpy:1187
translate spanish livingcoco_7d604c23:

    # s "Oh! I guess that would be the responsible thing to do!"
    s "¡Oh! ¡Supongo que eso sería lo más responsable!"

# game/scripts/scriptliving.rpy:1191
translate spanish livingcoco_af83bec0:

    # n "Coco greatly approves of Olive keeping an eye on Sparky!"
    n "¡Coco aprueba que Olive vigile a Sparky!"

# game/scripts/scriptliving.rpy:1206
translate spanish livingcoco_52ec6b0f:

    # s "Here it is Coco!"
    s "¡Aquí está Coco!"

# game/scripts/scriptliving.rpy:1209
translate spanish livingcoco_eda40838:

    # n "Olive hands over the first aid kit!"
    n "¡Olive le entrega el botiquín de primeros auxilios!"

# game/scripts/scriptliving.rpy:1211
translate spanish livingcoco_eaa9dae3:

    # c "Fantastic!"
    c "¡Fantástico!"

# game/scripts/scriptliving.rpy:1214
translate spanish livingcoco_15c034f0:

    # s "Now what?"
    s "¿Y ahora qué?"

# game/scripts/scriptliving.rpy:1219
translate spanish livingcoco_0b12f6bd:

    # c "Now scram! I need to take care of Brownie and Angel's injuries!"
    c "¡Ahora vete! ¡Necesito ocuparme de las heridas de Brownie y Angel!"

# game/scripts/scriptliving.rpy:1221
translate spanish livingcoco_6efe5c4a:

    # c "First things first, sanitation!"
    c "¡Primero lo primero, desinfectar!"

# game/scripts/scriptliving.rpy:1224
translate spanish livingcoco_5d7e6840:

    # c "Blep."
    c "Blep."

# game/scripts/scriptliving.rpy:1225
translate spanish livingcoco_c7ea0186:

    # n "Brownie becomes incredibly flustered."
    n "Brownie se pone extremadamente nerviosa."

# game/scripts/scriptliving.rpy:1227
translate spanish livingcoco_b5424a3e:

    # s "Wait wait!! Here, let me do it!"
    s "¡¡Espera espera!! ¡déjame hacerlo!"

# game/scripts/scriptliving.rpy:1230
translate spanish livingcoco_e024b15e:

    # b "I DO NOT WANT SPARKY LICKING ME!!"
    b "¡¡NO QUIERO QUE SPARKY ME LAMA!!"

# game/scripts/scriptliving.rpy:1234
translate spanish livingcoco_76f8b961:

    # s "No no I won't! Licking is very archaic."
    s "¡No, no, no lo haré! Lamer es muy arcaico."

# game/scripts/scriptliving.rpy:1236
translate spanish livingcoco_00cfe944:

    # s "I took a sports medicine class so no worries!"
    s "Tomé una clase de medicina deportiva, ¡así que no te preocupes!"

# game/scripts/scriptliving.rpy:1240
translate spanish livingcoco_3141a33c:

    # n "Sparky shows Coco how to clean and dress Brownie and Angel's wounds."
    n "Sparky le muestra a Coco cómo limpiar y vendar las heridas de Brownie y Angel."

# game/scripts/scriptliving.rpy:1243
translate spanish livingcoco_177d08e8:

    # n "Everyone seems so relaxed together. It makes Olive super happy!"
    n "Todos parecen tan relajados juntos. ¡Hace a Olive súper feliz!"

# game/scripts/scriptliving.rpy:1245
translate spanish livingcoco_16edfc70:

    # n "They find a marker and draw little hearts and stars on their friends' bandages."
    n "Olive encuentra un marcador y dibuja pequeños corazones y estrellas en las vendas de sus amigos."

# game/scripts/scriptliving.rpy:1249
translate spanish livingcoco_20ce8e14:

    # s "There all done!"
    s "¡Ahí está todo hecho!"

# game/scripts/scriptliving.rpy:1252
translate spanish livingcoco_caaa475e:

    # c "Wow! You know what, you're not as dumb as I thought you were!"
    c "¡Guau! ¿Sabes qué? ¡No eres tan tonto como pensaba!"

# game/scripts/scriptliving.rpy:1255
translate spanish livingcoco_b5fe47e9:

    # s "Heh, thanks?"
    s "Je, ¿gracias?"

# game/scripts/scriptliving.rpy:1257
translate spanish livingcoco_f2691eb6:

    # s "So out of curiosity..."
    s "Así que por curiosidad..."

# game/scripts/scriptliving.rpy:1258
translate spanish livingcoco_3404ebc5:

    # s "You told the zombies you'd ''take care of the rest'' once they found Patches and Ginger."
    s "Les dijiste a los zombies que ''te encargarías del resto'' una vez que encontraran a Patches y Ginger."

# game/scripts/scriptliving.rpy:1261
translate spanish livingcoco_fcaf5dc1:

    # s "You mean kill them right?"
    s "Te refieres a matarlos, ¿verdad?"

# game/scripts/scriptliving.rpy:1262
translate spanish livingcoco_e33d2898:

    # s "How? With magic?"
    s "¿Pero cómo? ¿Con magia?"

# game/scripts/scriptliving.rpy:1265
translate spanish livingcoco_daab29bc:

    # c "BAHAHAH oh is that what this is?!"
    c "BAJAJAJ oh ¿Esto es lo que creo que es?"

# game/scripts/scriptliving.rpy:1268
translate spanish livingcoco_7cfe9a59:

    # s "Huh?! What what is??"
    s "¡¿Eh?! ¿Qué es qué?"

# game/scripts/scriptliving.rpy:1271
translate spanish livingcoco_7cdbc790:

    # c "You were just teaching me first aid so I'd teach you sorcery in return!"
    c "¡Solo me estabas enseñando primeros auxilios para que yo te enseñara hechicería a cambio!"

# game/scripts/scriptliving.rpy:1272
translate spanish livingcoco_67662253:

    # c "Guess getting possessed really makes a dog feel helpless without any magic huh?"
    c "Supongo que ser poseído realmente hace que un perro se sienta indefenso sin ningún tipo de magia, ¿no?"

# game/scripts/scriptliving.rpy:1275
translate spanish livingcoco_5b817cdf:

    # n "Sparky looks very uncomfortable."
    n "Sparky parece muy incómodo."

# game/scripts/scriptliving.rpy:1277
translate spanish livingcoco_f26cc290:

    # s "I-I'm just curious I-"
    s "S-sólo tengo curiosidad yo-"

# game/scripts/scriptliving.rpy:1280
translate spanish livingcoco_e1ab0c70:

    # c "Sparky my friend, it's completely understandable! The art of magic is a much sought after skill,"
    c "Sparky amigo, ¡es completamente comprensible! El arte de la magia es una habilidad muy buscada,"

# game/scripts/scriptliving.rpy:1281
translate spanish livingcoco_846a7138:

    # c "Only passed down from generation of magical felines to generation of magical felines!"
    c "¡Solo se transmite de generación de felinos mágicos a generación de felinos mágicos!"

# game/scripts/scriptliving.rpy:1283
translate spanish livingcoco_f09802a5:

    # c "I suppose you're lucky to have a rare friend such as I! I'd be happy to tell you how I'll defeat Patches and Ginger and save this sorry bunch!"
    c "¡Supongo que tienes suerte de tener un amigo poco común como yo! ¡Me encantaría contarte cómo derrotaré a Patches y Ginger y salvaré a este lamentable grupo!"

# game/scripts/scriptliving.rpy:1287
translate spanish livingcoco_4fe101f9:

    # n "Brownie giggles, enamoured by Coco's unwavering arrogance."
    n "Brownie se ríe, enamorada de la inquebrantable arrogancia de Coco."

# game/scripts/scriptliving.rpy:1291
translate spanish livingcoco_b6e82995:

    # c "The plan is to draw a magic circle! You remember the one from school right? Or the one in my room?"
    c "¡El plan es dibujar un círculo mágico! ¿Recuerdas el del colegio, verdad? ¿O el de mi habitación?"

# game/scripts/scriptliving.rpy:1299
translate spanish livingcoco_2ec0b5f7:

    # n "Coco uses Olive's marker to draw the magic circle on a scrap piece of bandage."
    n "Coco usa el marcador de Olive para dibujar el círculo mágico en un trozo de vendaje."

# game/scripts/scriptliving.rpy:1301
translate spanish livingcoco_d0f2a768:

    # c "The circle just needs to be big enough for a soul to pass through. You can turn it into a portal with the wand!"
    c "El círculo sólo necesita ser lo suficientemente grande para que un alma pueda pasar a través de él. ¡Luego puedes convertirlo en un portal con la varita!"

# game/scripts/scriptliving.rpy:1303
translate spanish livingcoco_e2644b87:

    # c "From the portal you can summon demons and spirits from Inferno, from Purgatory, from wherever!"
    c "¡Desde el portal puedes convocar demonios y espíritus del Infierno, o del Purgatorio, o de donde sea!"

# game/scripts/scriptliving.rpy:1305
translate spanish livingcoco_ee888303:

    # c "And you can also banish things into it!"
    c "¡Y también puedes desterrar cosas en él!"

# game/scripts/scriptliving.rpy:1307
translate spanish livingcoco_99ac2c7e:

    # c "Just force em into the portal and shut it. Ta daaaa! Your problem is gone forever!"
    c "Simplemente los oblígas a entrar en el portal y lo ciérras. Ta daaa! ¡Tu problema desapareció para siempre!"

# game/scripts/scriptliving.rpy:1311
translate spanish livingcoco_aa6f8147:

    # n "Sparky leans uncomfortably close to Coco. Brownie looks a little annoyed."
    n "Sparky se inclina incómodamente cerca de Coco. Brownie parece un poco molesta."

# game/scripts/scriptliving.rpy:1318
translate spanish livingcoco_420dd13a:

    # b "Coco you're so flippin' cool!!"
    b "¡Coco, eres tan genial!"

# game/scripts/scriptliving.rpy:1321
translate spanish livingcoco_17466cd8:

    # c "Ahaha I know I know."
    c "Jajaja lo sé, lo sé."

# game/scripts/scriptliving.rpy:1324
translate spanish livingcoco_97b90150:

    # s "Ahah, yeah cool!"
    s "¡Ah, sí, genial!"

# game/scripts/scriptliving.rpy:1326
translate spanish livingcoco_e1554201:

    # s "..."
    s "..."

# game/scripts/scriptliving.rpy:1328
translate spanish livingcoco_b4fb059a:

    # s "So now what?"
    s "¿Y ahora qué?"

# game/scripts/scriptliving.rpy:1331
translate spanish livingcoco_0e9ba53d:

    # c "NOW SCRAM!"
    c "¡AHORA VETE ALA MIERDA!"

# game/scripts/scriptliving.rpy:1334
translate spanish livingcoco_ae3eab30:

    # c "You are SUCH a restless dog. Is learning about magic really that dull?"
    c "Eres un perro TAN PUTAMENTE inquieto. ¿De verdad te parece tan aburrido aprender sobre magia?"

# game/scripts/scriptliving.rpy:1335
translate spanish livingcoco_39624046:

    # c "Just wait here until Patches and Ginger show up!"
    c "¡Solo espera aquí hasta que aparezcan Patches y Ginger!"

# game/scripts/scriptliving.rpy:1338
translate spanish livingcoco_2a025f05:

    # s "Oh okay!"
    s "¡Ah, okey!"

# game/scripts/scriptliving.rpy:1343
translate spanish livingcoco_e1554201_1:

    # s "..."
    s "..."

# game/scripts/scriptliving.rpy:1345
translate spanish livingcoco_f9ed8142:

    # n "Sparky looks a little antsy."
    n "Sparky parece un poco inquieto."

# game/scripts/scriptliving.rpy:1348
translate spanish livingcoco_88153734:

    # s "Can I go for a walk?"
    s "¿Puedo salir a caminar?"

# game/scripts/scriptliving.rpy:1351
translate spanish livingcoco_765d67c7:

    # n "Coco groans."
    n "Coco gime."

# game/scripts/scriptliving.rpy:1353
translate spanish livingcoco_56167383:

    # c "Olive you go with him. Like I said before, don't let him do anything stupid!"
    c "Olive, ve con él. Como dije antes, ¡no dejes que haga nada estúpido!"

# game/scripts/scriptliving.rpy:1357
translate spanish livingcoco_3bb91f6a:

    # o "Ahahaha okie dokie!"
    o "¡Jajajaja, okie dokie!"

# game/scripts/scriptliving.rpy:1371
translate spanish livingdeadzombies_51506e05:

    # n "The living room is strewn with dead zombie dogs."
    n "La sala de estar está llena de perros zombis muertos."

# game/scripts/scriptliving.rpy:1374
translate spanish livingdeadzombies_cfa68040:

    # c "On the bright side we won't have to worry about zombies eating him."
    c "Lo bueno es que no tendremos que preocuparnos de que los zombies se los coman."

# game/scripts/scriptliving.rpy:1383
translate spanish livingdeadzombies_51506e05_1:

    # n "The living room is strewn with dead zombie dogs."
    n "La sala de estar está llena de perros zombis muertos."

# game/scripts/scriptliving.rpy:1393
translate spanish livingdeadzombies_819463e1:

    # g "These poor dogs. What happened to them?"
    g "Estos pobres perros. ¿Qué les pasó?"

# game/scripts/scriptliving.rpy:1395
translate spanish livingdeadzombies_c5e64bef:

    # o "Th-they were brutally murdered and then brought back to life!"
    o "¡Fueron brutalmente asesinados y luego resucitados!"

# game/scripts/scriptliving.rpy:1398
translate spanish livingdeadzombies_34bae3c6:

    # g "Well I know that."
    g "Bueno, eso lo sé."

# game/scripts/scriptliving.rpy:1400
translate spanish livingdeadzombies_15f7fff8:

    # g "I mean, I brought them back and gave them a chance to..."
    g "Quiero decir, los traje de vuelta y les di la oportunidad de..."

# game/scripts/scriptliving.rpy:1403
translate spanish livingdeadzombies_6c16b685:

    # s "Avenge themselves?"
    s "¿Vengarse?"

# game/scripts/scriptliving.rpy:1406
translate spanish livingdeadzombies_94fc342c:

    # g "Yes..."
    g "Sí..."

# game/scripts/scriptliving.rpy:1407
translate spanish livingdeadzombies_b6c70d9f:

    # g "Why aren't they up and avenging?"
    g "¿Por qué no se levantan a buscar venganza?"

# game/scripts/scriptliving.rpy:1409
translate spanish livingdeadzombies_fa421dcf:

    # o "Oh... I think Patches s-sliced through a bunch of them earlier..."
    o "Oh... creo que Patches r-rebanó a un montón de ellos antes..."

# game/scripts/scriptliving.rpy:1411
translate spanish livingdeadzombies_d4433717:

    # o "And I g-guess he sliced up even more of them after that."
    o "Y supongo que cortó a algunos mas después de eso."

# game/scripts/scriptliving.rpy:1414
translate spanish livingdeadzombies_89ebc27d:

    # g "I thought he cared about these dogs..."
    g "Pensé que le importaban estos perros..."

# game/scripts/scriptliving.rpy:1416
translate spanish livingdeadzombies_9ff5c625:

    # g "Well, he's lucky he's so cute."
    g "Bueno, tiene suerte de ser tan lindo."

# game/scripts/scriptliving.rpy:1419
translate spanish livingdeadzombies_a8b43b35:

    # s "What was that?"
    s "¿Qué fue eso?"

# game/scripts/scriptliving.rpy:1422
translate spanish livingdeadzombies_9904959e:

    # g "Er, n-nothing!"
    g "Er, n-nada!"

# game/scripts/scriptliving.rpy:1429
translate spanish livingdeadzombies_76623542:

    # n "The zombies capable of walking have left while the rest are strewn about the room."
    n "Los zombies capaces de caminar se han ido mientras el resto está esparcido por la habitación."

# game/scripts/scriptliving.rpy:1433
translate spanish livingdeadzombies_76623542_1:

    # n "The zombies capable of walking have left while the rest are strewn about the room."
    n "Los zombies capaces de caminar se han ido mientras el resto está esparcido por la habitación."

# game/scripts/scriptliving.rpy:1436
translate spanish livingdeadzombies_93340847:

    # n "They look pretty relaxed just lying around."
    n "Se ven bastante relajados simplemente tumbados."

# game/scripts/scriptliving.rpy:1438
translate spanish livingdeadzombies_d0e6a23f:

    # o "I guess it's not much of a l-living room anymore!"
    o "¡Supongo que ya no se puede ''estar'' muy tranquilo en esta s-sala de estar!"

# game/scripts/scriptliving.rpy:1442
translate spanish livingdeadzombies_062bd132:

    # s "Heh, good one Olive."
    s "Je, buen chiste Olive."

# game/scripts/scriptliving.rpy:1454
translate spanish lieforsparky_6cac2c7d:

    # o "S-S-Sparky kind of t-took himself for a walk!"
    o "¡S-S-Sparky salió a caminar!"

# game/scripts/scriptliving.rpy:1457
translate spanish lieforsparky_1e3b2765:

    # c "What."
    c "Qué."

# game/scripts/scriptliving.rpy:1460
translate spanish lieforsparky_19ee0b55:

    # o "W-well he wanted to go into the woods and uhh, sniff around."
    o "B-bueno, quería ir al bosque y... bueno, husmear un poco."

# game/scripts/scriptliving.rpy:1463
translate spanish lieforsparky_1a735593:

    # c "What. For what. Sniff for what."
    c "¿Qué? ¿Para qué? ¿Husmear qué?"

# game/scripts/scriptliving.rpy:1466
translate spanish lieforsparky_2c3a2cfb:

    # o "UHH y-y-you know, snacks, bones, other dogs, n-normal stuff."
    o "¡UHH! Y-y-ya sabes... aperitivos, huesos, otros perros... cosas n-normales."

# game/scripts/scriptliving.rpy:1469
translate spanish lieforsparky_d19f855d:

    # c "..."
    c "..."

# game/scripts/scriptliving.rpy:1472
translate spanish lieforsparky_839c7598:

    # o "And Ginger."
    o "Y a Ginger."

# game/scripts/scriptliving.rpy:1475
translate spanish lieforsparky_6fc2e896:

    # c "WHAT?!" with vpunch
    c "QUE?!" with vpunch

# game/scripts/scriptliving.rpy:1478
translate spanish lieforsparky_644a56dd:

    # c "YOU SAID YOU WERE WARMING UP TO GO WITH HIM! LIAR!!!" with vpunch
    c "¡DIJISTE QUE TE ESTABAS PREPARANDO PARA IR CON ÉL! ¡¡¡MENTIROSA!!!" with vpunch

# game/scripts/scriptliving.rpy:1481
translate spanish lieforsparky_8c9bd9aa:

    # a "That's strange... I thought Sparky was a lot smarter than this..."
    a "Eso es extraño... Pensé que Sparky era mucho más inteligente..."

# game/scripts/scriptliving.rpy:1484
translate spanish lieforsparky_8b627ca9:

    # b "Yeah are you sure Olive?"
    b "Sí, ¿estás segura, Olive?"

# game/scripts/scriptliving.rpy:1485
translate spanish lieforsparky_23adea7c:

    # b "When I walked through the woods earlier with him all he talked about was how sad he'd be if he were alone."
    b "Cuando caminé por el bosque con él antes, de lo único que habló fue de lo triste que estaría si estuviera solo."

# game/scripts/scriptliving.rpy:1488
translate spanish lieforsparky_ba83b561:

    # o "He said he had some kind of t-trump card?"
    o "Emm.. Dijo que tenía una especie de ¿A-as bajo la manga?"

# game/scripts/scriptliving.rpy:1491
translate spanish lieforsparky_d3963606:

    # c "WHATEVER it doesn't matter."
    c "LO QUE NO IMPORTA EN LO ABSOLUTO."

# game/scripts/scriptliving.rpy:1494
translate spanish lieforsparky_2842cf79:

    # c "Angel, Brownie, you stay here. I'm going into the woods to find Sparky."
    c "Angel, Brownie, quédense aquí. Voy al bosque a buscar a Sparky."

# game/scripts/scriptliving.rpy:1496
translate spanish lieforsparky_050e20fa:

    # c "Maybe I can use my magic to..."
    c "Tal vez pueda usar mi magia para..."

# game/scripts/scriptliving.rpy:1498
translate spanish lieforsparky_d34f9df6:

    # n "Coco digs around her dress."
    n "Coco hurga en su vestido."

# game/scripts/scriptliving.rpy:1500
translate spanish lieforsparky_146595e4:

    # c "Where..."
    c "Dónde..."

# game/scripts/scriptliving.rpy:1505
translate spanish lieforsparky_b9d02a3a:

    # c "WHERE IS MY WAND?!"
    c "¿DÓNDE ESTÁ MI VARITA?"

# game/scripts/scriptliving.rpy:1508
translate spanish lieforsparky_ba69c8df:

    # b "UH OH."
    b "Oh, oh."

# game/scripts/scriptliving.rpy:1510
translate spanish lieforsparky_67e113ec:

    # b "Do you think..."
    b "¿Crees que..."

# game/scripts/scriptliving.rpy:1513
translate spanish lieforsparky_2887aeef:

    # o "H-HE STOLE THE WAND?!"
    o "¡¿ÉL ROBÓ LA VARITA?!"

# game/scripts/scriptliving.rpy:1515
translate spanish lieforsparky_0ffb788d:

    # o "B-BUT HE'S A G-GOOD BOY!!"
    o "¡¡P-PERO EL ES UN B-BUEN PERRO!!"

# game/scripts/scriptliving.rpy:1518
translate spanish lieforsparky_0a42e9a3:

    # a "... I suppose getting possessed by a crazed demon and almost killing all of your friends can make you do strange things..."
    a "... Supongo que ser poseído por un demonio loco y casi matar a todos tus amigos puede hacerte hacer cosas extrañas..."

# game/scripts/scriptliving.rpy:1521
translate spanish lieforsparky_7081f1c5:

    # o "H-he did say something about getting revenge..."
    o "E-él dijo algo sobre venganza..."

# game/scripts/scriptliving.rpy:1524
translate spanish lieforsparky_b762ab96:

    # c "THAT BASTARD!!"
    c "¡¡ESE MALNACIDO!!"

# game/scripts/scriptliving.rpy:1526
translate spanish lieforsparky_a4fadc44:

    # c "AAAAUGH AND WE JUST GOT THE WAND BACK TOO!!"
    c "¡¡AAAAGH, Y JUSTO ACABÁBAMOS DE RECUPERAR LA VARITA!!"

# game/scripts/scriptliving.rpy:1529
translate spanish lieforsparky_fe3c73f2:

    # o "M-maybe he'll win!!"
    o "¡¡Quizás el lo haga bien!!"

# game/scripts/scriptliving.rpy:1532
translate spanish lieforsparky_07eb0ce3:

    # c "He doesn't even know how to use it!!"
    c "¡¡Ni siquiera sabe usarlo!!"

# game/scripts/scriptliving.rpy:1534
translate spanish lieforsparky_aa2dcd48:

    # c "We need to find him before Ginger or Patches does."
    c "Necesitamos encontrarlo antes de que lo hagan Ginger o Patches."

# game/scripts/scriptliving.rpy:1537
translate spanish lieforsparky_ad95d404:

    # a "My arm may be broken... But I think I could still hel-"
    a "Puede que tenga el brazo roto... Pero creo que aún podría ayudar..."

# game/scripts/scriptliving.rpy:1541
translate spanish lieforsparky_01eb720d:

    # c "DON'T PUSH IT ANGEL."
    c "¡NO TE ARRIESGUES, ANGEL!"

# game/scripts/scriptliving.rpy:1543
translate spanish lieforsparky_39a5f745:

    # c "You neither Brownie."
    c "Tú tampoco, Brownie."

# game/scripts/scriptliving.rpy:1546
translate spanish lieforsparky_a1d9b1be:

    # b "I didn't even say anything!!"
    b "¡¡Ni siquiera dije nada!!"

# game/scripts/scriptliving.rpy:1549
translate spanish lieforsparky_af8769b7:

    # c "Let's go Olive. We should find weapons before we go into the woods."
    c "Vamos Olive. Deberíamos encontrar armas antes de adentrarnos en el bosque."

# game/scripts/scriptliving.rpy:1568
translate spanish lieforsparky2_6ab8a01d:

    # o "I'm j-just warming up! You know how Sparky is; Big dog, hard to k-keep up with!"
    o "¡Estoy p-preparandome! Ya sabes cómo es Sparky; ¡Perro grande, difícil de s-seguir!"

# game/scripts/scriptliving.rpy:1571
translate spanish lieforsparky2_249424b3:

    # c "Uh huh, have fun with that!"
    c "¡Ajá, diviértete con eso!"

# game/scripts/scriptliving.rpy:1574
translate spanish lieforsparky2_b75fb4b8:

    # o "Oh uhh! I just wanted to know what you g-guys were talking about!"
    o "¡Oh, eh! ¡Solo quería saber de qué estaban hablando ustedes!"

# game/scripts/scriptliving.rpy:1577
translate spanish lieforsparky2_0e4906ad:

    # b "We're talking about the SWEET loot we raked in for your birthday!!"
    b "¡¡Estamos hablando del INCREÍBLE botín que acumulamos para tu cumpleaños!!"

# game/scripts/scriptliving.rpy:1580
translate spanish lieforsparky2_e6df03c3:

    # a "Heheh... You'd better leave before Brownie spills..."
    a "Jeje... Mejor vete antes de que a Brownie se le escape todo..."

# game/scripts/scriptliving.rpy:1585
translate spanish lieforsparky2_67f41697:

    # o "Okay I'll t-talk to you all later!"
    o "¡Está bien, hablaré con todos ustedes más tarde!"

translate spanish strings:

    # game/scripts/scriptliving.rpy:313
    old "{color=#ffcd65}Inspect table.{/color}"
    new "{color=#ffcd65}Inspeccionar la mesa.{/color}"

    # game/scripts/scriptliving.rpy:313
    old "{color=#ffcd65}Inspect cushions.{/color}"
    new "{color=#ffcd65}Inspeccione los cojines.{/color}"

    # game/scripts/scriptliving.rpy:313
    old "{color=#ffcd65}Inspect dead zombies.{/color}"
    new "{color=#ffcd65}Inspeccionar a los zombies.{/color}"

    # game/scripts/scriptliving.rpy:313
    old "{color=#ffcd65}Talk to Coco.{/color}"
    new "{color=#ffcd65}Hablar con Coco.{/color}"

    # game/scripts/scriptliving.rpy:313
    old "{color=#ffcd65}Talk to Angel.{/color}"
    new "{color=#ffcd65}Hablar con Angel.{/color}"

    # game/scripts/scriptliving.rpy:370
    old "{color=#86c4eb}Enter kitchen.{/color}"
    new "{color=#86c4eb}Ingresar a la cocina.{/color}"

    # game/scripts/scriptliving.rpy:370
    old "{color=#ffc1ed}Go upstairs.{/color}"
    new "{color=#ffc1ed}Subir las escaleras.{/color}"

    # game/scripts/scriptliving.rpy:370
    old "{color=#a1bd65}Exit house.{/color}"
    new "{color=#a1bd65}Salir de casa.{/color}"

    # game/scripts/scriptliving.rpy:370
    old "{color=#ffcd65}Stay.{/color}"
    new "{color=#ffcd65}Permanecer.{/color}"

    # game/scripts/scriptliving.rpy:475
    old "Drink tea."
    new "Beber té."

    # game/scripts/scriptliving.rpy:811
    old "Ask Angel out."
    new "Invirlo a salir de la sala."

    # game/scripts/scriptliving.rpy:811
    old "Leave Angel alone."
    new "Dejar a Angel en paz."

    # game/scripts/scriptliving.rpy:1148
    old "Let Sparky bother Coco."
    new "Dejarlo."

    # game/scripts/scriptliving.rpy:1450
    old "Tell the truth."
    new "Decir la verdad."

    # game/scripts/scriptliving.rpy:1450
    old "Lie."
    new "Mentir."

